"""Read-only independent review of saved live pilot records; never rescore."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
CAMPAIGN = ROOT / 'rosa-evaluation/artifacts/workflow-live-v1-20261022'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    frozen = json.loads((CAMPAIGN / 'freeze.json').read_text())
    source_ok = all(sha(ROOT / name) == digest for name, digest in frozen['files'].items())
    lines = ['# ROSA workflow live v1: detailed review', '',
        'Generated ' + datetime.now(timezone.utc).isoformat() + '.', '',
        'Scope: small, development-informed mock feasibility pilot. Same user goal, '
        'two permitted skills, bounded primitive operations and common accepted-report '
        'termination. The candidate transfers read / conditional write / verification '
        'coordination to ROSA; skill interpretation and reporting remain model responsibilities.', '',
        'The intervention includes different select_skill execution semantics. Results '
        'describe the complete arrangement, not an isolated routing algorithm or novelty claim.', '',
        '| Backend | Case | Condition | Correct | Report | Calls | Known output | Native | Invalid | Seconds | Persisted trace |',
        '| --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |']
    checks, pending, failures, recoveries = [], [], [], []
    for backend in ('ollama', 'siwc'):
        checkpoint = CAMPAIGN / backend / 'checkpoint.json'
        if not checkpoint.exists():
            pending.append(backend + ': no live trial checkpoint yet (possibly waiting for consent)')
            continue
        status = json.loads(checkpoint.read_text())
        if status['status'] != 'COMPLETE':
            pending.append(backend + ': ' + status['status'])
        for row in status['trials']:
            folder = CAMPAIGN / backend / row['run_id']
            evidence = json.loads((folder / 'evidence.json').read_text())
            local = json.loads((folder / 'trace.json').read_text())['spans']
            persisted_path = folder / 'phoenix-trace.json'
            remote = json.loads(persisted_path.read_text()) if persisted_path.exists() else []
            ids = {s['context']['span_id'].removeprefix('0x') for s in local}
            remote_ids = {s['context']['span_id'].removeprefix('0x') for s in remote}
            matched = bool(remote) and ids == remote_ids and all(s.get('end_time') and
                (not s.get('parent_id') or s['parent_id'].removeprefix('0x') in remote_ids) for s in remote)
            session = evidence['session']
            native_count = len(session['operations'])
            model_count = sum(s.get('attributes', {}).get('openinference.span.kind') == 'LLM' for s in local)
            calls = row['inference']['calls']
            native_match = native_count == row['native_operations'] and native_count <= 10
            messages = evidence['model_messages']
            usage_match = (sum(m['usage']['input_tokens'] for m in messages) == row['inference']['known_input_tokens']
                and sum(m['usage']['output_tokens'] for m in messages) == row['inference']['known_output_tokens']
                and len(messages) == len([e for e in row['inference']['events'] if e['status'] == 'RETURNED']))
            caps_match = calls <= 8 and sum(e['kind'] == 'write' for e in session['operations']) <= 1
            report = row['score']['accepted_report_status'] or '(none)'
            lines.append(f'| {backend} | {row["case"]} | {"program" if row["program_managed"] else "model"} | '
                f'{row["score"]["pass"]} | {report} | {calls} | '
                f'{row["inference"]["known_output_tokens"]} | {native_count} | '
                f'{row["score"]["invalid_attempts"]} | {row["wall_seconds"]:.2f} | {matched} |')
            checks.append({'backend': backend, 'run_id': row['run_id'], 'exact_persisted_trace': matched,
                'native_counters_match': native_match, 'llm_span_counters_match': model_count == calls,
                'usage_counters_match': usage_match, 'hard_call_write_caps': caps_match,
                'pass': matched and native_match and model_count == calls and usage_match and caps_match,
                'local_span_count': len(ids), 'persisted_span_count': len(remote_ids)})
            validations = [e for e in session['events'] if e['type'] == 'validation']
            if not row['score']['pass']:
                failures.append({'backend': backend, 'run_id': row['run_id'], 'answer': row['answer'],
                    'score': row['score'], 'validation_codes': [e['code'] for e in validations],
                    'submitted_reports': session['reports'],
                    'length_terminated_generations': sum(e['finish_reason'] == 'length' for e in row['inference']['events']),
                    'usage_complete': row['inference']['usage_complete']})
            elif validations:
                recoveries.append({'backend': backend, 'run_id': row['run_id'],
                    'codes': [e['code'] for e in validations]})
    analysis_path = CAMPAIGN / 'analysis.json'
    analysis = json.loads(analysis_path.read_text()) if analysis_path.exists() else None
    if analysis:
        lines += ['', '## Aggregate costs (all attempts)', '',
            '| Backend | Condition | Correct | Calls | Input tokens | Output tokens | Native operations | Invalid attempts | Trial seconds |',
            '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
        for backend in analysis['backends']:
            for c in backend['conditions']:
                lines.append(f'| {backend["backend"]} | {"program" if c["program_managed"] else "model"} | '
                    f'{c["correct"]}/{c["completed"]} | {c["model_calls"]} | {c["known_input_tokens"]} | '
                    f'{c["known_output_tokens"]} | {c["native_operations"]} | {c["invalid_attempts"]} | '
                    f'{c["wall_seconds_all_attempts"]:.2f} |')
        lines += ['', 'Native operations did not remain constant in live use: Qwen increased '
            'from 19 to 24 and Sol from 16 to 17. Extra model-requested reads after '
            'program verification/escalation are included, not hidden. Fewer inference '
            'calls must not be presented as fewer total robot/sensor operations.', '']
    lines += ['', '## Status and interpretation', '',
        'Pending/incomplete backends: ' + ('; '.join(pending) if pending else 'none') + '.', '',
        'Frozen live source hashes unchanged: ' + str(source_ok) + '.', '',
        'Both-backend feasibility gate: ' + str(analysis.get('both_backends_feasibility_gate') if analysis else 'pending') + '.', '',
        'Per-backend frozen gate details:', '', '```json',
        json.dumps([{'backend': b['backend'], 'status': b['status'], 'valid': b['valid'],
            'candidate_feasibility_gate': b['candidate_feasibility_gate'],
            'paired_losses': [p['case'] for p in b['pairs'] if p['paired_loss']],
            'jointly_correct_healthy_call_savings': b['jointly_correct_healthy_call_savings']}
            for b in analysis['backends']] if analysis else [], indent=2), '```', '',
        'Use analysis.json for the frozen paired gate. A correct fault result may be '
        'FAILURE or UNKNOWN; it does not mean successful robot movement. Do not turn a '
        'pending or interrupted trial into a pass, or compare aggregate tail log entries.', '',
        'Latency includes real model loading/inference and tool execution. The first '
        'local reference starts cold; inspect per-message load_duration, prompt_eval_duration '
        'and eval_duration in evidence before attributing latency savings to orchestration. '
        'No separate warm-up inference was added. Pair order is counterbalanced; only '
        'one observation per case/condition exists.', '',
        'Qwen profile: pinned Qwen3.5:9b Q4_K_M digest, 8192 context, seed 42, '
        'temperature 0, thinking disabled, mmap enabled, 1024 per call clamped to a '
        '2048 cumulative requested output allowance. Runtime model placement is retained '
        'in operator/local-loaded-profile.json. It is not assumed fully GPU-resident.', '',
        'Sol profile: unchanged account-catalog gpt-6.1-sol via the existing ChatSiwc '
        'adapter. No per-call hard generation cap is exposed. Usage is metered; an '
        'observed output threshold stops additional execution, but cannot bound an '
        'already generated hosted response. Unreturned usage remains censored. '
        'Request/time/native limits are matched within each backend; cross-backend '
        'token equality is not claimed.', '',
        'Program-native operations and verification provenance are distinct from model '
        'actions. Recovered reports count as combined-system outcomes. A wrong permitted '
        'skill fails user-goal completion even if that selected pose is locally verified.', '',
        'Tokens, authorization headers and encrypted reasoning are excluded from saved '
        'records. New OAuth consent stays manual; session-siwc.json records cleanup '
        'without credential material. No credential persistence is enabled.', '',
        '## Failed outcomes and corrections', '']
    for failure in failures:
        lines += ['### ' + failure['backend'] + ' / ' + failure['run_id'], '',
            'Terminal response: `' + failure['answer'] + '`.', '',
            'Validation codes: ' + ', '.join(failure['validation_codes']) + '.', '',
            'Length-terminated generations: ' + str(failure['length_terminated_generations']) +
                '; returned usage complete: ' + str(failure['usage_complete']) + '.', '',
            'Submitted reports (rejections preserved):', '', '```json',
            json.dumps(failure['submitted_reports'], indent=2), '```', '']
    lines += ['Successful outcomes after validation feedback: ' + str(len(recoveries)) + '.', '',
        '```json', json.dumps(recoveries, indent=2), '```', '', '## What follows', '',
        'Complete and audit both backends before drawing a comparison. If the frozen '
        'gate fails, preserve the negative result and diagnose the recorded failure; '
        'do not tune or replace these trials. If it passes, specify a small bounded '
        'UR5e Gazebo transfer protocol. No large campaign, physical deployment or '
        'generalization claim follows automatically. A strong macro-tool reference '
        'and genuinely held-out tasks remain necessary for broader research claims.', '',
        'All earlier Stage 4, reliability and output-budget results remain separate.']
    if analysis and analysis['status'] == 'COMPLETE':
        lines += ['', '## Recommendation from this completed pilot', '']
        for backend in analysis['backends']:
            reference, program = backend['conditions']
            lines += [f'- {backend["backend"]}: reference {reference["correct"]}/6 correct '
                f'with {reference["model_calls"]} calls; program {program["correct"]}/6 correct '
                f'with {program["model_calls"]} calls. Frozen progression gate: '
                f'{backend["candidate_feasibility_gate"]}.']
        if not analysis['both_backends_feasibility_gate']:
            lines += ['', 'Do not advance this version as a validated improvement for both backends. '
                'Preserve the useful efficiency evidence alongside the paired reliability loss.', '',
                'The recorded unavailable-observation program failure chose UNKNOWN but '
                'repeatedly used bench_arm instead of /bench_arm. It did not dispatch motion '
                'and was not truncated. This isolates a remaining reporting-contract burden; '
                'it does not establish that the model failed to recognize uncertainty.', '',
                'A reasonable next engineering candidate is a common evidence-reference '
                'reporting interface: the model classifies the outcome and cites trusted '
                'evidence; software retrieves exact identifiers/values and validates freshness. '
                'If pursued, apply it to both conditions and both backends, validate separately, '
                'and freeze fresh prospective cases before another comparison. Do not silently '
                'repair wrong identifiers in these trials or rescore them as passes.', '',
                'This is a recommendation, not an implementation or a new authorized campaign. '
                'Full JTVR remains paused and episodic memory remains optional.']
    (CAMPAIGN / 'DETAILED_REVIEW_FOR_CHATGPT.md').write_text('\n'.join(lines) + '\n')
    verified = source_ok and len(checks) == 24 and all(r['pass'] for r in checks) and not pending
    record = {'complete': not pending and len(checks) == 24, 'evidence_verified': verified,
              'frozen_source_hashes_match': source_ok, 'trials_checked': len(checks), 'rows': checks,
              'failed_outcomes': failures, 'corrected_after_feedback': recoveries, 'pending': pending}
    (CAMPAIGN / 'independent-review.json').write_text(json.dumps(record, indent=2) + '\n')
    if verified:
        destination = CAMPAIGN.parent / 'ROSA_WORKFLOW_LIVE_V1_COMPLETE_EVIDENCE_2026-10-22.zip'
        files = [p for p in CAMPAIGN.rglob('*') if p.is_file() and p.suffix != '.tmp']
        files += [Path(__file__)]
        manifest = {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
        with ZipFile(destination, 'x', compression=ZIP_DEFLATED) as archive:
            for name in manifest:
                archive.write(ROOT / name, name)
            archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2) + '\n')
        with ZipFile(destination) as archive:
            assert archive.testzip() is None
            assert all(hashlib.sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
        destination.with_suffix('.sha256').write_text(sha(destination) + '  ' + destination.name + '\n')
        print(json.dumps({'evidence_verified': True, 'archive': str(destination), 'sha256': sha(destination)}))
    else:
        print(json.dumps({'evidence_verified': False, 'trials_checked': len(checks), 'pending': pending}))


if __name__ == '__main__': main()
