"""Independent evidence review/package; no edits to frozen scores or source."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
CAMPAIGN = ROOT / 'rosa-evaluation/artifacts/workflow-reference-v1-20261022'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    frozen = json.loads((CAMPAIGN / 'freeze.json').read_text())
    source_ok = all(sha(ROOT / name) == digest for name, digest in frozen['files'].items())
    control_checks = []
    for control_path in [CAMPAIGN / 'deterministic-preflight/controls/result.json',
                         *CAMPAIGN.glob('gazebo/*/fresh-controls/result.json')]:
        control = json.loads(control_path.read_text())
        control_checks.append({'path': control_path.relative_to(CAMPAIGN).as_posix(),
            'pass': control['pass'] and len(control['rows']) == 4 and all(r['pass'] for r in control['rows'])})
    checks, failures, corrections, states, fault_coverage, healthy_summary = [], [], [], [], [], []
    for phase in ('mock', 'gazebo'):
        for backend in ('ollama', 'siwc'):
            checkpoint = CAMPAIGN / phase / backend / 'checkpoint.json'
            if not checkpoint.exists():
                states.append({'phase': phase, 'backend': backend, 'status': 'NOT_RUN'})
                continue
            status = json.loads(checkpoint.read_text())
            states.append({'phase': phase, 'backend': backend, 'status': status['status']})
            for program in (False, True):
                healthy = [r for r in status['trials'] if r['program_managed'] == program
                           and r['score']['expected_status'] == 'SUCCESS']
                healthy_summary.append({'phase': phase, 'backend': backend, 'program': program,
                    'healthy_trials': len(healthy), 'correct_healthy': sum(r['score']['pass'] for r in healthy)})
            assert sum(r['inference']['calls'] for r in status['trials']) == status['total_model_calls']
            assert status['total_model_calls'] <= 64
            for row in status['trials']:
                folder = CAMPAIGN / phase / backend / row['run_id']
                local = json.loads((folder / 'trace.json').read_text())['spans']
                evidence = json.loads((folder / 'evidence.json').read_text())
                remote_path = folder / 'phoenix-trace.json'
                remote = json.loads(remote_path.read_text()) if remote_path.exists() else []
                ids = {s['context']['span_id'].removeprefix('0x') for s in local}
                server_ids = {s['context']['span_id'].removeprefix('0x') for s in remote}
                closed = bool(remote) and all(s.get('end_time') and (not s.get('parent_id') or
                    s['parent_id'].removeprefix('0x') in server_ids) for s in remote)
                messages, session = evidence['model_messages'], evidence['session']
                usage_ok = (sum((m['usage'] or {}).get('input_tokens', 0) for m in messages) == row['inference']['known_input_tokens']
                    and sum((m['usage'] or {}).get('output_tokens', 0) for m in messages) == row['inference']['known_output_tokens'])
                calls = sum(s.get('attributes', {}).get('openinference.span.kind') == 'LLM' for s in local)
                caps = calls == row['inference']['calls'] and calls <= 8 and len(session['operations']) <= 10 and sum(
                    e['kind'] == 'write' for e in session['operations']) <= 1
                reports = [r for r in session['reports'] if r.get('accepted')]
                if 'no_effect' in row['case']:
                    fault_coverage.append({'phase': phase, 'backend': backend, 'run_id': row['run_id'],
                        'write_dispatched': any(e['kind'] == 'write' for e in session['operations']),
                        'frozen_outcome_correct': row['score']['pass']})
                refs_ok = all(r.get('observation_id') and r.get('values_supplied_by') ==
                              'program_from_existing_observation' for r in reports)
                checked = {'phase': phase, 'backend': backend, 'run_id': row['run_id'],
                    'trace_exact_closed': ids == server_ids and closed, 'usage_matches': usage_ok,
                    'caps_match': caps, 'report_provenance': refs_ok,
                    'pass': ids == server_ids and closed and usage_ok and caps and refs_ok}
                checks.append(checked)
                validation = [e for e in session['events'] if e['type'] == 'validation']
                if not row['score']['pass']:
                    failures.append({'phase': phase, 'backend': backend, 'run_id': row['run_id'],
                        'answer': row['answer'], 'score': row['score'], 'validation': validation,
                        'reports': session['reports'], 'inference': row['inference']})
                elif validation:
                    corrections.append({'phase': phase, 'backend': backend, 'run_id': row['run_id'],
                                        'codes': [e['code'] for e in validation]})
    gate_path = CAMPAIGN / 'mock-gate.json'
    gate = json.loads(gate_path.read_text()) if gate_path.exists() else None
    analysis = json.loads((CAMPAIGN / 'analysis.json').read_text())
    supervisors = [json.loads((CAMPAIGN / 'operator' / (b + '-supervisor.json')).read_text(encoding='utf-8-sig'))
                   for b in ('ollama', 'siwc')]
    terminal = all(s['status'] in ('COMPLETE', 'STOPPED') for s in supervisors)
    expected = 32 if gate and gate['pass'] else 16
    control_ok = all(c['pass'] for c in control_checks) and len(control_checks) == (3 if expected == 32 else 1)
    verified = source_ok and terminal and len(checks) == expected and all(c['pass'] for c in checks) and control_ok
    lines = ['# Shared reporting reference and UR5e transfer: detailed review', '',
        'Generated ' + datetime.now(timezone.utc).isoformat() + '.', '',
        'This is a prospective engineering/integration milestone. The earlier workflow-live-v1 '
        'Qwen 6/6→5/6 result and failed gate remain unchanged. The current common reporting '
        'contract is applied to both models and both conditions. The program supplies exact '
        'values from existing observations; the model still classifies the outcome.', '',
        'No new evidence database, general planner, model training or model-specific repair '
        'was introduced. The reusable reporting implementation is reference.py, layered '
        'over existing session observations, freshness rules and report validation.', '',
        '| Phase | Backend | Condition | Correct / completed | Calls | Input tokens | Output tokens | Native | Invalid | Seconds |',
        '| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for r in analysis['rows']:
        lines.append(f'| {r["phase"]} | {r["backend"]} | {"program" if r["program"] else "model"} | '
            f'{r["correct"]}/{r["completed"]} | {r["calls"]} | {r["input_tokens"]} | {r["output_tokens"]} | '
            f'{r["native_operations"]} | {r["invalid_attempts"]} | {r["wall_seconds"]:.2f} |')
    lines += ['', 'Correct FAILURE/UNKNOWN classifications are correct fault handling, not successful movements.', '',
        'Mock progression gate: ' + str(gate) + '. Evidence audit: ' + str(verified) + '.', '',
        '```json', json.dumps(states, indent=2), '```', '',
        '## Independent checks and controls', '',
        'Frozen source matches: ' + str(source_ok) + '; saved trial trace/usage/cap/reference checks: '
        + str(len(checks)) + '. Exact persisted Phoenix span IDs and closed trees were checked independently.', '',
        'Preflight: 8 reporting-contract checks,16 workflow checks,9 inference/design checks; '
        'eight actual scripted ROSA/Phoenix traces; four deterministic six-joint UR5e controls. '
        'Fresh deterministic controls and controller-readiness checks repeat before each live Gazebo backend.', '',
        'Gazebo uses a separate read-only joint-state subscriber for independent scoring. '
        'Reset/observer/control operations are outside agent budgets and logged separately. '
        'The model/workflow cannot access private observer truth or injected-fault labels.', '',
        'Faults are controlled transport-level injections: no-effect suppresses trajectory '
        'publication, while missing-observation masks the agent transport read. Gazebo '
        'continues publishing joint states for the independent observer. These are not '
        'naturally occurring controller/network/sensor outages.', '',
        'Healthy goal-completion counts:', '', '```json', json.dumps(healthy_summary, indent=2), '```', '',
        '## Retrospective fault-exercise diagnostic (no score changes)', '',
        'A truthful FAILURE while already off target does not by itself establish that '
        'an injected ineffective command was exercised. The frozen primary score checks '
        'truthful outcome reporting; dispatch coverage below separately shows whether a '
        'write occurred. Do not credit command-failure handling where no command was tried. '
        'A stricter attempt/coverage requirement would need prospective definition in a future study.', '',
        '```json', json.dumps(fault_coverage, indent=2), '```', '',
        '## Failed outcomes', '', '```json', json.dumps(failures, indent=2), '```', '',
        '## Successful outcomes after feedback', '', '```json', json.dumps(corrections, indent=2), '```', '',
        '## Limits and interpretation', '',
        'One repetition per fresh development-informed case. This is not held-out statistical '
        'evidence or a causal comparison against old differently cased/contracted trials. '
        'Compare model-managed/program-managed arms within each backend and phase.', '',
        'Calls can fall while native reads or invalid attempts rise. Failed attempts are '
        'included in aggregate costs; efficiency on successful tasks needs paired inspection. '
        'Some extra native work can also mean that the workflow attempted movement that '
        'the reference omitted; compare action coverage before calling that overhead waste. '
        'Initial local loads and simulator/controller timing limit latency attribution.', '',
        'Claim-time evaluator observer reads also occur within the measured trial window; '
        'latency includes evaluation overhead. There is no normalized inference-only '
        'speedup claim here.', '',
        'Qwen: same pinned Q4_K_M digest,ctx8192,temp0,seed42,thinking off,mmap on, '
        '1024 output per call clamped to a cumulative2048 requested allowance. Sol: '
        'unchanged OAuth adapter/account defaults, observed2048 stopping threshold, not '
        'a hard generation cap. Censored usage is explicit in individual inference records.', '',
        'Limits remain8 calls,180 seconds,10 native operations,one dispatched write per trial; '
        '64 calls per phase/backend,128 per backend pipeline. No automatic inference replay. '
        'OAuth stays memory-only/manual consent, with existing renewal and final revocation. '
        'No credentials or encrypted reasoning appear in evidence.', '',
        'Joint-state outcome verification does not establish collision avoidance, grasping '
        'or physical-robot safety. No physical hardware or large benchmark was launched.', '',
        'Before a larger research study: introduce the strong macro-skill reference and '
        'held-out tasks/repetitions. Preserve unrelated Qwen failures as limitations; '
        'do not automatically redesign the framework around them. Full JTVR remains '
        'paused and episodic memory remains optional.']
    lines += ['', '## Milestone result and recommendation', '',
        'The minimal common reporting-reference implementation, focused fresh validation '
        'and bounded two-backend UR5e transfer have been completed if all four state '
        'records above are COMPLETE. The stronger macro-skill comparison and a larger '
        'held-out study have not been implemented or launched.', '',
        'For the collected Gazebo results, interpret Qwen model-managed healthy failure '
        'as an execution omission with truthful reporting, not a false success or a '
        'truncated response. Its corresponding program-managed movement completed. '
        'The workflow also exercised an ineffective command that the model-managed '
        'reference did not attempt. These distinctions limit aggregate cost comparisons.', '',
        'The current reporting interface is a successful engineering validation on these '
        'fresh cases, not a retrospective correction of the failed earlier pilot and '
        'not an isolated causal estimate of the interface change. Program-supplied '
        'bookkeeping is part of the combined system in BOTH current conditions.', '',
        'Proceed next to the already-planned strong macro-skill reference and a carefully '
        'specified, small held-out comparison. Do not add more framework layers merely '
        'to repair every Qwen mistake. Keep the current module small and report negative '
        'findings if a simpler macro achieves the same results. Physical deployment '
        'and broad reliability/novelty claims remain unsupported.']
    (CAMPAIGN / 'DETAILED_REVIEW_FOR_CHATGPT.md').write_text('\n'.join(lines) + '\n')
    record = {'verified': verified, 'source_hashes_match': source_ok, 'expected_trials': expected,
        'trials_checked': len(checks), 'checks': checks, 'control_checks': control_checks,
        'healthy_summary': healthy_summary, 'fault_exercise_diagnostic': fault_coverage, 'failed_outcomes': failures}
    (CAMPAIGN / 'independent-review.json').write_text(json.dumps(record, indent=2) + '\n')
    if not verified:
        print(json.dumps({'verified': False, 'checked': len(checks), 'expected': expected, 'terminal': terminal}))
        return
    destination = CAMPAIGN.parent / 'ROSA_WORKFLOW_REFERENCE_V1_EVIDENCE_2026-10-22.zip'
    files = [p for p in CAMPAIGN.rglob('*') if p.is_file() and p.suffix not in ('.tmp', '.lock')]
    files.append(Path(__file__))
    manifest = {p.relative_to(ROOT).as_posix(): sha(p) for p in files}
    with ZipFile(destination, 'x', compression=ZIP_DEFLATED) as archive:
        for name in manifest: archive.write(ROOT / name, name)
        archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2) + '\n')
    with ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert all(hashlib.sha256(archive.read(n)).hexdigest() == d for n, d in manifest.items())
    destination.with_suffix('.sha256').write_text(sha(destination) + '  ' + destination.name + '\n')
    print(json.dumps({'verified': True, 'archive': str(destination), 'sha256': sha(destination), 'files': len(files)}))


if __name__ == '__main__': main()
