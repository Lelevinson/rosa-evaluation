# Archive completeness correction

The original ZIP correctly hashes its listed entries but excludes the frozen uv.lock. The packaging filter excluded all .lock suffixes. This corrected archive adds the exact frozen file and verifies all frozen sources against both the freeze and ZIP entries. The original archive, source freeze, scores and results are unchanged.
