# Lab local-model comparison — 2026-11-17

New replication of known M4 cases. 80 scheduled trials per model; four repetitions, two conditions.

| Model | Condition | Known-goal correct/recorded | Calls | Mean task seconds | Native ops |
|---|---|---:|---:|---:|---:|
| qwen3.5:9b | primitives | 26/36 | 185 | 12.01 | 75 |
| qwen3.5:9b | macro | 28/36 | 97 | 8.52 | 98 |

Eight ambiguous trials per model need actual human semantic review; the known-goal denominator is 72 per completed model. The legacy regex scores are diagnostic, not an adjudication.

All-attempt costs include failed tasks. Matched-success and family details are in analysis.json. No broad reliability, generalization, equivalence or physical-safety claim follows. Compare against fresh lab Qwen; historical Sol and laptop Qwen differ in hardware, repetitions and environment.
