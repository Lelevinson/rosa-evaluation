# Lab local-model comparison — 2026-11-17

New replication of known M4 cases. 80 scheduled trials per model; four repetitions, two conditions.

| Model | Condition | Known-goal correct/recorded | Calls | Mean task seconds | Native ops |
|---|---|---:|---:|---:|---:|
| qwen3.5:9b | primitives | 27/36 | 188 | 12.39 | 78 |
| qwen3.5:9b | macro | 28/36 | 98 | 8.56 | 97 |
| llama3.1:8b-instruct-q4_K_M | primitives | 0/36 | 211 | 2.16 | 18 |
| llama3.1:8b-instruct-q4_K_M | macro | 0/36 | 193 | 2.84 | 88 |
| granite3.3:8b | primitives | 0/36 | 40 | 3.13 | 0 |
| granite3.3:8b | macro | 0/36 | 40 | 2.64 | 0 |
| ministral-3:8b-instruct-2512-q4_K_M | primitives | 28/36 | 156 | 4.83 | 76 |
| ministral-3:8b-instruct-2512-q4_K_M | macro | 28/36 | 82 | 2.31 | 78 |

Eight ambiguous trials per model need actual human semantic review; the known-goal denominator is 72 per completed model. The legacy regex scores are diagnostic, not an adjudication.

All-attempt costs include failed tasks. Matched-success and family details are in analysis.json. No broad reliability, generalization, equivalence or physical-safety claim follows. Compare against fresh lab Qwen; historical Sol and laptop Qwen differ in hardware, repetitions and environment.
