# Marvel robotics project — lab workspace

Canonical folder: /media/naeem/d1/marvel proj
Prepared 2026-11-17. This is on the large d1 drive. The hyphenated marvel-proj name is a compatibility symlink, not a second model download.

- rosa-research/: Martin's member/martin branch, b13df0f03677754f42383dee95424cded862b117.
- rosa-evaluation/: Martin's member/martin branch, synchronized to local commit ec42ee72f53d95004c51b803c1a5d41f58e08d1c through a verified Git bundle; no GitHub push.
- models/: four Ollama model families, all Q4_K_M.
- baseline/: retained original M4 source and locks, immutable for this replication.
- study/: new versioned local-model replication adapter and protocol.
- runtime/: project-local Ollama, locked Python environments and Phoenix database.
- results/: live checkpoints, trial records, exact trace audits and generated comparison.
- preparation/: setup logs, retained preflight failures, inventory and download metadata.
- evidence/: checksummed archive generated when the bounded worker finishes or stops.

The experiment is a new replication, not the historical M4 campaign and not G1 held-out testing. It schedules 80 trials per local model (320 total). Main known-goal correctness covers 72 per model; eight ambiguous trials per model require separate human semantic review. Original M4 was 80 TOTAL (40 Sol + 40 Qwen).

Read results/operator-status.json for current status. The report is results/COMPARISON_REPORT.md, with full numeric breakdown in results/analysis.json after the first model completes. An incomplete file is a checkpoint, not a final verdict.

The detached worker continues after closing SSH/VS Code or disconnecting the laptop VPN. The lab computer must remain awake and running. Do not reboot it, stop the owned container/server, or start competing GPU work during timing. The worker will not stop other users' jobs. Failures and consumed requests are retained; do not blindly rerun the operator.

ROS 2 Jazzy/Gazebo runs in the owned marvel-rosa-lab-20261117 container (Ubuntu 24.04), not on the Ubuntu 25.04 host. Ollama is project-local on 127.0.0.1:11439; Phoenix is HTTP-only on 127.0.0.1:6006. No cloud API key, hosted Sol grant or SSH password is stored here.
