import urllib.request,json,hashlib,subprocess,time
from pathlib import Path
root=Path('/media/naeem/d1/marvel-proj')
release=json.load(urllib.request.urlopen('https://api.github.com/repos/ollama/ollama/releases/tags/v0.40.6',timeout=30))
a=next(a for a in release['assets'] if a['name']=='ollama-linux-amd64.tar.zst')
p=root/'runtime'/a['name']
started=time.time()
print('Downloading',a['browser_download_url'],flush=True)
with urllib.request.urlopen(a['browser_download_url'],timeout=120) as r,p.open('wb') as f:
 while chunk:=r.read(8*1024*1024): f.write(chunk)
digest=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert a['digest']=='sha256:'+digest,(digest,a['digest'])
subprocess.run(['tar','--zstd','-xf',str(p),'-C',str(root/'runtime')],check=True)
(root/'preparation'/'ollama_install.json').write_text(json.dumps({'version':release['tag_name'],'asset':a['name'],'sha256':digest,'verified_against_official_release_digest':True,'download_seconds':time.time()-started},indent=2))
print('INSTALL_COMPLETE',digest,flush=True)
