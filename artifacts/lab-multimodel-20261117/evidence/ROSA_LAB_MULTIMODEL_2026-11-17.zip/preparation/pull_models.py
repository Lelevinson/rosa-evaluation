import json,time,urllib.request,traceback
from pathlib import Path
root=Path('/media/naeem/d1/marvel-proj')
models=['qwen3.5:9b','llama3.1:8b-instruct-q4_K_M','granite3.3:8b','ministral-3:8b-instruct-2512-q4_K_M']
status={'models':models,'completed':[],'status':'DOWNLOADING'}
def save():
 p=root/'preparation/model-download-status.json'; t=p.with_suffix('.tmp'); t.write_text(json.dumps(status,indent=2)); t.replace(p)
def post(path,data,timeout=3600):
 r=urllib.request.Request('http://127.0.0.1:11439'+path,data=json.dumps(data).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(r,timeout=timeout) as f:return json.load(f)
try:
 for m in models:
  status['current']=m; save(); started=time.time(); print('PULL',m,flush=True)
  response=post('/api/pull',{'model':m,'stream':False})
  if response.get('status')!='success':raise RuntimeError(str(response))
  show=post('/api/show',{'model':m},60)
  if 'tools' not in show.get('capabilities',[]):raise RuntimeError('No native tools capability: '+m)
  (root/'preparation'/('model-'+m.replace(':','_')+'.json')).write_text(json.dumps(show,indent=2))
  status['completed'].append({'model':m,'download_seconds':time.time()-started,'capabilities':show.get('capabilities'),'details':show.get('details')}); save()
  print('PULL_COMPLETE',m,show.get('details'),flush=True)
 status['status']='COMPLETE'; status['current']=None; save()
except Exception:
 status['status']='FAILED'; status['error']=traceback.format_exc(); save(); raise
