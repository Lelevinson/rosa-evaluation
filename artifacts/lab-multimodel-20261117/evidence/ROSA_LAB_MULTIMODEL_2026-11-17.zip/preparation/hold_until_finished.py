from pathlib import Path
import json,time
p=Path('/media/naeem/d1/marvel proj/results/operator-status.json')
deadline=time.monotonic()+32*3600
while time.monotonic()<deadline:
 s=json.loads(p.read_text())
 if s['phase'] in ('EXECUTION_COMPLETE','STOPPED'):break
 time.sleep(10)
print('Study finished or stopped; releasing temporary sleep inhibitor',flush=True)
