from pathlib import Path
import json
r=Path('results');s=json.loads((r/'operator-status.json').read_text());print('')
print('LIVE_PHASE='+s['phase'])
for tag,label in [('ministral-3_8b-instruct-2512-q4_K_M','Ministral'),('granite3.3_8b','Granite'),('qwen3.5_9b','Qwen'),('llama3.1_8b-instruct-q4_K_M','Llama')]:
 p=r/tag/'ollama/checkpoint.json'
 if p.exists():
  x=json.loads(p.read_text());print('LIVE '+label+': '+x['status']+' '+str(len(x['trials']))+'/80; calls='+str(x.get('live_model_requests',0)))
 else:print('LIVE '+label+': UNSTARTED')
if s.get('error'):print('LIVE_ERROR='+s['error'])
