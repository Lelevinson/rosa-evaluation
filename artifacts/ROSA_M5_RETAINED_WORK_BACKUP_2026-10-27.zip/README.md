# Robotics environment

**Current project overview:** [Improved ROSA master record and chatbot handoff](rosa-evaluation/PROJECT_MASTER_README.md).
It records goals, architecture, roadmaps, experiments, corrections and dated progress.
Refresh its checkpoint snapshot before sharing an active-run status.

## Historical setup and earlier checkpoints

The notes below preserve earlier milestones and installation instructions; they
do not describe the latest experiment or authorize rerunning system setup.

Earlier project direction: [Improved ROSA vision](rosa-research/PROJECT_VISION.md).
The separate
[interface, tracing and operation-limit repair milestone](rosa-evaluation/docs/POST_STAGE4_ENGINEERING_MILESTONE_2026-10-22.md)
now has [completed validation and a bounded Gazebo skill](rosa-evaluation/RELIABILITY_V1_RESULTS.md):
both backends passed 36/36 combined-system checks and all 72 persisted trace
audits passed. Qwen still attempted three writes with unavailable observations;
the shared guard blocked all three before dispatch.
This uses a limited single-joint fixture; added mechanisms did not improve
completion over the repaired reference. The results entry gives a reusable
PowerShell launcher for the deterministic controller and both LLMs.
The [published Stage 4 results](rosa-evaluation/STAGE4_RESULTS.md) are closed with
negative/inconclusive findings and a documented audit exception. Earlier status
notes below describe their historical checkpoints.

Requirements from `Improved_ROSA_Setup_Windows_WSL.pdf`: WSL2 Ubuntu 24.04,
ROS 2 Jazzy Desktop, developer tools, and Gazebo Harmonic through `ros-jazzy-ros-gz`.

For the initial system installation, run this command in Windows PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Proj\robotics\introtorobotics\setup-robotics.ps1"
```

Requires an existing Ubuntu-24.04 WSL2 distribution with a regular default user
(already present on this machine). The installer runs apt as Linux root, installs
the official ROS repository configuration, and can be rerun after a failure.
It adds ROS to the Linux user's `.bashrc` and creates `~/robotics_ws/src`.
It verifies ROS publisher/listener communication and a short headless simulation.

Open Ubuntu from PowerShell:

```powershell
wsl -d Ubuntu-24.04
```

In that Ubuntu terminal:

```bash
cd ~/robotics_ws
gz sim shapes.sdf
```

Press Play in Gazebo to run the world. GUI usability and real-time simulation
performance need an interactive check. `glxinfo -B` reports the graphics renderer.
The initial check on this machine reported `llvmpipe` and `Accelerated: no`;
GPU acceleration remains to be configured for better GUI performance.

The prepared research environment is separate from that system installer. You
do not rerun the installer to access it. Start the project services from this
workspace in Windows PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\rosa-research\scripts\start-research.ps1
```

Open Phoenix at http://localhost:6006 to inspect stored traces. In Ubuntu, enter
the evaluation repository and use its launcher; it selects the research uv
environment and sources ROS automatically:

```bash
cd /mnt/c/Proj/robotics/introtorobotics/rosa-evaluation
./run.sh research --mode controlled
```

The sibling repositories are [rosa-research](rosa-research/README.md) for the
modified ROSA implementation and [rosa-evaluation](rosa-evaluation/README.md)
for tracing, benchmarks and independent scoring. The evaluation results target
`member/martin`; see its [Stage 4 publication entry](rosa-evaluation/STAGE4_RESULTS.md).
Research implementation changes remain local and are preserved byte-for-byte in
the evaluation evidence snapshot.

Both local Qwen and the ChatGPT OAuth backend use the same ROSA interface.
OAuth prompts for browser consent each session and keeps renewable tokens in
memory until session cleanup. Stateful tests expose only simulated tools.
The latest [clean Stage 1–4 rerun report](reports/clean-stage1-4-20261021-r1/REVIEW_REPORT.md)
and [complete evidence archive](reports/ROSA_STAGE1_TO_4_CLEAN_RERUN_2026-10-21.zip)
cover 120 live trials across 12 distinct scenarios and 540 scripted controls.
Fresh baseline terminal handling was 24/36 for Qwen and 30/36 for the hosted
backend. Both verified all 18 achievable baseline goals. Repeated failure/unknown
handling problems remained, and one local conservative-cache trial timed out.
The report includes every live failure, full trial records, trace audits,
source snapshots, environment details and the limits of this pilot.

The earlier [test protocol](reports/gate4_protocol_2026-10-21.md),
[cache control results](reports/gate4_control_results_2026-10-21.md) and
[hosted results](reports/gate4_hosted_results_2026-10-21.md) describe the scope
and limitations. The [earlier comparison](reports/gate4_results_2026-10-21.md)
covers 120 live trials across 12 scenarios and 540 scripted control trials.
Qwen missed the provisional baseline usefulness target; conservative caching
saved eligible reads without a demonstrated end-to-end model speedup. Those
historical runs did not test original JTVR or episodic memory.

Official compatibility reference: https://gazebosim.org/docs/harmonic/ros_installation/

The historical [Phase 4 v2 protocol](PHASE4_V2_PLAN.md) preserves Baseline v1 and
separates retrospective contract checks, reliability interventions, inference
diagnostics and a frozen information-acquisition comparison. New code is under
`rosa-evaluation/experiments/phase4/`. A pass is an experimental decision with
measured benefit over simpler controls; implementing JTVR alone is insufficient.
The [v2 preflight status](reports/phase4-v2/PRELIVE_STATUS.md) records the validated
contract, scripted controls and local diagnostics. Its pending live batch was
closed before consent when the original JTVR specification arrived; no new live
trials ran. See the [revision notice](PHASE4_REVISION_NOTICE.md),
[original-spec comparison and proposed experiment](rosa-evaluation/docs/JTVR_SPEC_REVIEW_AND_MINIMAL_EXPERIMENT.md),
and [historical six-stage roadmap](rosa-evaluation/docs/PROJECT_ROADMAP_SIX_STAGES.md).
The fixed dependency bundle is not the original JTVR algorithm. Revised live
experiments need a fresh protocol and sign-in, with reliability kept separate.

The subsequent [three-algorithm report](rosa-evaluation/artifacts/stage4-policy-20261021/REPORT_FOR_CHATGPT.md)
compares greedy selection, strong amortized batching and the original JTVR
selection core: 1,152 audited policy episodes plus 15 audited real ROS parameter
episodes, with zero model requests. JTVR and batching tied on all 96 primary
fixtures. The predefined benefit criterion was not met; full JTVR model/Runnable
integration is paused for this catalogue. At that policy checkpoint, V2 live
reliability and actual model manifest quality were still untested and Stage 4
was incomplete. The subsequent completed live screen and its limitations are
documented in the Stage 4 results linked above. Baseline v1 and the earlier
frozen V2 sources are preserved.
