# ROSA project: update from the user and Codex

Date: 2026-10-20 (Asia/Taipei)

Please use this update when revising the v3.1 master plan. It records actual work completed and a new user clarification; it is not a claim of benchmark results.

## 1. User clarification: two interchangeable backend candidates

We intend to support and independently evaluate both:

- Local Qwen3.5 9B through its verified inference server.
- An available hosted OpenAI model accessed through the supported Sign in with ChatGPT OAuth flow.

Both are first-class candidates for future project use. Do not assume Qwen is the eventual production choice or treat the hosted model only as an optional reference. The choice should follow measured suitability for our tasks and operating conditions. OAuth is the access mechanism; the selected OpenAI model is the backend being evaluated.

“Interchangeable” means either backend can occupy the same application interface and receive equivalent task information and tool contracts. It does not mean identical capabilities, request parameters, sampling controls, latency, or availability.

Each backend needs its own baseline without JTVR or episodic memory. Run both on the same controlled scenario suite and independent evaluator once each is ready. Work on either backend can continue if the other is blocked; neither OAuth-first nor Qwen-first is a required global ordering. Qwen3.5 9B remains a required experimental candidate.

Report task success, claim accuracy, tool-call correctness, latency, model/tool effort, and operational failures separately. Also report overall completion across attempted tasks so quota or infrastructure failures do not disappear from the practical comparison. Record model identity, configuration, resource needs, access limits, and connectivity requirements. A winner may depend on the task and deployment constraints; no outcome is predetermined.

## 2. Existing repositories are the implementation foundation

- Research: https://github.com/Lelevinson/rosa-research
  - ROSA fork, model adapters, controlled tool integration, JTVR, and memory implementation.
  - Inspected commit: `18a5f2f962133a0bc490a2f2e79873ab6dca9b1d`.
- Evaluation: https://github.com/Lelevinson/rosa-evaluation
  - Experiment launchers, fixtures/scenarios, Phoenix tracing, scoring, metrics, and reports.
  - Inspected commit: `b3b1d45422331f41416bba55a6f569bf78bb60ab`.

Both are cloned as sibling directories under `C:\Proj\robotics\introtorobotics`. Adapt the master plan's proposed files to these repositories. Extend existing launchers, configuration, and environments instead of creating another project or duplicating the tracing system.

Codex created and pushed `member/martin` in `rosa-research`; the local research checkout is on that branch. The evaluation checkout is on `main`. Both currently have clean working trees. There have been no research implementation commits in this session.

## 3. uv and Phoenix status

Both repositories already contain uv configuration and lockfiles. There is no pending migration from pip requirements to uv.

- Installed uv 0.13.3 in Ubuntu at `/home/martin/.local/bin/uv`.
- Validated both the research and Phoenix lockfiles using `uv lock --check` with Ubuntu's `/usr/bin/python3` (Python 3.12.3).
- No dependency declarations or lockfiles were changed.
- The research and Phoenix `.venv` directories have not yet been created or synced in these checkouts.
- Phoenix has not been started or fully validated on this machine.

Keep Phoenix in its existing separate uv environment under `rosa-evaluation/tools/phoenix`. Keep ROS/Gazebo apt-managed and use the repositories' locked Python dependency workflow.

## 4. Evidence and remaining gaps

- October 15: Ubuntu 24.04/WSL2, ROS 2 Jazzy, and Gazebo Harmonic installation; ROS messaging and a short headless simulation passed. Present readiness still needs reconfirmation.
- That graphics check reported software rendering (`llvmpipe`). It did not establish GPU compute availability for model inference.
- All six evaluation configuration tests passed in Ubuntu. A Windows run encountered a Windows-path escaping error in one test; Ubuntu is the intended runtime.
- Existing controlled fixtures use scripted model responses. They test framework dispatch/tracing behavior, not live model competence.
- The current live launcher constructs `ChatOllama`; a hosted OAuth adapter is not implemented.
- Stateful research mocks, independent task scoring, the scenario pilot, JTVR, verified memory, OAuth login/tool round trips, and comparative results remain unimplemented or unverified.
- No credentials have been generated and no physical robot actions have been attempted.

## 5. Requested plan revision

Consolidate the conflicting roadmaps into one short operational plan that preserves the existing repos, member branch, uv environments, and Phoenix infrastructure. Establish both backend baselines through a common, strictly controlled tool boundary, then evaluate simple caching before more complex JTVR and memory interventions. Preserve non-privileged optimizer inputs, independent outcome evaluation, fixed-example memory controls, and held-out scenario discipline. Keep physical robot work outside the initial research commitment.
