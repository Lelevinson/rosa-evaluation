# ChatGPT OAuth readiness smoke: PASS

Date: 2026-10-20 (Asia/Taipei). This is a connectivity and structured-tool readiness test, not a research benchmark.

Later implementation: a [shared ROSA model adapter and probe](shared_rosa_interface_2026-10-20.md) now extend this native transport. The run below tested the native transport directly.

The user completed browser sign-in and consent. Identity validation, the ChatGPT plan-usage scope, account model discovery, streamed inference through `response.completed`, a native structured function call, and a tool-result continuation all passed. The selected model was `gpt-6.1-sol`, the first visible model returned by this account's catalog.

| Request | Wall time | Input/output tokens | Result |
| --- | ---: | ---: | --- |
| Text readiness | 2.83 s | 11 / 5 | `READY` |
| Structured mock tool call | 3.98 s | 81 / 23 | `mock_robot.get_robot_health`, robot ID `mock-robot` |
| Tool-result continuation | 2.72 s | 146 / 18 | Reported the supplied battery value, 73% |

No robot was connected or actuated. The tool returns a fixed in-memory fixture. This sequence does not test state changes, recovery, task planning, independent scoring, or repeated-run reliability. These timings cannot establish a winner against Qwen because the runners and prompts differ.

## Evidence

- Run: `af97cfc1-cd47-4ae3-9624-e9f382950f01`.
- [Sanitized request/result report](../rosa-evaluation/results/runs/af97cfc1-cd47-4ae3-9624-e9f382950f01/result.json).
- [Phoenix read-back export](../rosa-evaluation/results/runs/af97cfc1-cd47-4ae3-9624-e9f382950f01/phoenix/trace.json).
- Trace: `50b18216ad56824e42c4c5c50234b68e`; five spans, three LLM calls, one mock-tool dispatch, one root. The actual tool arguments and fixed result were read back from Phoenix.
- Root/tool OpenTelemetry status is `UNSET` (no error was recorded); application success is established by the report's explicit gates. The generic inspector's requested-tool-name list is empty because native LLM spans do not populate that optional attribute; the structured call is present in the result report.
- Nineteen offline OAuth/streaming regression tests and eight evaluation configuration/export tests passed.
- All eight controlled Phoenix integration cases passed after the export fix, including nested tools, errors, tracing disabled, and interruption: [validation evidence](../rosa-evaluation/results/validations/rosa-validation-026c8015/phoenix/verified.json). The research environment's 92 installed packages also passed the dependency compatibility check.

The first authenticated attempt exposed a local parser bug: completed stream item events contained the answer while the terminal response's output array was empty. The parser now retains completed items and requires `response.completed`; regression tests cover this. The successful run above used that fix. Read-back also exposed an exporter filter that omitted child spans without copied run metadata; export now locates the run and retrieves its full trace. The existing successful run was verified without repeating inference.

## Session handling and reproduction

Access, ID, and refresh tokens stayed in process memory. The refresh token was revoked at cleanup (`session_cleanup: REVOKED`); no tokens were written to disk, result reports, or Phoenix. Only the stable host ID, issued public client ID, and hashed account subject are retained in `~/.local/share/rosa-siwc/registration.json` with restricted permissions. This smoke runner intentionally requires browser consent each time.

From the Ubuntu terminal in `rosa-evaluation`, with Phoenix running:

```bash
./run.sh research --probe-siwc
```

Open the printed loopback sign-in link and complete consent. The runner selects the first visible catalog model unless `--model EXACT_SLUG` is supplied. It permits at most three inference requests and revokes the token session afterward. Offline checks:

```bash
# In rosa-research
uv run --locked python -m unittest discover -s tests -p test_siwc.py -v
```

## Remaining implementation

This proves the native OAuth transport works for this account and model. It is not yet a LangChain/ROSA hosted-model adapter or an interchangeable benchmark backend. Next, connect both candidates to the same agent interface and tool schema, then implement stateful task families with hidden-state scoring and matched evaluation settings. Cache/JTVR work remains later. Source changes are local and uncommitted on the member branches.

Implementation follows OpenAI's [sign-in contract](https://developers.openai.com/siwc/token-sharing-open-source/sign-in) and [model/inference contract](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference).
