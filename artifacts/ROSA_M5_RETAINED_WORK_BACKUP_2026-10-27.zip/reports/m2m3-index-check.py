"""Confirm Git's staged evidence bytes match the already-verified archive."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/mnt/c/Proj/robotics/introtorobotics/rosa-evaluation')
base = root / 'artifacts/macro-capabilities-m2m3-20261027'
manifest = json.loads((base / 'archive-manifest.json').read_text())['files']
command = ['git', '-c', 'safe.directory=' + str(root), '-C', str(root)]
entries = subprocess.check_output([*command, 'ls-files', '-s', '-z'], text=True).split('\0')
objects = {entry.split('\t', 1)[1]: entry.split()[1] for entry in entries if entry}
paths = {str((base / name).relative_to(root)): sha for name, sha in manifest.items()}
paths['artifacts/macro-capabilities-m2m3-20261027/archive-manifest.json'] = hashlib.sha256(
    (base / 'archive-manifest.json').read_bytes()).hexdigest()
reader = subprocess.Popen([*command, 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
try:
    for path, expected in paths.items():
        reader.stdin.write((objects[path] + '\n').encode())
        reader.stdin.flush()
        header = reader.stdout.readline().decode().split()
        size = int(header[2])
        content = reader.stdout.read(size)
        assert reader.stdout.read(1) == b'\n'
        assert hashlib.sha256(content).hexdigest() == expected, path
finally:
    reader.stdin.close()
    reader.wait(timeout=5)
print(json.dumps({'staged_evidence_files': len(paths), 'exact_archive_bytes': 'PASS'}))
