# Gate 4: controlled cache stress results

Date: 2026-10-21 (Asia/Taipei). No LLM was used in this batch. It is a mechanism/control result, not model task performance.

Batch `0df4a888-fce1-440a-b278-bc2f4fefb33f` completed 540 trials: 60 distinct seeded fixtures × three policies × three repetitions. [Raw report](../rosa-evaluation/results/runs/0df4a888-fce1-440a-b278-bc2f4fefb33f/result.json). Frozen manifest SHA-256: `11be0677513134803e42be7b0a353c7994ad194bfb76d7d2e0066ef55691066f`.

| Policy | Trials correctly handled | Eligible sensor reads | Mandatory reads | Cache hits | Stale cached observations |
| --- | ---: | ---: | ---: | ---: | ---: |
| No cache | 180/180 | 600 | 420 | 0 | 0 |
| TTL only | 180/180 | 360 | 480 | 300 | 120 |
| Conservative invalidation | 180/180 | 450 | 420 | 150 | 0 |

Each policy achieved the actual goal in 90 of 180 trials. The remaining task families require correct failure, unknown or refusal handling; they must not be counted as successful transfers. There were zero false/unsupported success claims, prohibited action attempts or unsafe mock executions for this public-observation scripted control.

All 540 saved execution records passed the separate [oracle/state audit](../rosa-evaluation/results/runs/0df4a888-fce1-440a-b278-bc2f4fefb33f/phoenix/oracle-audit.json), including independently reconstructed final state, action contracts, counts and stale-cache labels. Tracing was disabled for this control, so that artifact is not a Phoenix trace-completeness audit.

Conservative invalidation saved 150/600 eligible reads (25%) while keeping mandatory-read counts unchanged. TTL saved more eligible reads but served stale state and incurred 60 additional mandatory reads from rejected stale-revision attempts and their verification. The independent controller prevented those stale plans from becoming unsafe executions. That is evidence against using the naive cache as a reliable robot-state policy.

Across the 180 matched no-cache/conservative pairs, measured eligible sensor-backend time fell by an aggregate 7.61 seconds and measured lookup/pre-call policy computation totaled approximately 35.5 ms. Post-call cache writes/invalidation are included in end-to-end time but not that narrower policy counter. Sensor delays are injected fixture costs (zero or 100 ms); these are not measurements of real robotics sensors. Paired median end-to-end saving was approximately 29.7 ms, with simultaneous model workloads and ordinary machine activity introducing timing noise. Counts are the clearest mechanism result. No LLM calls were saved: the control uses none in every condition.

The repeated-read fixtures intentionally create redundant information requests to test the mechanism. They do not establish how often real tasks contain that redundancy. The cache applies only where policy permits observation reuse; requests requiring two independent fresh sensor measurements would need a bypass and are outside these cache-benefit claims.

This establishes that the simple conservative policy can reduce eligible observation work under the tested logical-time model without suppressing mandatory checks. It does not establish JTVR novelty, physical safety, live-model reliability, or a useful end-to-end LLM speedup. The live model/cache batches are separate evidence.
