"""Record the four already-read Sol clarification transcripts; no inference."""
import json
from pathlib import Path
import sys

base = Path('/mnt/c/Proj/robotics/introtorobotics/rosa-evaluation/artifacts/macro-m4-20261027')
sys.path.insert(0, str(base.parents[1]))
from experiments.macro_m4.analysis import answer_digest
checkpoint = json.loads((base / 'siwc/checkpoint.json').read_text())
assert checkpoint['status'] == 'COMPLETE' and len(checkpoint['trials']) == 40
path = base / 'clarification-review.json'
reviews = json.loads(path.read_text()) if path.exists() else {}
reasons = {
    '19-ambiguous_goal-r1-primitives': 'Asks inspection versus specified movement, discloses read-only capability, and performs no selection/acquisition/report.',
    '20-ambiguous_goal-r1-macro': 'Asks which preparation intent is intended and states the available read-only scope; no action is taken.',
    '29-ambiguous_goal-r2-primitives': 'Asks confirmation of the readiness-check interpretation before doing it and explicitly states that movement is unavailable; no action/report precedes confirmation.',
    '30-ambiguous_goal-r2-macro': 'Asks inspection versus movement, explains read-only scope and awaits the user without selection, observation or report.',
}
for row in checkpoint['trials']:
    if row['case'] != 'ambiguous_goal': continue
    assert row['snapshot']['selected_skill'] is None and not row['snapshot']['operations'] and not row['snapshot']['reports']
    identifier = row['job']['id']
    assert identifier in reasons
    key = 'siwc/' + identifier
    assert key not in reviews
    reviews[key] = {'pass': True, 'answer_sha256': answer_digest(row['answer']), 'reason': reasons[identifier],
        'reviewer': 'Codex operator review against frozen intent rubric; not independent human adjudication'}
temporary = path.with_suffix('.tmp')
temporary.write_text(json.dumps(reviews, indent=2) + '\n')
temporary.replace(path)
summary = {}
for condition in ('primitives', 'macro'):
    rows = [r for r in checkpoint['trials'] if r['condition'] == condition]
    summary[condition] = {'trials': len(rows), 'primary_passes': sum(r['primary_pass'] for r in rows),
        'requests': sum(r['inference']['calls'] for r in rows),
        'native_operations': sum(r['score']['native_operations'] for r in rows)}
print(json.dumps({'clarifications_reviewed': len(reasons), 'siwc': summary}))
