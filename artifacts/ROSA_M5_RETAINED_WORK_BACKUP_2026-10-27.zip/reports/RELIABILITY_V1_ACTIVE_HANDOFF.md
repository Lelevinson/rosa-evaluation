# Active task: four-step post-Stage 4 implementation

## FINAL: completed 2026-10-22 (supersedes every running checkpoint below)

All four steps completed within the explicitly limited one-joint Gazebo fixture.
Hosted36/36 and Qwen36/36 COMBINED final outcomes passed.64mock+8realGazebo
trials; all72Phoenix persisted span-ID sets match local real exports, all346LLM
spans match model request counters, all native/model caps respected.8runtime
tests+3ROSAintegration tests+16scripted controls passed before source freeze.
Matched deterministic reference2/2 and Linux AND exact Windows launcher demos
passed. OAuth REVOKED; owned simulator children exited0; local Qwen unloaded;
temporary sleep hold released. No batch or consent remains pending.

IMPORTANT QUALIFICATION: Qwen had9rejected calls in9trials:3UNKNOWN-state write
attempts (A/r1,C/r1,D/r0) all blocked before native dispatch, plus6reports lacking
the dedicated verifier record. No live schema errors. Hosted0rejections. Do not
call36/36error-free model behavior. Callsavings are exploratory and depend partly
on the verifier API policy; both A/D tie on completion, benefit screen not met.
Localmock A43calls/D38 at34nativeops each; localGazebo A12calls/8ops vsD9calls/7ops.

Canonical user review:
`rosa-evaluation/artifacts/RELIABILITY_V1_REPORT_FOR_CHATGPT_2026-10-22.md`.
Complete review bundle includes the unchanged sealed base ZIP + explicit safety
attribution JSON + consolidated report + generation source + manifest:
`ROSA_RELIABILITY_V1_COMPLETE_REVIEW_2026-10-22.zip`,4282779bytes,
SHA2569546d2bfb2dd371cbf694ba17b3b016728c9c6df90ece24606df0f0264c8117f.
BaseZIP4597373bytes,400manifestfiles,
SHA2562bd6963cd27e01df9e86df9a7f9fbd1d84dba03e52c3fb85d42d86ea717e51a5.
OriginalStage4all789manifestmembers still match. No historical score changed.
The explicit rejected-call addendum was produced after sealing; primary artifacts
were preserved byte-for-byte, not rewritten. Reports/verify_reliability_final.py
verified bothZIPs, caps,72traces,346LLMspans,400new+789oldfiles and cleanup.
Verificationreceipt: reports/RELIABILITY_V1_FINAL_VERIFICATION.json.

Reusable command from workspace:
`powershell -NoProfile -ExecutionPolicy Bypass -File .\rosa-evaluation\scripts\reliable-gazebo.ps1 -Backend deterministic`.
Useollama/siwc forLLMs;siwcrequiresfreshconsent. DefaultconfigurationAstrong
reference;Doptional. Demoheadless, savesrawrecords, cleansownsimulator.

CurrentfilesareLOCALandUNCOMMITTED;no new push was requested/performed for this
milestone. Evaluation remains onmember/martin with earlierStage4f8482ccpublished.
Research contains earlier user/session runtime changes plus new module; preserve
them. Source snapshots inbasearchive do not replace proper research publication.
Do not relaunch a completed campaign. Future changes need a separate version.

User explicitly authorized completing interface/tracing/limits repairs, fresh
validation, a deterministic Gazebo skill, and both LLM backends on that skill.
Do not stop at a proposal. Do not change closed Stage 4 evidence or re-score it.

## Latest active checkpoint (supersedes preparatory notes below)

NEWEST (~2026-10-21 19:28 UTC): hosted COMPLETE36/36, all passes/audits,
164modelcalls, OAuth REVOKED, both simulator children exit0. Qwen RUNNING11/36,
all task/report/audits pass so far; ~1minute/trial, unchanged partialGPUoffload.
Runtime metadata records qwen digest56671...,Q4_K_M,size6.4GB,VRAM3.49GB,
RTX4050Laptop6GB, low free RAM. Do NOT tune serving profile mid-run.

- Source freeze remains35files; new review.py/package.py/demo.py are post-freeze
  additions, not imported by frozen runner. DO NOT edit frozen35files.
- Durable finisher PID26109 (reports/finish_reliability.py) waits for pipeline
  completion, unloads exact Qwen model, stops sleep hold, runs independent review
  and seals ZIP automatically if pipeline/audits pass. Logs outside sealed
  artifacts: reports/RELIABILITY_V1_POSTPROCESS.log and _RECEIPT.json.
- Release-only watcher PID25998 also stops power hold after completion.
- Package destination artifacts/reliability-v1-20261022-evidence.zip. Do NOT
  modify any campaign members after sealing; analysis/report changes must be
  completed before the finisher seals, or a separate addendum/version afterward.
- Independent replay on hosted36 found0score/ledger/callback mismatches.
- Important interpretation found in local A/postwrite r0: correct fresh read,
  then SUCCESS was rejected solely because no dedicated verify_outcome record;
  model called verifier/resubmitted,7calls. B same case6calls due redundant read,
  no error. C/D5calls. Do NOT call missing named verifier a false physical claim.
  review.py explicitly documents this potential artificial API overhead and
  separates false-at-call-time claims from missing named records. No core or
  score was changed. Future contract may reuse fresh trusted read evidence.
- Report generator contains per-arm costs, independent call-time replay,
  benefit-screen decisions, full failure list and honest limitations. Both
  goals and fault handling scored separately. Host A/B/C/D all8/8mock; C/D
  use34nativeops vs A/B28; modelcalls36each. Nohostincrementalbenefit.
- Need still: monitor Qwen until36, final independent persisted Phoenix72trace
  equality, finisher results/ZIP verification; run deterministic user demo
  AFTER live to avoid load confound. scripts/reliable-gazebo.sh provided; demo
  is new/unfrozen and not yet exercised. Then update current-status docs outside
  sealed artifacts and final concise report links + command. No new Git push
  requested in latest instruction; research changes remain local.

- User completed fresh OAuth consent. Hosted batch RUNNING, first12/36 all
  task/report and trace audits passed; no source or protocol retuning allowed.
- Detached supervisor PID25637, operator reports/reliability_pipeline.sh.
  `artifacts/reliability-v1-20261022/pipeline.log`, per-backend result.json and
  per-trial evidence/trace. Hosted then local then independent Phoenix audit.
- The first operator launcher failed before any auth/model request due to ROS
  setup under set-u; preserved as pipeline-startup-failure-1.log and supervisor
  startup JSON. Operator wrapper corrected; frozen runtime unmodified.
- Final prerequisites:8unit tests,3integration tests including actual ROSA
  controlled-stop Phoenix span,16scripted case/arm controls,7persisted development
  traces (closed trees) passed. Exact35-file source snapshot frozen.
- Temporary Windows sleep/resource monitor PID10748 writes campaign power-hold
  and resource CSV. MUST create campaign/monitor.stop and verify power-release.json
  when batch finishes (also on failure). No saved power-plan changes.
- Added user guide src/rosa_reliability/README.md and separate interactive
  eval module experiments/reliability_v1/demo.py plus scripts/reliable-gazebo.sh
  AFTER freeze. These are not imported by the frozen batch. Demo not yet tested;
  run deterministic once after live testing (avoid simulator load during trials).
- Keep monitoring <60s commentary cadence. No remaining user input is pending.
- Need final detailed report, independent artifact/source/trace audit, matched
  results and status/README updates; DO NOT claim benefit if simple reference ties.

Working implementation (2026-10-22): new optional research package
`rosa-research/src/rosa_reliability/{execution,tools,ros_joint}.py`, assets in
`sim/{arm.sdf,bridge.yaml}`. Uses actual ROSA AgentExecutor with four custom-only
tools; no frozen historical runtime modules changed except research pyproject
package-data metadata. Existing research changes are user-owned/unpublished.

Evaluation: `rosa-evaluation/experiments/reliability_v1/` modules cases, tracing,
simulator, runner, prepare. Protocol `docs/RELIABILITY_V1_PROTOCOL_2026-10-22.md`.
Artifacts planned `artifacts/reliability-v1-20261022/`, 36 trials/backend:
32 mock = four fresh fixtures x four arms x two repetitions; four Gazebo trials
= two cases (move, accepted/no motion) x A/D. 288 model requests/backend max,
8/trial, 180sec/trial, 3hr/backend. Source MUST be frozen using prepare before
any live trials. No live model calls have been made yet at this checkpoint.

Focused research unit tests: 8 passed initially; modified since, rerun necessary.
Actual ROSA integration tests: 2 passed, including 16 scripted controls and
real Phoenix export with recoverable errors. Final review/freeze still pending.
Gazebo development probe2: 3 independent pose checks passed plus correctly
detected suppressed command; simulator/bridge children exited0. Probe1 failed
ROS executor context startup; preserved, fixed with explicit per-context
SingleThreadedExecutor. Probe records under artifacts/reliability-v1-development.

WSL requires sandbox escalation (`require_escalated`), auto-approved earlier.
Use shell script paths to avoid PowerShell stripping nested native quotes.
Research Python `/home/martin/.local/share/rosa-envs/research/bin/python`;
Phoenix Python `/home/martin/.local/share/rosa-envs/phoenix/bin/python`.
Source `/opt/ros/jazzy/setup.bash` to find vendor gz; Gazebo8.15.0 present.
Ollama endpoint from eval .env currently http://172.31.0.1:11434 (not yet probed).
Phoenix service currently running at loopback6006. No new deps installed.

Important next work:
- Finish fresh deterministic tests and record logs; add real controlled-stop
  Phoenix integration test if needed. Audit compares real ended explicit spans,
  normal LangChain starts/terminal callbacks and LangChain exported tool spans.
- Check hosted transport token_provider wiring (now fixed to auth.access_token).
- Check observed-value reporting tolerance0.015 declared in protocol; null
  represents unavailable evidence; no sentinel guessing or automatic repair.
- Runtime automatically verifies only after writes; all arms retain explicit
  verify_outcome. Write prerequisites and strict report gates shared.
- Runner limits one write/session (write_limit=1); JointTransport direct writes
  used only deterministic/outside-trial reset.
- Freeze, then launch hosted consent runner and local sequentially (prepare
  durable wrapper, capture logs/status). Need fresh browser OAuth sign-in.
- Do NOT rerun frozen failed trials or mutate frozen source after live begins.
- Validate Phoenix persisted span IDs independently using separate Phoenix env;
  local exporter success alone is insufficient. Existing helper
  tools.phoenix.inspect_trace.fetch can select metadata.run_id or use trace IDs.
- Run both backends; export/score honestly and make detailed final report,
  including limitations (single-axis fixture, small pilot, prose not exhaustively
  graded, no novelty/general small-model claim). Keep all prior evidence hashed.
- User did not explicitly request a new push in this latest message. Do not
  accidentally publish all existing uncommitted research changes.
