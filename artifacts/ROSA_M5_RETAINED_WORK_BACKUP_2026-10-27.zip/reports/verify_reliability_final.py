"""Read-only verification of primary/new review bundles and preserved Stage 4."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

workspace = Path(__file__).resolve().parents[1]
root = workspace / 'rosa-evaluation'
campaign = root / 'artifacts/reliability-v1-20261022'
base = root / 'artifacts/reliability-v1-20261022-evidence.zip'
review = root / 'artifacts/ROSA_RELIABILITY_V1_COMPLETE_REVIEW_2026-10-22.zip'
verified = {}
for archive in (base, review):
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert digest == archive.with_suffix('.sha256').read_text().split()[0]
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        name = 'artifacts/reliability-v1-20261022/evidence-manifest.json' if archive == base else 'manifest.json'
        manifest = json.loads(z.read(name))
        assert all(hashlib.sha256(z.read(k)).hexdigest() == v for k,v in manifest.items())
        if archive == base:
            assert all(hashlib.sha256((root/k).read_bytes()).hexdigest() == v for k,v in manifest.items())
    verified[archive.name] = {'sha256': digest, 'manifest_members': len(manifest), 'bytes': archive.stat().st_size}
old = json.loads((root/'artifacts/stage4-batching-completion-20261021/evidence-manifest.json').read_text())
assert all(hashlib.sha256((root/k).read_bytes()).hexdigest() == v for k,v in old.items())
analysis = json.loads((campaign/'analysis.json').read_text())
assert not analysis['independent_replay_failures']
assert all(x['status']=='COMPLETE' and x['completed_trials']==36 for x in analysis['backends'].values())
phoenix = json.loads((campaign/'phoenix-audit.json').read_text())
assert phoenix['pass'] and len(phoenix['traces'])==72
assert all(x['exact_span_ids_match'] and x['closed_tree'] for x in phoenix['traces'])
replay = json.loads((campaign/'independent-replay.json').read_text())
assert len(replay)==72 and all(r['independent_replay']['llm_span_count_matches_model_callback_count'] for r in replay)
assert all(r['score']['native_operations']<=10 and r['model_calls']<=8 for r in replay)
assert all(r['independent_replay']['accepted_critical_writes']==0 for r in replay)
assert (campaign/'power-release.json').exists()
assert json.loads((campaign/'local-model-cleanup.json').read_text())['done_reason']=='unload'
missing=[]
for file in (root/'RELIABILITY_V1_RESULTS.md', root/'docs/POST_STAGE4_ENGINEERING_MILESTONE_2026-10-22.md'):
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', file.read_text(encoding='utf-8-sig')):
        if not target.startswith(('http:', 'https:', '#')) and not (file.parent/target.split('#')[0]).exists():
            missing.append(target)
assert not missing, missing
demo = sorted((root/'artifacts/reliability-demos').glob('*/result.json'))[-1]
assert json.loads(demo.read_text())['completed_verified_task']
result = {'archives': verified, 'preserved_stage4_members': len(old), 'audited_live_traces': 72,
          'llm_spans_match_recorded_requests': sum(r['model_calls'] for r in replay),
          'all_caps_respected': True, 'windows_launcher_demo_verified': str(demo.relative_to(root)),
          'blocked_unknown_write_attempts': 3, 'accepted_critical_writes': 0,
          'temporary_sleep_hold_released': True, 'local_model_unloaded': True,
          'files_are_local_not_newly_pushed': True}
(workspace/'reports/RELIABILITY_V1_FINAL_VERIFICATION.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
