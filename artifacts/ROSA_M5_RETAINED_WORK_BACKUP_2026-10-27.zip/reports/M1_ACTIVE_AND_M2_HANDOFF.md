# M1 final handoff, 2026-10-27

User authorized M1 and chose remembered OAuth across restarts with explicit
sign-out. Both implemented; stop at M1 boundary. Memory/JTVR/teammate-package
migration remain deferred. No live model requests or real authorization used.

Read `rosa-evaluation/artifacts/macro-module-v1-20261027/M1_ACCEPTANCE_REPORT.md`.
Public numeric-state API: `rosa_reliability.bounded_macro`; public opt-in ROSA
integration: `rosa_reliability.macro_agent`. Internal prototype version 0.1.0.
Docs/spec: `rosa-research/docs/MACRO_MODULE_V1_*.md`.

Validation: 276 regression test executions in offline-04 passed; final focused
36 methods passed (overlap, do not sum), with final malformed-budget assertions
confirmed in offline-05. Final scripted-03:12/12,543 exact persisted spans.
Gazebo-01:7/7,87 exact persisted spans, independent observer, normal cleanup.
Package-03 wheel installed in empty target using existing pinned dependencies.
Earlier fixture, Phoenix-offline and uv-PATH failures remain on disk.

OAuth: new optional `rosa_auth.remembered.remembered_session`; Windows-user DPAPI
refresh-only record, Windows profile lease, existing renewal/scope validation,
manual initial consent, no auto-popup on invalidation, explicit CLI logout.
Actual synthetic DPAPI/lease checks passed;12 offline protocol methods passed.
REAL PROVIDER RESUME NOT TESTED; no real remembered grant provisioned. Future
hosted run should explicitly use remembered_session, not the old frozen runner.
Default interactive_session remains unchanged and revokes on exit. Do not ask
the persistence preference again; user already chose it. Instructions:
`rosa-research/docs/REMEMBERED_CHATGPT_AUTH.md`.

M2 candidate: read-only arm/controller-readiness inspection. Actual configured
arm controllers observed; generic gripper/MoveIt software installed but no
working gripper demonstrated. Two poses remain ONE capability. No M2 started.
Original macro-focus-v2 still69/72,incomplete; no hidden continuation or rescoring.
Both repos member/martin, old dirty work retained, no staging/commit/push in M1.
