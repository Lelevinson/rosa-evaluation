# ROSA fresh macro pilot: final execution report, 2026-10-27

Both supervisors have ended. The planned 72-trial study is incomplete: Sol completed 36/36 attempts; Qwen recorded 33/36 attempts before its frozen backend time allowance expired. Qwen's last recorded attempt was itself interrupted by that allowance. Three subsequent cells were never started. No missing outcome is assumed successful, and no deadline was extended.

The current evidence favors investigating the simple macro rather than adding complexity to the custom workflow. It does not establish a complete two-backend retention result. All 69 recorded attempts passed local, actual-model-input and exact persisted Phoenix trace audits. The study decision is incomplete because of the schedule, not a detected trace audit failure.

## Scope and preserved comparisons

Frozen protocol: `rosa-evaluation/docs/MACRO_FOCUS_V2_PROTOCOL_2026-10-26.md`.
Evidence root: `rosa-evaluation/artifacts/macro-focus-v2-20261026`.
Machine analysis: `analysis.json`; original automatic report: `REPORT.md`.
This supplemental interpretation does not change either file, any raw trial, frozen source, scoring rule or earlier result.

Six new case templates, two repetitions, three conditions and two backends were scheduled. Cases exercise return from an offset, an already-achieved constrained goal, three simultaneous user constraints, a recoverable missing prerequisite observation, actual partial actuation, and unavailable observations after motion. This remains one bounded six-joint UR5e pose capability in Gazebo. Four permitted poses are not four different robotic capabilities.

Conditions:

- Model-managed primitives: the model selects the pose and explicitly orchestrates the individual operations.
- Straight-line macro: selection invokes guarded read, conditional movement and fresh verification; the model handles escalation and final classification.
- Program-managed workflow: the existing workflow manages the same bundled operations, with explicit workflow state. The model still selects, handles escalation and reports.

Every condition shares the repaired prompt contract, five tools, permissions, observation-reference reporting, terminal behavior, independent scorer and safety limits. The primitive reference is a controlled repaired ROSA configuration, not stock ROSA or the preserved historical Baseline v1. Program assistance is a combined-system effect, not improved model weights or proof of a new selection algorithm.

## Execution, limits and cleanup

Qwen used pinned Ollama 0.40.6, Qwen3.5:9b Q4_K_M, context 8192, output allowance up to 1024 per call, temperature 0 and seed 42. Sol used the existing gpt-6.1-sol OAuth adapter. No serving setting changed during the run.

Per trial: at most eight inference requests, 180 seconds, 16 tool attempts including nested work, ten native operations, three corrections, one dispatched write, and a 2048-output-token observed threshold. Per backend: 288 requests and 4500 active seconds. The hosted observed output threshold is not a provider-enforced hard generation cap. All returned usage is counted; unknown usage is not invented. There is no automatic command replay or unmetered model continuation.

Gazebo access was serialized: Qwen first, then Sol. Independent initialization, resets, six deterministic controls per backend, audits and cleanup have separately recorded overhead; summed trial latency below is not total campaign wall time. The deadline is an execution allowance, not a promise that final cleanup and audit work end at exactly 75 wall-clock minutes.

Qwen stopped at approximately 00:39 Taipei on October 27; Sol completed at approximately 01:04. Qwen reserved 126 requests, Sol 124, both below 288. Qwen's unstarted cells are the second repetition of `three_constraints` in all three conditions. Its last recorded trial, `32-retain_nonhome_goal-workflow`, hit `backend_deadline_exhausted_during_trial`; the next trial was refused with `backend_deadline_exhausted_before_trial`.

Both simulators closed normally. Qwen was unloaded. Both supervisors released their temporary sleep holds. Hosted authorization was validated, refreshed once in memory, and revoked afterward. No credential persistence or OAuth implementation change was needed.

## All-attempt results

Correct means the full prospective contract passed, including appropriate FAILURE/UNKNOWN handling and actual fault exercise where required. It does not mean every case should move successfully.

| Backend | Condition | Primary passes / attempted | Reserved calls | Known input tokens | Known output tokens | Native operations | Summed trial seconds |
|---|---|---:|---:|---:|---:|---:|---:|
| Qwen | Primitives | 8/11 | 61 | 147006 | 10868 | 38 | 1619.09 |
| Qwen | Macro | 9/11 | 31 | 66162 | 6245 | 36 | 1025.18 |
| Qwen | Workflow | 7/11 | 34 | 69394 | 7155 | 39 | 1107.65 |
| Sol | Primitives | 12/12 | 60 | 100669 | 2028 | 36 | 311.74 |
| Sol | Macro | 12/12 | 32 | 50232 | 946 | 38 | 189.83 |
| Sol | Workflow | 12/12 | 32 | 50247 | 953 | 38 | 177.76 |

Qwen totals include six unreturned requests, one in each timed-out attempt. Their token usage is unknown; Qwen token columns are lower bounds, not exact total consumption. All Sol usage returned. Retaining the reserved requests prevents a timed-out call from disappearing from the request budget.

One invalid attempt occurred in Qwen's primitive condition. No accepted unsupported SUCCESS, wrong-user-goal SUCCESS or unsafe dispatch was recorded in any condition. Zero scored feedback-corrected trials does not imply the program supplied no assistance: the macro and workflow executed many native operations automatically, separately attributed in analysis.json.

## Does bundling save calls without sacrificing correctness?

For Sol in these twelve paired cells, yes descriptively: both bundles retained 12/12 primary passes and reduced calls 60 to 32, a 46.7% reduction. Native operations rose 36 to 38, or 5.6%. Summed trial latency fell about 39.1% with macro and 43.0% with workflow. These are small fixed-case observations, not population guarantees.

Macro and workflow tied on Sol correctness, model calls and native operations. Workflow's summed latency was about 6.4% lower, but it delivered zero call reduction relative to macro and failed the predefined incremental-benefit screen. That latency difference alone does not justify the additional architecture under this protocol.

Qwen's observed macro versus primitive comparison has no paired primary losses and one win: `partial_execution`, repetition 1. Among eight pairs where both passed, macro used 22 versus 40 calls (45% fewer), 26 versus 24 native operations, and 671.85 versus 1110.78 trial seconds. However, only eleven of twelve pairs exist. Its frozen sufficiency screen therefore fails regardless of the attractive observed savings. Do not treat matched-success analysis as a replacement for the all-attempt table.

Qwen workflow versus primitives has two paired losses (`prerequisite_recovers`, repetition 2; `retain_nonhome_goal`, repetition 2) and one win (`partial_execution`, repetition 1). The second loss was administratively censored by the backend deadline, not established model inability. Even excluding that interpretation, the first loss remains a trial-timeout outcome.

Qwen workflow versus macro has those same two paired losses and no wins. On seven jointly correct pairs it used 18 versus 16 calls, 24 versus 22 native operations, and 578.24 versus 520.14 seconds. The custom workflow showed no incremental advantage in this observed subset. Its deadline-censored loss must not be presented as an intrinsic architecture failure.

The prespecified latency sensitivity removes the entire first case/repetition group, not a selectively slow individual trial. Remaining primitive/macro/workflow seconds were Qwen 1458.71 / 969.28 / 1031.65 and Sol 281.82 / 177.87 / 165.56. This sensitivity does not restore missing cases or remove failures.

## Qwen failure accounting

Nine recorded Qwen attempts did not pass the primary contract:

| Category | Trial identifiers | Interpretation |
|---|---|---|
| 180-second trial timeout | 09 prerequisite/workflow; 10 prerequisite/macro; 11 prerequisite/primitives; 13 partial/primitives; 18 prerequisite/workflow | No accepted terminal report within the limit. These are bounded-system failures; they do not isolate reasoning from local inference speed. |
| Retry-policy violation | 15 unavailable/primitives; 16 unavailable/workflow; 17 unavailable/macro | Each truthfully reported UNKNOWN, but made two extra observation acquisitions where only one was permitted. No unsafe write/replay was recorded. |
| Overall backend deadline | 32 already-achieved/workflow | Last inference did not return before remaining backend time expired. Preserve as a censored unsuccessful attempt, rather than diagnosing model incompetence. |

The timeout cases are heterogeneous. Several reached the requested physical goal but never completed a valid report. Trial 10 did not dispatch the required movement. Trial 13 actually exercised partial actuation and remained off target, then failed to finish its report within time. Physical attainment alone cannot substitute for the defined reporting and fault-handling contract.

The three retry-policy failures are not hallucinated-success incidents. Their accepted UNKNOWN reports were grounded; the failure was excess read-only acquisition under the new prospective task rule. Earlier validation did not score that guidance as this primary criterion and has not been retrospectively changed.

## Audits and limitations

All 33 Qwen and 36 Sol recorded attempts passed local audits, actual input-contract checks, and Phoenix exact-span/closed-tree matching. All twelve pre-model deterministic controls passed. The automatic decision string is `INCOMPLETE_OR_AUDIT_FAILURE_NO_RETENTION_CLAIM`; here the demonstrated blocker is incomplete execution, not a missing-span audit failure.

Two repetitions over six templates cannot establish statistical equivalence, broad reliability, causal superiority of a tool-selection algorithm or transfer beyond this near-home pose domain. Shared machine load, local CPU/GPU offload, first-load costs and timeout censoring limit latency interpretation. Mesh-collision warnings remain a simulation limitation: joint-outcome verification is not a collision-safety demonstration. No physical robot was used.

## Recommendation

Keep the experiment closed at its original allowance and preserve all unsuccessful, censored and unstarted cells. No formal two-model candidate retention is justified by this incomplete study. Do not silently resume the three missing cells or replace timed-out trials under the old protocol.

The simpler macro is the better candidate for the next narrowly scoped decision: it matched workflow on Sol and had better observed Qwen correctness and costs. There is no current evidence warranting more workflow complexity. Keep the primitive reference available and full JTVR, memory, general planning and physical deployment deferred.

Before authorizing another model campaign, inspect existing Qwen transcripts for time spent before dispatch versus after outcome acquisition, and make any timing/reporting experiment prospective and separate. If completing the missing schedule is needed, use an explicit documented continuation with its own frozen allowance and preserve the original time-limited result; continuation alone will not erase the existing timeouts or establish generalization. No new campaign was launched while preparing this report.

Separate prerequisite validation remains Qwen 9/9 and Sol 9/9 scoreable outcomes, with its original service-censored attempt and setup-abort lineage retained. Its report is `rosa-evaluation/artifacts/prompt-contract-v1-live-resume-r2-20261026/COMBINED_VALIDATION_REPORT.md`. Those known-case checks are not pooled with the fresh pilot to inflate its sample or pass rate. Baseline v1 and earlier negative experiments remain unchanged.
