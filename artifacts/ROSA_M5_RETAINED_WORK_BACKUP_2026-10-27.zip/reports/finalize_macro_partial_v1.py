"""Audit and seal an explicitly INCOMPLETE campaign without changing scores."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
CAMPAIGN = ROOT / 'rosa-evaluation/artifacts/macro-transfer-v1-20261022'
ARCHIVE = CAMPAIGN.parent / 'ROSA_MACRO_TRANSFER_V1_PARTIAL_EVIDENCE_2026-10-23.zip'
QUOTA = 'subscription_sharing_usage_limit_exceeded'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    sys.path.insert(0, str(ROOT / 'rosa-evaluation'))
    from experiments.macro_transfer_v1.design import catalogue, cases, jobs
    from experiments.macro_transfer_v1.scoring import score
    specs = {s['id']: s for s in cases()}
    freeze = read(CAMPAIGN / 'freeze.json')
    states, rows, checks, infrastructure, missing = {}, [], [], [], []
    source_members = {}
    for name, value in freeze['files'].items():
        copied = CAMPAIGN / 'source' / name
        assert digest(copied.read_bytes()) == value
        assert digest((ROOT / name).read_bytes()) == value, name
        source_members[copied.relative_to(ROOT).as_posix()] = value
    for backend in ('ollama', 'siwc'):
        folder = CAMPAIGN / 'gazebo' / backend
        state = read(folder / 'checkpoint.json')
        states[backend] = state
        assert state['status'] == ('COMPLETE' if backend == 'ollama' else 'STOPPED')
        assert state['total_model_calls'] <= 144
        assert state['simulator_cleanup']['returncode'] == 0
        assert read(folder / 'fresh-controls/result.json')['pass']
        assert read(CAMPAIGN / 'operator' / (backend + '-power-release.json'))['released']
        assert read(CAMPAIGN / 'operator' / (backend + '-supervisor.json'))['status'] == state['status']
        for row in state['trials']:
            trial = folder / row['run_id']
            raw = read(trial / 'evidence.json')
            assert row == read(trial / 'result.json')
            assert row['audit']['pass'] and read(trial / 'phoenix-audit.json')['pass']
            local = read(trial / 'trace.json')['spans']
            persisted = read(trial / 'phoenix-trace.json')
            ids = lambda spans: {s['context']['span_id'].removeprefix('0x') for s in spans}
            assert ids(local) == ids(persisted)
            assert all(s.get('end_time') and (not s.get('parent_id') or
                       s['parent_id'].removeprefix('0x') in ids(persisted)) for s in persisted)
            assert row['inference']['calls'] <= 8 and row['native_operations'] <= 10
            assert not row['score']['accepted_unsupported_selected_goal_success']
            assert not row['score']['dispatch_violations']
            selected = raw['session']['selected_skill']
            reconstructed = SimpleNamespace(snapshot=lambda: raw['session'],
                selected_skill=selected, targets=catalogue('gazebo')[selected or 'pose_amber'])
            rescored = score(reconstructed, specs[row['case']], SimpleNamespace(records=raw['transport_records']),
                row['answer'], raw['claim_time_oracles'], catalogue('gazebo'), .025, raw['private_final_state'])
            assert rescored == row['score'], row['run_id']
            assert len(raw['session']['operations']) == row['native_operations']
            is_quota = backend == 'siwc' and QUOTA in row['answer']
            if is_quota:
                assert not row['inference']['usage_complete'] and row['inference']['calls'] == 1
                assert row['native_operations'] == 0 and row['tool_attempts'] == 0
                assert state['authorization_or_service_unavailable']['code'] == QUOTA
                infrastructure.append({'backend': backend, 'run_id': row['run_id'],
                    'case': row['case'], 'condition': row['condition'],
                    'reason': QUOTA, 'request_attempts': 1,
                    'known_generated_tokens': row['inference']['known_output_tokens'],
                    'actual_token_usage': 'UNKNOWN_NO_USAGE_RETURNED', 'output_upper_bound': None})
            else:
                assert row['inference']['usage_complete']
            rows.append({**row, 'review_classification': 'QUOTA_INTERRUPTED' if is_quota else 'SCOREABLE'})
            checks.append({'backend': backend, 'run_id': row['run_id'],
                'saved_score_recomputed': True, 'exact_persisted_spans': True,
                'classification': 'QUOTA_INTERRUPTED' if is_quota else 'SCOREABLE'})
        attempted = {(r['case'], r['condition']) for r in state['trials']}
        missing.extend({'backend': backend, 'case': j['case']['id'], 'condition': j['condition'],
                        'status': 'NOT_STARTED'} for j in jobs('gazebo')
                       if (j['case']['id'], j['condition']) not in attempted)
    assert len(rows) == 33 and len(infrastructure) == 1 and len(missing) == 3
    assert read(CAMPAIGN / 'preflight/result.json')['pass']
    assert read(CAMPAIGN / 'deterministic-preflight/result.json')['pass']
    assert read(CAMPAIGN / 'deterministic-preflight/cleanup.json')['returncode'] == 0
    assert read(CAMPAIGN / 'session-siwc.json')['auth']['session_cleanup'] == 'REVOKED'
    assert read(CAMPAIGN / 'local-model-unload.json')['done_reason'] == 'unload'
    assert read(CAMPAIGN / 'operator/finalizer-status.json')['status'] == 'STOPPED'
    summaries = []
    for backend in states:
        for condition in ('model', 'macro', 'workflow'):
            attempted = [r for r in rows if r['backend'] == backend and r['condition'] == condition]
            valid = [r for r in attempted if r['review_classification'] == 'SCOREABLE']
            summaries.append({'backend': backend, 'condition': condition, 'planned': 6,
                'scoreable': len(valid), 'correct': sum(r['score']['pass'] for r in valid),
                'attempted_calls_including_quota': sum(r['inference']['calls'] for r in attempted),
                'scoreable_calls': sum(r['inference']['calls'] for r in valid),
                'known_input_tokens': sum(r['inference']['known_input_tokens'] for r in attempted),
                'known_output_tokens': sum(r['inference']['known_output_tokens'] for r in attempted),
                'censored_attempts': sum(not r['inference']['usage_complete'] for r in attempted),
                'native_operations': sum(r['native_operations'] for r in attempted),
                'invalid_attempts': sum(r['score']['invalid_attempts'] for r in attempted),
                'scoreable_seconds': sum(r['wall_seconds'] for r in valid)})
    lookup = {(r['backend'], r['case'], r['condition']): r for r in rows}
    paired = {}
    for backend in states:
        complete_cases = [s['id'] for s in cases() if all((r := lookup.get((backend, s['id'], c))) and
                          r['review_classification'] == 'SCOREABLE' for c in ('model', 'macro', 'workflow'))]
        paired[backend] = {'complete_three_condition_cases': complete_cases,
            'cells': {condition: {'correct': sum(lookup[backend, case, condition]['score']['pass'] for case in complete_cases),
                'calls': sum(lookup[backend, case, condition]['inference']['calls'] for case in complete_cases),
                'native': sum(lookup[backend, case, condition]['native_operations'] for case in complete_cases)}
                for condition in ('model', 'macro', 'workflow')}}
    resume = {'campaign_status': 'INCOMPLETE_QUOTA_STOP', 'resume_now': False,
        'reason': QUOTA, 'preserve_original_attempts_and_scores': True,
        'requires_new_manual_consent_after_quota_available': True,
        'remaining_cells': [{**infrastructure[0], 'new_attempt_required': True}, *missing],
        'maximum_additional_requests': 32, 'prior_hosted_requests': 43,
        'maximum_combined_hosted_requests_with_this_extension': 75,
        'continuation_requirement': 'Separate versioned continuation protocol and output folder; same frozen treatments/settings/cases/scoring and fresh simulator reset. Do not run the original full backend command into the populated folder.'}
    result = {'campaign_complete': False, 'stop_reason': QUOTA,
        'audited_attempt_records': len(rows), 'scoreable_trials': 32,
        'infrastructure_interrupted': infrastructure, 'unstarted': missing,
        'summaries': summaries, 'complete_case_pairs': paired, 'checks': checks,
        'frozen_sources_verified': len(source_members),
        'audit_exception': 'Shared default system instructions require unavailable discovery tools and conflict with the bounded select-first contract.',
        'raw_primary_scores_unchanged': True}
    (CAMPAIGN / 'PARTIAL_AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
    (CAMPAIGN / 'RESUMPTION_PLAN.json').write_text(json.dumps(resume, indent=2) + '\n')
    lines = ['# ROSA macro comparison: audited partial checkpoint', '',
        'Status: INCOMPLETE. User-local date: 2026-10-23 (Asia/Taipei). The historical campaign '
        'name retains its 2026-10-22 UTC freeze date. The hosted service stopped at 00:19:53 '
        'Taipei time with subscription_sharing_usage_limit_exceeded. This was a quota stop, '
        'not a laptop shutdown or loss of the saved experiment.', '',
        'Qwen completed18/18 planned trials. Sol completed14 scoreable trials, all correct; '
        'one further trial was quota-interrupted before any tool/native operation, and three '
        'were never started. All33 saved attempt records passed local/persisted-span audits '
        'and their saved primary scores were recomputed exactly. No frozen score was changed.', '',
        '## Outcomes and costs', '',
        '| Backend | Condition | Correct / scoreable | Scoreable calls | All attempted calls | Native | Invalid | Known input tokens | Known output tokens | Censored | Trial seconds (scoreable) |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for r in summaries:
        lines.append(f'| {r["backend"]} | {r["condition"]} | {r["correct"]}/{r["scoreable"]} | '
            f'{r["scoreable_calls"]} | {r["attempted_calls_including_quota"]} | {r["native_operations"]} | '
            f'{r["invalid_attempts"]} | {r["known_input_tokens"]} | {r["known_output_tokens"]} | '
            f'{r["censored_attempts"]} | {r["scoreable_seconds"]:.2f} |')
    lines += ['', 'Each condition originally planned six trials. Sol denominators differ; do not '
        'compare its unequal condition totals as a completed paired benchmark. Token totals '
        'are known lower bounds where censored: the quota-interrupted request returned no '
        'usage and is not assumed zero-cost. All125 inference attempts count against the '
        'resource ledger (82 Qwen,43 hosted). Native operations include failed observations.', '',
        '## Complete-case paired comparison', '', '```json', json.dumps(paired, indent=2), '```', '',
        'For Sol, only the first four cases form complete three-condition pairs. All four '
        'passed in every condition:19 primitive-tool calls versus8 macro and8 workflow calls. '
        'The missing-prerequisite case has model/macro outcomes but no scoreable workflow '
        'outcome. No Sol transient-after-motion trial started. There is no full Sol retention result.', '',
        '## Per-case status', '', '| Backend | Case | Primitive tools | Macro | Workflow |',
        '| --- | --- | --- | --- | --- |']
    for backend in states:
        for spec in cases():
            cells = []
            for condition in ('model', 'macro', 'workflow'):
                row = lookup.get((backend, spec['id'], condition))
                cells.append('NOT STARTED' if row is None else 'QUOTA INTERRUPTED' if
                    row['review_classification'] != 'SCOREABLE' else
                    f'{"PASS" if row["score"]["pass"] else "FAIL"} / {row["inference"]["calls"]} calls')
            lines.append(f'| {backend} | {spec["id"]} | ' + ' | '.join(cells) + ' |')
    lines += ['', '## Interpretation and decision', '',
        'The simple macro and workflow have the same acquisition policy. Qwen had the same '
        '5/6 correctness in each; macro used22 calls versus21 for workflow, with19 native '
        'operations each. The strict predeclared Qwen macro screen therefore fails its '
        'no-additional-calls requirement (21 versus20 calls on five matched-correct pairs). '
        'Do not rename that screen as a pass. A one-call difference in this tiny study is '
        'not proof of an algorithmic workflow advantage. Sol showed observed parity on '
        'four complete pairs, but its full screen remains incomplete.', '',
        'Both bundles are promising relative to primitive tools in the recorded Qwen cases, '
        'particularly avoiding the persistent-observation loop. They did not fix Qwen ending '
        'the already-home task without using tools. No architectural novelty, general '
        'reliability, statistical equivalence or physical-robot readiness is established.', '',
        'A shared prompt/tool inconsistency was discovered: default system prompts mandate '
        'unavailable discovery tools before action while the bounded contract mandates '
        'selection first. It is a real interface defect, but its causal effect is untested. '
        'Passing trace/schema/resource audits does not mean that the instruction contract '
        'was consistent. Preserve this experiment and resolve the mismatch prospectively '
        'before a larger study; do not silently tune or rerun frozen cases.', '',
        '## Safety, cleanup and audit scope', '',
        'All33 saved attempts matched actual persisted Phoenix span IDs and closed trees. '
        'All saved primary scores were reproduced from raw evidence. No accepted unsupported '
        'selected-goal SUCCESS or dispatch violation appeared. Fault coverage is recorded '
        'separately; the quota attempt had no fault exercise. Both simulators exited with '
        'returncode0, both supervisors released sleep holds, Qwen was unloaded, and the hosted '
        'session was revoked. No credential persistence or consent bypass was introduced.', '',
        'Pre-live validation:40 test methods,18 scripted ROSA/Phoenix trials and six initial '
        'deterministic UR5e controls passed. Six deterministic controls also passed before '
        'each live backend. The initial Phoenix-unavailable attempt is retained. All189 '
        'frozen sources, including both dependency lockfiles, are verified and included.', '',
        'Per trial:8 requests,180 seconds,16 tool attempts,10 native operations,one trajectory, '
        'three corrections. Per backend:144 inference attempts and4500 active batch seconds. '
        'Qwen retained the frozen Q4_K_M model digest, Ollama0.40.6, ctx8192, temp0,seed42, '
        'reasoning off, per-call allowance1024 reduced against2048 cumulative generated tokens. '
        'Sol retained the OAuth adapter and observed2048 stopping threshold; an equivalent '
        'hard generation cap is not available. Cross-model hard-token-budget equality is '
        'not claimed. Latencies exclude startup/reset/control/audit/serialization overhead.', '',
        'Session receipt:', '', '```json', json.dumps(read(CAMPAIGN / 'session-siwc.json'), indent=2), '```', '',
        'The session supports authorized memory renewal, but token_refreshes0 means this '
        'batch did not exercise actual renewal. The observed error was quota exhaustion, '
        'which refresh-token renewal cannot legitimately bypass.', '',
        '## Remaining work', '',
        'Four hosted cells remain: repeat the quota-interrupted missing-prerequisite workflow '
        'cell as a new attempt, then the three transient-after-motion conditions. They require '
        'quota availability and fresh manual consent because cleanup revoked the session. '
        'Use a separate continuation protocol/output folder and preserve the original '
        'quota record. A continuation capped at32 requests keeps combined hosted attempts '
        'at most75, below the original144 ceiling. No continuation has been launched and '
        'no reset time is assumed. Do not rerun completed Qwen or hosted cells.', '',
        'Next research priority after this interrupted campaign is accounted for: uniformly '
        'repair the composed prompt/tool contract, validate separately, and compare the '
        'smallest bundled skill with primitive tools using fresh repeated cases. Keep JTVR, '
        'memory, general planning and physical deployment out of this experiment.', '',
        '## Detailed review notes', '', (CAMPAIGN / 'INTERPRETATION_NOTES.md').read_text(), '',
        '## Evidence', '',
        'The frozen analyzer analysis.json/REPORT_FOR_CHATGPT.md remains unchanged and includes '
        'the raw failed quota row. Use PARTIAL_AUDIT.json and this partial report for the '
        'explicit infrastructure/scoreable distinction. Complete campaign finalization correctly '
        'refused to publish a complete ZIP. This separate archive is explicitly partial.', '',
        'Archive: `' + ARCHIVE.name + '`. All raw attempts, controls, checkpoints, source '
        'snapshots, actual Phoenix spans, cleanup receipts and partial classification are included.']
    (CAMPAIGN / 'REPORT_FOR_CHATGPT_PARTIAL.md').write_text('\n'.join(lines) + '\n')
    files = [p for p in CAMPAIGN.rglob('*') if p.is_file() and p.suffix != '.tmp' and p.name != 'gazebo.lock']
    files.append(Path(__file__))
    manifest = {p.relative_to(ROOT).as_posix(): digest(p.read_bytes()) for p in files}
    assert all(manifest.get(name) == value for name, value in source_members.items())
    with ZipFile(ARCHIVE, 'x', compression=ZIP_DEFLATED) as archive:
        for name in manifest:
            archive.write(ROOT / name, name)
        archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2) + '\n')
    with ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        assert all(digest(archive.read(name)) == value for name, value in manifest.items())
        assert all(digest(archive.read(name)) == value for name, value in source_members.items())
    checksum = digest(ARCHIVE.read_bytes())
    ARCHIVE.with_suffix('.sha256').write_text(checksum + '  ' + ARCHIVE.name + '\n')
    print(json.dumps({'campaign_complete': False, 'audit_complete': True, 'attempts': len(rows),
        'scoreable_trials': 32, 'quota_interrupted': 1, 'not_started': 3,
        'frozen_sources_in_archive': len(source_members), 'manifest_entries': len(manifest),
        'archive': str(ARCHIVE), 'sha256': checksum}))


if __name__ == '__main__':
    main()
