# Shared ROSA backend interface

Date: 2026-10-20 (Asia/Taipei). Scope: model/agent integration with fixed mock reads; not the stateful research benchmark.

Update, 2026-10-21: the previously pending [hosted OAuth-through-ROSA live test passed](shared_rosa_oauth_verification_2026-10-21.md), including both single and dependent tool cases, Phoenix read-back and session revocation. Both backends have now passed the shared-interface readiness cases. The October 20 timeout below is retained as historical evidence.

## Implemented

- `rosa-research/src/rosa_backends`: one `create_model` entry point for local Ollama/Qwen and ChatGPT OAuth, plus `create_mock_agent` using the existing modified ROSA executor. Both use ordinary LangChain tool definitions, the same ROSA prompts and agent loop, and an exact custom-only tool registry.
- OAuth `ChatSiwc` is a `BaseChatModel` with `bind_tools`, synchronous generation and LangChain's async fallback. It converts system messages to developer messages, wraps function schemas in the supported `rosa_tools` namespace, and preserves native tool call IDs through tool-result continuation.
- Native Responses streams must reach `response.completed`. Unknown tools/namespaces, duplicate IDs/argument keys, malformed argument JSON, orphan/missing tool results, and unavailable native continuation history fail closed.
- Tokens and encrypted continuation output stay private in memory, outside serialized models, public messages and tracing callbacks. The adapter retains at most 64 native message outputs; short-lived probe sessions allow at most eight requests and revoke on exit. Automatic refresh and durable sign-in are not implemented.
- ROSA's robot-specific prompt construction now copies its global prompt list, preventing instruction accumulation across agent instances.
- `rosa-evaluation/experiments/probe_backends.py`: the same single-tool and dependent two-tool cases for both backends. Captures schemas, queries, observed calls, model settings, source hashes, answers, timings and Phoenix traces. Sampling controls differ by backend and are recorded rather than silently emulated.

## Verification so far

- Nine offline shared-adapter tests passed, exercising the real ROSA executor, async calls, task isolation, schema rebinding, unsupported/invalid calls, callback/model serialization privacy, prompt isolation, and explicit Ollama loading options.
- Twenty OAuth protocol/stream regressions (including an idle loopback browser connection deadline), two mock-isolation checks and eight evaluation configuration/export checks passed.
- Phoenix was already on the latest stable server/client releases. [Version check and ingestion evidence](phoenix_version_check_2026-10-20.md).
- Live Qwen shared-interface single and dependent cases passed with explicit `use_mmap=true` and bundled CUDA 12: [run c085fac7](../rosa-evaluation/results/runs/c085fac7-4e4c-4fdc-af5c-fe6a7919c420/result.json). Phoenix read-back confirmed five LLM calls and three tool dispatches: health; health then left gripper. [Trace export](../rosa-evaluation/results/runs/c085fac7-4e4c-4fdc-af5c-fe6a7919c420/phoenix/trace.json).
- Final verification also passed after restoring automatic CUDA selection, which selected CUDA 13: [run aa1ee9bc](../rosa-evaluation/results/runs/aa1ee9bc-a616-4126-9c2b-ee3e0dff83bb/result.json), [Phoenix export](../rosa-evaluation/results/runs/aa1ee9bc-a616-4126-9c2b-ee3e0dff83bb/phoenix/trace.json). It used the same pinned Qwen digest, 4,096 context, 256 output budget, temperature 0 and seed 42, with `use_mmap=true`. Single-tool case including cold load: 46.58 seconds; warm dependent case: 21.68 seconds. The exported trace contains five LLM calls and three tool dispatches, and the server log confirms memory-mapped loading with 17/33 layers on GPU.
- The new shared-interface OAuth live attempt [fb94f1ea](../rosa-evaluation/results/runs/fb94f1ea-cba2-4e10-912f-91bb7ff454bc/result.json) ended with `browser_consent_timeout`, zero inference cases, and `NO_TOKEN_SESSION`. This is an incomplete live verification, not evidence that the adapter or account inference failed. It requires a new user-completed sign-in. Prior [native OAuth readiness](oauth_smoke_2026-10-20.md) passed; it is a separate result from validation of the new ROSA adapter.
- The existing Qwen readiness workflow also passed after honoring the loading setting: [run c7843087](../rosa-evaluation/results/runs/c7843087-c2dd-48e4-acd9-511c74d5526b/result.json), with native single/dependent tool loops and custom-only ROSA. Qwen was unloaded afterward to release memory; both services remain running.

## Local serving failure and recovery

The original Windows Ollama CUDA 13 runner crashed on warm-up with `CUDA error: shared object initialization failed` / process exit `0xc0000409`. Restarting did not fix it. Trying bundled CUDA 12 alone also failed. The failed runs and logs are retained:

- `e2fbb90c-0cdb-48f2-b5ee-95ee5f76093b`: initial CUDA 13 failure.
- `b8399b72-1951-4bcf-8ee5-473d705b260a`: restarted CUDA 13 failure.
- `82440eb0-1cb1-4ec0-9c53-33dccf7bbaf2`: CUDA 12 alone failed.

Explicit memory-mapped model loading succeeded with both CUDA 12 and the restored CUDA 13 selection. Windows reported approximately 4.2 GiB available physical RAM and 5.4 GiB remaining virtual commit headroom during diagnosis; low host-memory headroom is a plausible contributor, not a proven sole cause. No drivers, pagefile settings, unrelated applications, or model weights were changed. CUDA runtime experiments are separate serving factors, not model/JTVR effects. The original automatic CUDA selection is restored; no CUDA-library override is retained.

`OLLAMA_USE_MMAP=true` is saved in this machine's ignored evaluation `.env`. The shared and Qwen readiness probes honor it, or accept explicit `--use-mmap` / `--no-use-mmap`. The pinned ChatOllama version lacks this named option; a small subclass adds it to native options while preserving sampling/context settings. This is a documented serving configuration change from earlier smoke tests.

## Commands and remaining scope

From Ubuntu in `rosa-evaluation`, with project services running:

```bash
./run.sh research --probe-backends --backend ollama
./run.sh research --probe-backends --backend siwc
```

The latter prints the sign-in link, discovers current account models, and accepts an exact `--model` slug. No API-key fallback is configured. Authentication runs outside the inference tracing context.

These fixed fixtures establish integration only. The next research step remains stateful mock task families, a hidden-state independent scorer, matched budgets, repeated runs and held-out evaluation. The generic existing `--mode live` launcher remains its historical ROS/Ollama workflow; use the explicit shared probe for controlled backend checks. Observation caching and episodic memory are disabled; backend-managed prompt/KV caching can still occur. No claims of model parity, research novelty, or robot task reliability follow from these cases. Changes remain local and uncommitted on the member branches.
