"""Create isolated versioned runners; never edit the completed pilot."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
old = root / 'rosa-evaluation/experiments/workflow_live_v1'
new = root / 'rosa-evaluation/experiments/workflow_reference_v1'
for name in ('inference.py', 'tracing.py', 'persisted.py'):
    data = (old / name).read_text().replace('rosa-workflow-live-v1-20261022', 'rosa-workflow-reference-v1-20261022')
    (new / name).write_text(data)
data = (old / 'runner.py').read_text()
replacements = {
 'from rosa_reliability.workflow import WorkflowSession, make_workflow_tools':
 'from rosa_reliability.reference import ReferenceWorkflowSession as WorkflowSession, make_reference_tools as make_workflow_tools',
 'from .design import LIMITS, SKILLS, PilotTransport, jobs, query':
 'from .design import LIMITS, catalogue, PilotTransport, jobs, query',
 'artifacts/workflow-live-v1-20261022': 'artifacts/workflow-reference-v1-20261022',
 'experiments.workflow_live_v1.persisted': 'experiments.workflow_reference_v1.persisted',
 'def score(session, spec, transport, answer, claims):':
 'def score(session, spec, transport, answer, claims, skills, tolerance, actual=None):',
 '    snap = session.snapshot()\n    last =':
 "    actual = transport.values if actual is None else actual\n    snap = session.snapshot()\n    last =",
 'SKILLS[spec[\'skill\']]': "skills[spec['skill']]",
 'transport.values[n][k]': 'actual[n][k]',
 '<= .01': '<= tolerance',
 "missing = spec['fault'] == 'missing' or (spec['fault'] == 'post_missing' and transport.writes > 0)":
 "missing = spec['fault'] == 'missing'",
 "if record['kind'] == 'read':": "if record['kind'] in ('read', 'observation', 'observation_timeout'):",
 "known = not record['missing']": "known = not record.get('missing', record['kind'] == 'observation_timeout')",
 "elif record['kind'] == 'write' and not known:": "elif record['kind'] in ('write', 'trajectory_request') and not known:",
 'if transport.writes > 1:': "if sum(r['kind'] in ('write', 'trajectory_request') for r in transport.records) > 1:",
 'def run_backend(backend, llm, oauth_transport=None):':
 'def run_backend(backend, llm, phase, batch_counter, oauth_transport=None):',
 "folder = DESTINATION / backend": "folder = DESTINATION / phase / backend",
 "folder.mkdir(exist_ok=False)": "folder.mkdir(parents=True, exist_ok=False)",
 "'request_cap': 96": "'request_cap': 64",
 "    active_start = time.monotonic()":
 "    skills = catalogue(phase)\n    tolerance = .025 if phase == 'gazebo' else .01\n    active_start = time.monotonic()\n    simulator = controller = observer = None",
 "if status['total_model_calls'] >= 96 or time.monotonic() - active_start >= LIMITS['backend_seconds']:":
 "if status['total_model_calls'] >= 64 or batch_counter['calls'] >= 128 or time.monotonic() - active_start >= LIMITS['backend_seconds']:",
 "        status['total_model_calls'] += 1": "        status['total_model_calls'] += 1\n        batch_counter['calls'] += 1",
 "        for index, job in enumerate(jobs()):":
 """        if phase == 'gazebo':
            from experiments.ur5e_transfer_v1.arm import ArmSimulator, ArmTransport
            simulator = ArmSimulator(folder / 'simulator')
            simulator.start()
            controller, observer = ArmTransport(), ArmTransport(read_only=True)
        for index, job in enumerate(jobs(phase)):""",
 '            transport, meter, claims = PilotTransport(spec), Meter(), []':
 """            if phase == 'gazebo':
                from experiments.ur5e_transfer_v1.arm import reset, configure_fault, JOINTS
                reset_record = reset(controller, observer)
                configure_fault(controller, spec)
                controller.records.clear()
                transport = controller
                oracle = lambda: {'/ur5e': observer.read('/ur5e', list(JOINTS))}
            else:
                transport = PilotTransport(spec)
                oracle = lambda: deepcopy(transport.values)
                reset_record = None
            meter, claims = Meter(), []""",
 "                        claims.append({'status': args.get('status'), 'arguments': deepcopy(args),":
 "                        actual = oracle()\n                        claims.append({'status': args.get('status'), 'arguments': deepcopy(args),",
 "'private_actual_state': deepcopy(transport.values)": "'private_actual_state': deepcopy(actual)",
 "<= .01\n                                for n, group": "<= tolerance\n                                for n, group",
 "'protocol': 'workflow-live-v1'": "'protocol': 'workflow-reference-v1', 'phase': phase",
 'request = query(spec, program)': 'request = query(spec, program, phase)',
 'session = EvaluatedSession(transport, SKILLS, program_managed=program, tracer=tracer)':
 'session = EvaluatedSession(transport, skills, program_managed=program, tolerance=tolerance, tracer=tracer)',
 'len(snap[\'operations\']) > 10 or transport.writes > 1':
 "len(snap['operations']) > 10 or session.write_count > 1",
 'scored = score(session, spec, transport, answer, claims)':
 'actual = oracle()\n            scored = score(session, spec, transport, answer, claims, skills, tolerance, actual)',
 "'private_final_state': transport.values, 'claim_time_oracles': claims":
 "'private_final_state': actual, 'claim_time_oracles': claims, 'reset_record': reset_record",
 '    finally:\n        save()\n    return status':
 """    finally:
        for item in (controller, observer):
            if item:
                item.close()
        if simulator:
            status['simulator_cleanup'] = simulator.close()
        save()
    return status""",
 'request_budget=96': 'request_budget=128',
 'run_backend(args.backend, llm, transport)':
 """counter = {'calls': 0}
            run_backend(args.backend, llm, 'mock', counter, transport)
            wait_mock_gate()
            with gazebo_lock():
                run_backend(args.backend, llm, 'gazebo', counter, transport)""",
 "'request_cap': 96": "'request_cap': 128",
 "    verify_freeze()\n    from dotenv":
 "    verify_freeze()\n    os.environ['ROS_DOMAIN_ID'] = '211' if args.backend == 'ollama' else '212'\n    os.environ['ROS_AUTOMATIC_DISCOVERY_RANGE'] = 'LOCALHOST'\n    from dotenv",
}
for source, target in replacements.items():
    if source not in data:
        # One tolerance occurrence was already replaced by the general rule.
        if source.startswith('<= .01'):
            continue
        raise RuntimeError('missing source anchor: ' + source)
    data = data.replace(source, target)
insertion = '''
def wait_mock_gate():
    deadline = time.monotonic() + 2700
    while time.monotonic() < deadline:
        files = [DESTINATION / 'mock' / b / 'checkpoint.json' for b in ('ollama', 'siwc')]
        states = [json.loads(p.read_text()) if p.exists() else None for p in files]
        if any(s and s['status'] == 'STOPPED' for s in states):
            raise RuntimeError('mock_peer_stopped_no_gazebo')
        if all(s and s['status'] == 'COMPLETE' for s in states):
            passed = all(len(s['trials']) == 8 and all(r['score']['pass'] and r['audit']['pass']
                         for r in s['trials']) for s in states)
            write(DESTINATION / 'mock-gate.json', {'pass': passed, 'required_correct_trials': 16})
            if not passed:
                raise RuntimeError('fresh_mock_validation_gate_failed_no_gazebo')
            return
        time.sleep(2)
    raise RuntimeError('mock_gate_wait_timeout_no_gazebo')


@contextmanager
def gazebo_lock():
    import fcntl
    with (DESTINATION / 'gazebo.lock').open('a') as handle:
        deadline = time.monotonic() + 2700
        while True:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() > deadline:
                    raise RuntimeError('gazebo_serialization_wait_timeout')
                time.sleep(2)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


'''
data = data.replace('def main():', insertion + 'def main():')
(new / 'runner.py').write_text(data)
print('Created isolated reference runner; completed campaign sources unchanged.')
