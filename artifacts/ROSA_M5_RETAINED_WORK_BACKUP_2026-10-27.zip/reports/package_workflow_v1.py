"""Verify and package only the named workflow development evidence."""
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZipFile, ZIP_DEFLATED


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root = Path(__file__).resolve().parents[1]
    evaluation = root / 'rosa-evaluation'
    artifacts = evaluation / 'artifacts'
    pilot = artifacts / 'workflow-v1-development-r1-20261022'
    summary = json.loads((pilot / 'summary.json').read_text())
    assert summary['all_pass'] and len(summary['results']) == 14
    assert all(r['pass'] and all(r['checks'].values()) for r in summary['results'])
    source_manifest = json.loads((pilot / 'source-hashes.json').read_text())
    for index, (name, expected) in enumerate(source_manifest.items()):
        path = Path(name)
        assert digest(path) == expected, name
        assert digest(pilot / 'source' / f'{index:02d}-{path.name}') == expected, name
    validation = artifacts / 'workflow-v1-validation-20261022'
    assert json.loads((validation / 'validation.json').read_text())['all_pass']
    test_count = sum(int(re.search(r'Ran (\d+) tests?', path.read_text()).group(1))
                     for path in validation.glob('*.log'))
    assert test_count == 35
    previous = {
        'ROSA_OUTPUT_BUDGET_V1_COMPLETE_EVIDENCE_2026-10-22.zip':
            'ae202ca1f6aa0bf43fdeea189c6f489b0b1cb0b632ce160e905303b3accea19a',
        'ROSA_OUTPUT_BUDGET_V1_COMPLETE_REVIEW_2026-10-22.zip':
            'da713dc6b59670d83eb17e4a7edc1d1a7f8dfc67a36846f541c963c7a4ba6cf0',
        'ROSA_RELIABILITY_V2_UR5E_COMPLETE_EVIDENCE_2026-10-22.zip':
            '63188649d0c21bd7f0b9a8a70bce01de88b5d2df45845486aafa884d68cadae6'}
    for name, expected in previous.items():
        assert digest(artifacts / name) == expected, name
    roots = [pilot, validation, artifacts / 'workflow-v1-development-a0-20261022',
             evaluation / 'experiments/workflow_v1']
    files = [p for folder in roots for p in folder.rglob('*') if p.is_file()]
    files += [evaluation / 'WORKFLOW_V1_DEVELOPMENT_REPORT.md',
              evaluation / 'docs/WORKFLOW_V1_DEVELOPMENT_2026-10-22.md',
              evaluation / 'tests/test_workflow_v1.py',
              root / 'rosa-research/WORKFLOW_PROTOTYPE.md',
              root / 'rosa-research/src/rosa_reliability/terminal.py',
              root / 'rosa-research/src/rosa_reliability/workflow.py',
              root / 'reports/WORKFLOW_V1_ACTIVE.md', Path(__file__)]
    manifest = {str(p.relative_to(root)).replace('\\', '/'): digest(p) for p in files}
    destination = artifacts / 'ROSA_WORKFLOW_V1_DEVELOPMENT_2026-10-22.zip'
    with ZipFile(destination, 'x', compression=ZIP_DEFLATED) as archive:
        for name in manifest:
            archive.write(root / name, name)
        archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2) + '\n')
    with ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert all(hashlib.sha256(archive.read(name)).hexdigest() == expected
                   for name, expected in manifest.items())
    receipt = {'pass': True, 'test_methods_passed': test_count, 'scripted_scenarios_passed': 14,
               'source_files_verified': len(source_manifest), 'packaged_files_verified': len(manifest),
               'previous_archive_hashes_unchanged': previous,
               'archive': str(destination), 'archive_sha256': digest(destination)}
    destination.with_suffix('.sha256').write_text(receipt['archive_sha256'] + '  ' + destination.name + '\n')
    (root / 'reports/WORKFLOW_V1_FINAL_VERIFICATION.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
