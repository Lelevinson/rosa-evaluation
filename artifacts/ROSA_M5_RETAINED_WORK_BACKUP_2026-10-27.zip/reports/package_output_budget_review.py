"""Bundle a clearly post-run review with the unchanged sealed evidence ZIP."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
EVAL=ROOT/'rosa-evaluation'


def sha(data):return hashlib.sha256(data).hexdigest()


def main():
    evidence=EVAL/'artifacts/ROSA_OUTPUT_BUDGET_V1_COMPLETE_EVIDENCE_2026-10-22.zip'
    receipt=json.loads((ROOT/'reports/OUTPUT_BUDGET_V1_FINAL_VERIFICATION.json').read_text(encoding='utf-8-sig'))
    if not receipt['pass'] or sha(evidence.read_bytes())!=receipt['archive_sha256']:
        raise RuntimeError('sealed_evidence_verification_mismatch')
    sources={
        'REVIEW_FOR_CHATGPT.md':EVAL/'OUTPUT_BUDGET_V1_REVIEW_FOR_CHATGPT.md',
        'evidence/'+evidence.name:evidence,
        'verification/FINAL_VERIFICATION.json':ROOT/'reports/OUTPUT_BUDGET_V1_FINAL_VERIFICATION.json',
        'verification/TERMINAL_REPORT_REVIEW.json':ROOT/'reports/OUTPUT_BUDGET_V1_TERMINAL_REPORT_REVIEW.json',
        'verification/verify_output_budget_v1.py':ROOT/'reports/verify_output_budget_v1.py',
        'verification/package_output_budget_review.py':Path(__file__),
    }
    manifest={name:sha(path.read_bytes()) for name,path in sources.items()}
    metadata={'purpose':'Post-run interpretation plus unchanged independently verified raw evidence.',
        'primary_scores_unchanged':True,'attempts':41,'scored_trials':40,'external_unscorable_attempts':1,
        'read_first':'REVIEW_FOR_CHATGPT.md','files':manifest,
        'sealed_evidence_sha256':receipt['archive_sha256']}
    target=EVAL/'artifacts/ROSA_OUTPUT_BUDGET_V1_COMPLETE_REVIEW_2026-10-22.zip'
    with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as archive:
        for name,path in sources.items():archive.write(path,name)
        archive.writestr('MANIFEST.json',json.dumps(metadata,indent=2)+'\n')
    with zipfile.ZipFile(target) as archive:
        if set(archive.namelist())!=set(sources)|{'MANIFEST.json'}:
            raise RuntimeError('review_member_set_mismatch')
        for name,digest in manifest.items():
            if sha(archive.read(name))!=digest:raise RuntimeError('review_member_mismatch:'+name)
    digest=sha(target.read_bytes())
    target.with_suffix('.sha256').write_text(digest+'  '+target.name+'\n')
    result={'pass':True,'archive':target.name,'bytes':target.stat().st_size,'sha256':digest,
            'sealed_evidence_unchanged':sha(evidence.read_bytes())==receipt['archive_sha256']}
    (ROOT/'reports/OUTPUT_BUDGET_V1_REVIEW_PACKAGE.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
