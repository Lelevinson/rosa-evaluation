"""Read-only final evidence checks; writes one receipt outside sealed packages."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
ARTIFACTS=ROOT/'rosa-evaluation/artifacts'
FIRST=ARTIFACTS/'output-budget-v1-20261022'
PRIOR=ARTIFACTS/'output-budget-v1-followup-20261022'
TAIL=ARTIFACTS/'output-budget-v1-resume-20261022'


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    errors=[]
    freeze=json.loads((TAIL/'freeze.json').read_text())
    for campaign in (FIRST,PRIOR):
        if digest(campaign/'freeze.json')!=freeze['prior_source_freezes'][campaign.name]:
            errors.append('original_freeze_changed:'+campaign.name)
    first_result=FIRST/'gazebo/ollama/000-r0-ur5e_coordinated_move-R256/result.json'
    prior_freeze=json.loads((PRIOR/'freeze.json').read_text())
    if digest(first_result)!=prior_freeze['original_trial_result_sha256']:
        errors.append('original_failed_trial_changed')
    if digest(PRIOR/'gazebo/ollama/result.json')!=freeze['original_interrupted_checkpoint_sha256']:
        errors.append('original_interrupted_checkpoint_changed')
    rows=[]
    schemas=set()
    for campaign in (FIRST,PRIOR,TAIL):
        phase=json.loads((campaign/'gazebo/ollama/result.json').read_text())
        rows+=phase['trials']
        for row in phase['trials']:
            trace=json.loads((campaign/'gazebo/ollama'/row['run_id']/'trace.json').read_text())
            for span in trace['spans']:
                attr=span.get('attributes',{})
                if attr.get('openinference.span.kind')!='LLM':continue
                invocation=json.loads(attr['llm.invocation_parameters'])
                schemas.add(json.dumps(invocation['tools'],sort_keys=True))
                options=invocation['options']
                if not (0<options['num_predict']<=row['per_call'] and
                        options['num_ctx']==8192 and options['seed']==42 and
                        options['temperature']==0 and options['use_mmap'] is True):
                    errors.append('serving_profile:'+row['run_id'])
    if len(rows)!=40 or len({r['run_id'] for r in rows})!=40:
        errors.append('coverage_or_duplicate_trial')
    if len(schemas)!=1:errors.append('tool_schemas_differ')
    review=json.loads((TAIL/'independent-review.json').read_text())
    if not review['pass']:errors.append('independent_review_failed')
    manifest=json.loads((TAIL/'MANIFEST.json').read_text())
    target=ARTIFACTS/'ROSA_OUTPUT_BUDGET_V1_COMPLETE_EVIDENCE_2026-10-22.zip'
    with zipfile.ZipFile(target) as archive:
        expected=set(manifest['files'])|{TAIL.name+'/MANIFEST.json'}
        if set(archive.namelist())!=expected:errors.append('zip_member_set_mismatch')
        for name,value in manifest['files'].items():
            if hashlib.sha256(archive.read(name)).hexdigest()!=value or digest(ARTIFACTS/name)!=value:
                errors.append('zip_or_disk_mismatch:'+name)
    for name,value in freeze['previous_archives'].items():
        if digest(ARTIFACTS/name)!=value:errors.append('old_archive_changed:'+name)
    receipt={'pass':not errors,'errors':errors,'trials':len(rows),
        'correct':sum(r['score']['pass'] for r in rows),
        'model_calls':sum(r['model_calls'] for r in rows),
        'identical_tool_schema_sets':len(schemas),
        'archived_files':len(manifest['files']),
        'archive_bytes':target.stat().st_size,'archive_sha256':digest(target),
        'original_failed_trial_unchanged':digest(first_result)==prior_freeze['original_trial_result_sha256'],
        'external_interrupted_unscorable_attempts':1,
        'unknown_usage_trials':sum(r['usage_incomplete_trials'] for r in review['aggregates'])}
    (ROOT/'reports/OUTPUT_BUDGET_V1_FINAL_VERIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
    if errors:raise SystemExit(1)


if __name__=='__main__':main()
