# Phoenix release check

Checked 2026-10-20 (Asia/Taipei) against official PyPI JSON metadata and the upstream release page.

| Package | Installed | Latest published stable |
| --- | --- | --- |
| arize-phoenix | 20.23.0 | 20.23.0 |
| arize-phoenix-client | 3.5.0 | 3.5.0 |

The existing pinned installation is already current. No dependency upgrade, database migration, or server restart was required. The latest server release is dated October 16, 2026; it includes server-log export over OTLP and a Bedrock playground tool-result fix.

Local ingestion and read-back passed again: run `2d7e6452-068f-4b9d-bf14-1402a185af54`, [smoke evidence](../rosa-evaluation/results/runs/2d7e6452-068f-4b9d-bf14-1402a185af54/phoenix/smoke.json). Existing trace storage was retained.

Sources: [server package](https://pypi.org/project/arize-phoenix/), [client package](https://pypi.org/project/arize-phoenix-client/), [upstream releases](https://github.com/Arize-ai/phoenix/releases).
