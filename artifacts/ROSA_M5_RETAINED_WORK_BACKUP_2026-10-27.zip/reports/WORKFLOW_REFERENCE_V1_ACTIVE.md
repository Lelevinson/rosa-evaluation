# Observation-reference reporting and gated UR5e transfer

FINAL COMPLETE: 32 live trials collected, 31 correct frozen outcomes. All16
program-managed trials were correct. All live usage is known; no censored
generation. Hosted session REVOKED, local model unloaded, simulators closed,
both supervisors complete and temporary sleep holds released.

| Phase | Model | Model-managed correct / calls | Program-managed correct / calls | Native model / program |
| --- | --- | ---: | ---: | ---: |
| Mock | Qwen | 4/4 / 26 | 4/4 / 12 | 15 / 14 |
| Mock | Sol | 4/4 / 18 | 4/4 / 9 | 10 / 11 |
| Gazebo | Qwen | 3/4 / 18 | 4/4 / 14 | 6 / 12 |
| Gazebo | Sol | 4/4 / 19 | 4/4 / 8 | 11 / 10 |

Qwen reference failed one healthy Gazebo movement by omitting movement and
truthfully reporting FAILURE. The paired workflow reached the pose. Its
ineffective-command reference also omitted movement but received the frozen
correct-fault-report score; that did NOT exercise the injected command fault.
Dispatch coverage is documented separately without changing scores.

Milestones completed: minimal common reporting option, focused validation,
deterministic controls and two-model small UR5e transfer. Strong macro-skill
reference/held-out study remain next, before any larger experiment.

Report: `rosa-evaluation/artifacts/workflow-reference-v1-20261022/DETAILED_REVIEW_FOR_CHATGPT.md`.
Analysis: same folder `analysis.json`. Original workflow-live-v1 negative result
and all historical experiments remain unchanged.

The initial launch record below is preserved as history.

Started 2026-10-22. Pipeline RUNNING; read checkpoints for authoritative progress.

Vision unchanged: backend-neutral ROSA reliability/efficiency improvements around
existing models. No new LLM, general evidence subsystem, JTVR or physical robot.

- Minimal new opt-in report schema: status + existing observation_id.
- Eight report-contract checks, 16 workflow checks and nine budget/design checks
  passed. Eight scripted ROSA traces exactly matched persisted Phoenix traces.
- Four fresh deterministic UR5e controls passed; simulator shut down cleanly.
- Protocol/source frozen (53 files) before live generation.
- Hosted manual sign-in completed. Tokens remain memory-only; normal revocation
  occurs after completion/failure. Same session may renew while waiting at gates.
- Supervisors: Qwen PID15016, Sol PID23864, temporary sleep holds in effect.
- Mock: four fresh cases x two conditions x two models = 16 trials.
- Gazebo: 16 further trials ONLY if all mock outcomes/audits pass. Simulators
  serialize; repeat deterministic controls before each backend's model trials.
- Limits: 8 model calls / 180s / 10 native operations / one dispatched write per
  trial; 64 calls per phase/backend; 128 total calls per backend.
- Qwen uses unchanged1024-per-call/2048-cumulative requested output limits;
  Sol uses observed output stopping, not a hard generation cap.

Campaign: `rosa-evaluation/artifacts/workflow-reference-v1-20261022/`.
Protocol: `rosa-evaluation/docs/WORKFLOW_REFERENCE_V1_PROTOCOL_2026-10-22.md`.
Individual checkpoint: `{mock|gazebo}/{ollama|siwc}/checkpoint.json`.
Operator logs: `operator/{backend}-live.log` and supervisor JSON.

Completed workflow-live-v1 remains unchanged: Qwen6/6→5/6 and Sol6/6→6/6.
The new case/contract results must not be presented as a causal correction or
retrospective rescore of that pilot. Macro-skill reference and held-out tasks
remain required before a larger architectural performance study.
