# Fresh macro focus V2 - final execution checkpoint, 2026-10-27

FINAL STATUS (supersedes historical running instructions below): BOTH SUPERVISORS
ENDED. Sol COMPLETE,36/36 primary passes,124 calls. Qwen STOPPED on frozen backend
deadline,33 attempt rows,24 primary passes,126 calls; last row deadline-censored,
three second-repetition three_constraints cells unstarted. All69 local/input/exact
Phoenix audits passed; all12 deterministic controls passed; both simulators closed,
Qwen unloaded, hosted session refreshed once in memory then REVOKED, sleep holds
released. No running pilot or consent request remains. No continuation launched.

Per condition primitives/macro/workflow: Qwen8/11,9/11,7/11 with61/31/34 calls;
Sol12/12 each with60/32/32 calls. Qwen has6 unreturned inference requests with
unknown token usage. No formal retention claim: study INCOMPLETE, not audit-failed.
Simple macro is the more promising next candidate; workflow adds no Sol call
saving and is worse in the observed Qwen subset. Missing cells and timeouts stay.

Shareable interpretation: reports/MACRO_FOCUS_V2_RESULTS_FOR_CHATGPT_2026-10-27.md.
Frozen automatic results: artifacts/macro-focus-v2-20261026/REPORT.md and analysis.json
under rosa-evaluation. Validation remains separate. No frozen files were changed.

HISTORICAL LAUNCH CHECKPOINT BELOW; its RUNNING/next-sign-in text is superseded.

Latest reporting clarification: read reports/MACRO_FOCUS_V2_REPORT_BRIEF.md.
User wants the final report centered on call savings WITHOUT correctness loss,
and whether the custom workflow adds value over the simple macro. Existing
frozen analysis already computes these paired screens; no live source or
criterion changes. Recommend macro only if it meets its baseline requirements
and workflow adds no sufficient benefit; cheap failures are not efficiency wins.

Current status: RUNNING. User completed the NEW pilot's manual hosted sign-in.
Qwen supervisor PID9524, hosted supervisor PID17600. Same-campaign Gazebo lock
serializes access; hosted memory session waits/renews without new consent.
User authorized continuing the original experiment ordering and combining the
two reports later. Teammate rosa-llm package remains parked; no backend migration,
JTVR, memory, general planner or physical-robot work in this milestone.

Prerequisite validation COMPLETE WITH LINEAGE: Qwen9/9 and Sol9/9 scoreable
completed outcomes. All19 attempts passed local/input/exact Phoenix audits.
Initial hosted service-censored attempt retained (one unknown-cost request),
R1 setup abort retained (zero inference), R2 explicit-HOME spawn amendment
validated by2 unit checks,3 cold starts and18 deterministic controls. R2 finished
5/5 correct,19 new hosted calls,32 combined hosted requests including the initial
13 and R1's0. All sessions revoked and simulators closed normally. Gate proof:
rosa-evaluation/artifacts/prompt-contract-v1-live-resume-r2-20261026/COMBINED_ANALYSIS.json.
Its separate report is COMBINED_VALIDATION_REPORT.md. Do not alter raw data.

Fresh pilot FROZEN before inference at:
rosa-evaluation/artifacts/macro-focus-v2-20261026/freeze.json.
Protocol: rosa-evaluation/docs/MACRO_FOCUS_V2_PROTOCOL_2026-10-26.md.
Code: rosa-evaluation/experiments/macro_focus_v2. New coordinator/scorer/decision
preflight11/11 unit methods passed, including18 deterministic fixture paths.
Source copies include the historical runtime and dependency locks. Freeze also
binds prior validation evidence and both continuation lineages. Pinned Ollama
version0.40.6 and Qwen digest reconfirmed; environment-preflight.json recorded.

Six new cases,2 repetitions,3 conditions (model primitives / macro / workflow),
2 models =72 trials,36/backend,max288 requests/backend. Same serving profiles,
common prompt,5 tools,permissions,strict reports and actor budgets. Main timer
also bounds inference by remaining4500-second backend allowance. Startup uses
the validated HomeSpawnSimulator in ALL conditions. Cases: nonhome return,
already-achieved nonhome goal,3 user constraints,transient prerequisite recovery,
actual partial actuation and persistent post-motion observation loss. This is
ONE bounded trajectory capability; do not claim multi-capability generalization.
New prospective scorer enforces the one-extra-observation policy separately;
historical validation's soft guidance is not retrospectively rescored.

Supervisors: reports/macro-focus-v2-run.ps1 -Backend ollama|siwc, each hidden,
with temporary sleep hold and finally release. Output: operator-<backend>/live.log,
supervisor.json,power-release.json. A shared gazebo.lock serializes simulator
access. Backend checkpoints: gazebo/<backend>/checkpoint.json. Six fresh
deterministic controls precede inference. Never rerun populated backend folders.
No automatic retry/command replay or failed-outcome replacement. Authorization
loss, service error, bounds/audit failure stop with saved progress. Normal task
failures remain in the schedule. Manual initial OAuth; memory-only renewal and
normal revocation. Fresh pilot hosted consent is separate from completed R2.

When both supervisors finish, they mark analysis-ready-<backend>.json and run
experiments.macro_focus_v2.analysis automatically. Outputs analysis.json,REPORT.md.
It will NOT make a retention claim if the study is incomplete/unaudited. Primary
screen: no paired reliability losses and>=20% matched-correct call savings per
backend,>=6 matched-correct pairs,<=20% native increase. Workflow must additionally
justify itself against macro using the frozen stricter screen; otherwise prefer
the simple macro if it passes,or retain primitives. Never relax thresholds.

Next: get hosted manual sign-in,monitor all actual trials/audits/limits/cleanup,
retain every failed/censored attempt and all cost, then review the results.
Keep validation/pilot reports separate until combining them for the user later.
No files were staged/committed; both repos remain on member/martin.
