# Strong macro reference and fresh UR5e pilot

Next work is planning-only as of2026-10-23. User expects to return October30;
no new experiments or repairs were started. Read
`rosa-evaluation/docs/PROJECT_DIRECTION_AND_OCT30_HANDOFF_2026-10-23.md` for the
current project goal, evidence, exact prompt defect and deferred next milestone.

## Final: all36 measurement cells completed through four-cell continuation

2026-10-23 Asia/Taipei: the four authorized remaining hosted trials all passed.
The continuation used15 new inference requests; combined hosted attempts58,
including the original quota interruption, below the original144 ceiling.
No completed original result was rerun or replaced. Fresh OAuth cleanupREVOKED;
simulator exited cleanly and the supervisor released its sleep hold.

Final primary/calls: Qwen primitive4/6,39; macro5/6,22; workflow5/6,21.
Sol primitive6/6,29; macro6/6,14; workflow6/6,14 (plus one preserved original
quota request outside the scoreable calls). Both hosted bundles used17 native
operations. Qwen macro and workflow each used19 native operations.

Combined final report:
`rosa-evaluation/artifacts/macro-transfer-v1-resume-r1-20261023/COMBINED_REPORT_FOR_CHATGPT.md`.
Complete joined evidence ZIP:
`rosa-evaluation/artifacts/ROSA_MACRO_TRANSFER_V1_COMPLETE_WITH_CONTINUATION_2026-10-23.zip`.
SHA256: `27652480fb1a6f8a341025399a503b2c40bbcef64472b4de0bab77aae7303200`.
All37 attempt records audited (36 scoreable plus original quota interruption),
196 frozen source copies included,591 manifest entries verified. Both original
partial archives and their historical checkpoint statuses remain unchanged.

Numerical macro screen: Sol passes; Qwen fails the strict no-extra-calls rule
by one call on matched-correct cases. This does not establish an algorithmic
workflow advantage; both use the same acquisition policy. The shared default
prompt/tool contradiction remains an audit exception and must be repaired and
validated separately before a larger clean study. No frozen prompt was tuned.

The sections below preserve prior launch and quota-stop history.

## Four-cell continuation running after fresh manual consent

User authorized continuing only the remaining four hosted cells on2026-10-23.
Continuation: `rosa-evaluation/artifacts/macro-transfer-v1-resume-r1-20261023`.
Supervisor PID5028. Six resume selection/refusal/budget tests passed; seven
continuation sources/schedule were frozen separately. Fresh consent completed;
Gazebo startup and six deterministic controls precede the four model trials.
Additional inference cap32, combined hosted maximum75 including the original43.
No original completed result is rerun or replaced. The shared prompt mismatch
is preserved for comparable treatment, with its caveat retained in reporting.
Monitor the continuation's operator/supervisor.json and finalization-status.json.
No automatic sign-in or repeated quota attempts are authorized by this helper.

## Current checkpoint: STOPPED ON HOSTED QUOTA, campaign incomplete

2026-10-23 Asia/Taipei: Qwen completed18/18 trials; hosted Sol completed14
scoreable trials, then one request was interrupted by
`subscription_sharing_usage_limit_exceeded` at00:19:53. Three further hosted
cells were never started. No experiment process remains running. Both
simulators exited cleanly, Qwen unloaded, sleep holds released and OAuth revoked.

Qwen: primitive4/6 with39 calls; macro5/6 with22; workflow5/6 with21.
Hosted:14/14 scoreable outcomes correct. Four complete three-condition cases
have19 primitive calls versus8 macro and8 workflow calls. Do not compare
unmatched hosted aggregate totals as a completed paired experiment.

All33 saved attempt records passed local/persisted span audits and score
recomputation; all189 frozen sources verified. The quota request returned no
usage; its actual token use remains unknown. Frozen raw scores are unchanged;
the partial audit labels this infrastructure interruption separately.

Partial report:
`rosa-evaluation/artifacts/macro-transfer-v1-20261022/REPORT_FOR_CHATGPT_PARTIAL.md`.
Partial archive:
`rosa-evaluation/artifacts/ROSA_MACRO_TRANSFER_V1_PARTIAL_EVIDENCE_2026-10-23.zip`.
SHA256: `347c7cd1afa82e2e4311b7b262c9d1cd2c08f78108803353fc40d54ab0ac7754`.
539 manifest entries verified; the archive is explicitly incomplete.

Remaining: hosted missing-prerequisite workflow as a new attempt, then all three
transient-after-motion conditions. RESUMPTION_PLAN.json specifies a separate
continuation capped at32 additional requests (combined hosted maximum75,
below original144). No continuation is implemented/launched; quota availability
and fresh manual consent are required. Do not rerun the original full backend
command against populated folders, or retry quota by signing in repeatedly.

Scientific caveat: the shared default system prompts mandate unavailable
discovery tools and conflict with the bounded select-first contract. The run
is preserved as observed under this configuration. Fix and validate that
model-independent mismatch prospectively before a larger clean study. The
Qwen macro failed the strict no-additional-calls screen by one call; its
correctness matched workflow. The full hosted retention screen is incomplete.

The notes below preserve the launch/preparation history.

Current campaign: `rosa-evaluation/artifacts/macro-transfer-v1-20261022`.
This is a separate prospective campaign; all earlier studies remain frozen.

Live launch: 2026-10-22 15:36:53 UTC. Qwen supervisor PID25964; hosted
supervisor PID6700. User reported completed consent; the callback listener
closed and the hosted process is waiting for serialized simulator access. Source freeze contains
189 files. Do not edit frozen sources or launch duplicate supervisors.

## Prepared

- Straight-line strong macro in `rosa-research/src/rosa_reliability/macro.py`.
- Six fresh cases, three conditions, two backends: 36 live cells.
- Same model/backend serving settings and all existing execution safeguards.
- Macro and workflow receive identical public prompts and tool contracts.
- New scoring requires actual injected-fault exercise and correct dispatch coverage.
- 40 offline tests, 18 scripted ROSA/Phoenix runs and six deterministic Gazebo controls passed.
- First trace preflight failed with Phoenix unavailable; preserved separately.
- Existing loopback Phoenix and pinned Ollama services restarted before live calls.

## Run and checkpoint

Protocol: `rosa-evaluation/docs/MACRO_TRANSFER_V1_PROTOCOL_2026-10-22.md`.
Each backend: 18 trials, at most144 inference requests; per trial8 requests,
180seconds,16 tool attempts,10 native operations,one dispatched write.
The simulator is used serially between backends. Six deterministic controls
run before each backend's live matrix. Progress and operator status are saved
under the campaign's `gazebo` and `operator` directories.

Launch using `reports/macro-transfer-v1-run.ps1 -Backend ollama` or `siwc`.
Use hidden background supervisors; each releases its temporary sleep hold.
Hosted consent remains manual, tokens memory-only, renewal under existing
authorization, revocation on exit. Never restart an already populated backend
folder or replay an uncertain in-flight robot trial.

An independent hidden finalizer waits for both backend supervisors, runs the
analyzer and packages complete evidence after audits. It preserves partial
results without claiming completion if either backend stops. Monitor
`operator/finalizer-status.json`. For manual recovery after checking status,
after both supervisors finish, run the new analyzer, then
`reports/finalize_macro_transfer_v1.py` using the research Python environment.
The finalizer recomputes scores from raw evidence and requires full audits,
clean simulator/session cleanup and frozen-source inclusion before packaging.
The packager includes dependency lockfiles; only exact transient gazebo.lock
and .tmp files are excluded.

## Interpretation

The current workflow already uses the same acquisition policy as an ordinary
macro. No new tool-selection algorithm is established by this comparison.
Prefer simple packaging if the predeclared per-backend retention screen passes;
otherwise report observed tradeoffs without tuning these cases. Four catalog
entries remain variants of the same arm movement primitive. Six cases and one
repetition do not support a general reliability or statistical-equivalence claim.

## Prior archive correction

Preserved original ZIP SHA256:
`43c7a2d3d4e87504445e6c10f38ac1e0d76c5ed6cf6d5cca118df098f78295e1`.
Corrected complete ZIP:
`rosa-evaluation/artifacts/ROSA_WORKFLOW_REFERENCE_V1_EVIDENCE_2026-10-22_COMPLETE.zip`.
SHA256: `2674e954437cd75fd5aaea05fbd00330fe39dfd26511c03513ab6cb5efddf942`.
All53 frozen sources are included;332 manifest entries verified. Original data,
scores, freeze and archive are unchanged. The omitted uv.lock resulted from
excluding all .lock suffixes in the old packager.
