# Shared ROSA OAuth live verification: PASS

Date: 2026-10-21 (Asia/Taipei). This completes the previously pending live integration check for the hosted ROSA adapter.

The user completed fresh browser sign-in and consent. The account catalog selected `gpt-6.1-sol`. Through `ChatSiwc`, the actual modified ROSA executor completed the same fixed mock cases already passed by local Qwen. The saved queries and function schemas match the final Qwen run exactly.

| Case | Observed tool sequence | Grounded answer | Wall time |
| --- | --- | --- | ---: |
| Single read | `get_robot_health(mock-robot)` | Battery 73% | 6.75 s |
| Dependent reads | `get_robot_health(mock-robot)` then `get_gripper_state(left)` | Battery 73%, active arm left, gripper open | 10.68 s |

The second tool's arm came from the first tool's output. All five inference requests reached `response.completed`; three native structured calls were mapped through LangChain and executed by ROSA. Only the registered fixed in-memory read tools were exposed. No physical robot was connected or actuated.

## Evidence

- Run: `cb2134ad-c715-47d2-b2a7-192ef1078f0e`.
- [Result report](../rosa-evaluation/results/runs/cb2134ad-c715-47d2-b2a7-192ef1078f0e/result.json).
- [Phoenix export](../rosa-evaluation/results/runs/cb2134ad-c715-47d2-b2a7-192ef1078f0e/phoenix/trace.json).
- Trace ID: `a6999b077dc604fa709ea58c52619bb5`.
- Phoenix read-back: 41 spans, five LLM calls, three top-level tool dispatches, complete exported parent relationships. All three tool spans report `OK`; the root's OpenTelemetry status is `UNSET`, with application success recorded explicitly in the result report.
- Matched local reference: [Qwen run aa1ee9bc](../rosa-evaluation/results/runs/aa1ee9bc-a616-4126-9c2b-ee3e0dff83bb/result.json). Saved query and tool-schema comparisons both returned true.
- Five inference requests used out of an eight-request budget. Reported aggregate input/output tokens: 4,965 / 112.
- Sign-in validation: `PASS`; session cleanup: `REVOKED`; `credentials_persisted: false`. Tokens stayed in memory and were not included in reports or tracing attributes.

## What this establishes

Both candidates have now passed single and dependent tool interactions through the shared ROSA interface. OAuth is no longer limited to a separate native transport smoke test. The previous browser-consent timeout did not recur after fresh consent.

These are two fixed readiness cases, not stateful tasks or a statistically meaningful model comparison. Sampling settings differ by backend, the local single case included cold loading, and no repeated-run or held-out analysis has been performed. The timings do not establish an overall winner. The next milestone is stateful mock task families with a hidden-state independent scorer and matched evaluation budgets, without JTVR or episodic memory enabled.

No implementation changes were needed for this successful retry. Existing source hashes and configuration are recorded in the result report. Source changes from setup/interface work remain local and uncommitted.
