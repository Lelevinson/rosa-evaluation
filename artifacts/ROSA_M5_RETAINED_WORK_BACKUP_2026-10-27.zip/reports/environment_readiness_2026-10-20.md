# Research environment readiness

This is the pre-installation snapshot. See [the completed setup report](setup_2026-10-20.md) for subsequent installation and live smoke-test results.

Date: 2026-10-20 (Asia/Taipei). This report records inspection, not a completed benchmark.

## Confirmed

| Component | Observation |
|---|---|
| Ubuntu | WSL Ubuntu 24.04.5 LTS |
| Python | Ubuntu system Python 3.12.3 |
| uv | 0.13.3; available in an interactive Ubuntu Bash shell |
| Research environment | `rosa-research/.venv/bin/python` absent |
| Phoenix environment | `rosa-evaluation/tools/phoenix/.venv/bin/python` absent |
| ROS | Jazzy; desktop 0.11.0 and ros-gz 1.0.24 packages installed |
| ROS Python | System Python imports `/opt/ros/jazzy/lib/python3.12/site-packages/rclpy`; research-venv import not yet tested |
| Gazebo | 8.15.0; no new physics or graphical performance test in this audit |
| GPU | NVIDIA RTX 4050 Laptop, 6141 MiB VRAM, driver 581.86; visible to Windows and WSL nvidia-smi |
| Host RAM | Approximately 15.7 GiB |
| WSL memory | 7.6 GiB total, approximately 7.0 GiB available during inspection, 2 GiB swap |
| Physical C: storage | Approximately 31 GiB free; 94% used |
| WSL filesystem | Reports 948 GiB virtual capacity available; this is not proof of equivalent free physical storage on the backing Windows drive |
| Ollama | Windows CLI 0.24.0; `ollama list` returned an empty model inventory |
| Ollama connectivity | WSL `127.0.0.1:11434` unavailable during audit; cross-host endpoint remains unverified |
| Phoenix connectivity | WSL `127.0.0.1:6006` unavailable during audit |

The Ollama CLI automatically attempted to start its desktop server when queried. No model download, intentional upgrade, or inference request was performed. nvidia-smi visibility does not establish successful GPU-backed model inference.

## Work needed for first live tests

1. Sync the existing locked research and Phoenix uv environments with Ubuntu system Python 3.12. Verify the ROSA import with the intended ROS environment sourced.
2. Start Phoenix and pass its existing ingestion/read-back smoke test and controlled dispatch/trace validation suite. These tests establish instrumentation behavior, not model quality.
3. Serve/download Qwen3.5 9B in a selected inference environment; verify WSL connectivity. Run short text inference and a genuine structured tool-call/output round trip. Record model digest, context, quantization, actual GPU/CPU offload, memory, and latency.
4. Implement a strictly allowed mock-tool surface and independent state evaluator before research task-success measurements. The current ROSA constructor appends built-in tools, so merely supplying mocks is insufficient isolation.
5. Implement and validate the OAuth-hosted adapter and user-controlled sign-in separately. The current live experiment runner constructs ChatOllama, and no OAuth adapter was found in the inspected application modules.
6. Run both backend baselines on a common controlled scenario suite through Phoenix before attributing gains to caching, JTVR, or memory.

## Resource considerations

The GPU's 6 GiB capacity, currently allocated WSL RAM, and physical disk headroom require measurement during Qwen startup. Full-GPU residency and useful latency are not established. Avoid running Gazebo during initial model profiling so contention does not obscure the model measurements. Neither JTVR nor episodic memory is a prerequisite for the initial baseline.

No source dependencies, model credentials, or physical robot controls were changed during this audit. The readiness-check script is `.local/audit-research-readiness.sh` in the shared workspace.
