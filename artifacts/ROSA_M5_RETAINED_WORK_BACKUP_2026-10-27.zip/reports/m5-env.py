import json
import os
from pathlib import Path
import shutil

print(json.dumps({'commands': {name: shutil.which(name) for name in ('ffmpeg', 'Xvfb', 'xvfb-run', 'gz', 'xwininfo', 'xdotool')},
    'display': {name: os.environ.get(name) for name in ('DISPLAY', 'WAYLAND_DISPLAY', 'XDG_RUNTIME_DIR')},
    'wslg': Path('/mnt/wslg').exists()}, indent=2))
launch = Path('/opt/ros/jazzy/share/ur_simulation_gz/launch/ur_sim_control.launch.py')
text = launch.read_text()
for line in text.splitlines():
    if any(word in line for word in ('world', 'gazebo_gui', 'gz_args', 'GZ_PARTITION')):
        print(line)
