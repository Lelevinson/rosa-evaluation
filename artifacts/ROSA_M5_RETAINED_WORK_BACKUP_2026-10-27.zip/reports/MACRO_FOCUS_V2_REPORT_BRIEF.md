# Final report focus requested by the user

User request, 2026-10-26 Asia/Taipei: prepare the report when the running pilot
finishes. Central question: do macro and workflow save model calls without
sacrificing correctness, and does workflow add enough benefit over simple macro?

This is a reporting clarification. It changes no frozen case, model setting,
budget, outcome criterion, retention threshold or running source file.

Use the automatically generated artifacts/macro-focus-v2-20261026/REPORT.md
and analysis.json in rosa-evaluation. Keep the completed validation evidence
separate; combine discussion reports later as requested. Do not call the pilot
complete until both backend states, audits and cleanup are verified.

For Qwen and Sol separately, present primitives/macro/workflow correctness and
calls together. Show the exact paired cases where a candidate fails while its
reference succeeds, as well as candidate wins. Equal aggregate scores can hide
different failures. Report all-attempt calls/tokens/latency/native operations,
and matched-correct comparisons; cheap early failures are not efficiency gains.
Distinguish goal selection, grounded reporting, actual fault exercise, retry
policy compliance, model correction after feedback and program assistance.

Apply the existing frozen >=20% matched-correct call-saving screen against
primitives, with no paired correctness losses, >=6 matched-correct pairs/backend
and <=20% native-operation increase. For workflow versus macro, retain the
existing stricter benefit/reliability/native/latency requirements. Do not relax
these criteria after seeing results. Six case templates with two repetitions
do not establish statistical equivalence or broad generalization.

If macro meets the primitive-reference requirements and workflow demonstrates
no sufficient additional benefit, recommend the simpler macro. If neither
packaged condition meets its requirements, retain the primitive reference.
If either backend is incomplete or unaudited, state that limitation and do not
claim the full study supports retention. Preserve every failed/censored attempt.
