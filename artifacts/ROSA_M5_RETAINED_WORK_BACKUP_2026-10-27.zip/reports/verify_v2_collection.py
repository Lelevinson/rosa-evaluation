"""Read-only verification of the sealed collection; receipt stays outside it."""
import hashlib
import json
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parents[1]
artifacts=root/'rosa-evaluation/artifacts'
archive=artifacts/'ROSA_RELIABILITY_V2_UR5E_COMPLETE_EVIDENCE_2026-10-22.zip'
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    manifest=json.loads(zipped.read('reliability-v2-ur5e-review-20261022/MANIFEST.json'))['files']
    for name,digest in manifest.items():
        assert hashlib.sha256(zipped.read(name)).hexdigest()==digest,name
        assert hashlib.sha256((artifacts/name).read_bytes()).hexdigest()==digest,name
review=json.loads((artifacts/'reliability-v2-ur5e-review-20261022/independent-review.json').read_text())
assert review['pass'] and not review['errors']
assert review['live_trials']==96 and review['model_calls']==482
assert review['auth']['session_cleanup']=='REVOKED'
assert review['original_session_auth']['session_cleanup']=='REVOKED'
trials=[]
for campaign,phases in (('reliability-v2-20261022',('validation','mock')),('ur5e-transfer-v1-20261022',('gazebo',))):
    for phase in phases:
        audit=json.loads((artifacts/campaign/(phase+'-phoenix-all.json')).read_text())
        assert audit['pass']
        for backend in ('siwc','ollama'):
            status=json.loads((artifacts/campaign/phase/backend/'result.json').read_text())
            assert status['status']=='COMPLETE'
            trials.extend(status['trials'])
assert len(trials)==96
assert sum(r['model_calls'] for r in trials)==482
assert sum(r['score']['pass'] for r in trials)==86
old_archives={
    'ROSA_STAGE4_COMPLETE_EVIDENCE_2026-10-21.zip':'44bae743969d473359e5e6dcead7c89226851286a45c2d439ddf8a091a63b76c',
    'reliability-v1-20261022-evidence.zip':'2bd6963cd27e01df9e86df9a7f9fbd1d84dba03e52c3fb85d42d86ea717e51a5',
    'ROSA_RELIABILITY_V1_COMPLETE_REVIEW_2026-10-22.zip':'9546d2bfb2dd371cbf694ba17b3b016728c9c6df90ece24606df0f0264c8117f'}
for name,digest in old_archives.items():
    assert hashlib.sha256((artifacts/name).read_bytes()).hexdigest()==digest,name
simulators=[]
for path in Path('/proc').glob('[0-9]*/cmdline'):
    try:
        cmd=path.read_bytes().replace(b'\0',b' ').decode(errors='replace')
    except (FileNotFoundError,PermissionError,ProcessLookupError):
        continue
    if 'ros2 launch ur_simulation_gz ' in cmd or ('gz sim ' in cmd and 'empty.sdf' in cmd):
        simulators.append({'pid':path.parent.name,'command':cmd})
assert not simulators,simulators
receipt={'pass':True,'live_trials':96,'correct_final_outcomes':86,'model_calls':482,
    'manifest_members':len(manifest),'archive_bytes':archive.stat().st_size,
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'older_archives_unchanged':list(old_archives),'active_simulator_processes':simulators}
(root/'reports/RELIABILITY_V2_UR5E_FINAL_VERIFICATION.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt),flush=True)
