# Active work: ordered reliability study and full-arm Gazebo transfer

UPDATE: original background campaign completed all80 model validation/mock
trials, then failed its first independent UR5e reset. Session revoked and all
records preserved. Continuing in a separately frozen readiness-corrected arm
follow-up: see reports/UR5E_TRANSFER_V1_ACTIVE.md. Notes below are historical.

User authorized all four steps on 2026-10-22. Preserve all previous artifacts.

1. Fresh prospective validation of schema/recovery/budgets/traces on Qwen and Sol.
2. Separate four-arm main mock study with fixed comparable budgets and independent
   scoring of physical state, invalid attempts, raw claims, assistance and cost.
3. UR5e six-axis Gazebo Harmonic / ROS 2 Jazzy deterministic skill and independent
   actual-state observer. Establish controls before model access.
4. Both models, same skills, reference/improved and matched deterministic controls.

Earlier reliability v1 completed72 trials but was a one-joint engineering screen
with ceiling effects, not a full-arm or confirmatory research result. Its named
verifier rule added artificial costs. New EvidenceSession accepts genuine fresh
read evidence in every arm; old runtime class and frozen experiments stay intact.

## Live checkpoint: validation complete; main mock comparison running

User completed explicit initial OAuth consent. Sol8/8 and Qwen8/8 fresh validation
outcomes passed. All16 persisted Phoenix traces exactly match local span-ID sets;
no missing spans.60 offline tests and40 scripted controls passed before freezing.
41 source files frozen under artifacts/reliability-v2-20261022/freeze.json.
Do not edit any frozen source/protocol/test. New analysis/operator scripts live
under reports/ and are not part of the agent runtime.

Campaign root: rosa-evaluation/artifacts/reliability-v2-20261022.
Hosted Linux PID27029, one memory-only renewable session across all phases,
hard384 model requests /48 trials. Its interactive_session waits up to30min for
initial consent (already done), then gates between validation/mock/arm phases.
Main mock phase:32trials/backend, A/B/C/D,8 heterogeneous cases,5achievable and
3fault cases; per-phase model cap256. Arm transfer:8trials/backend A/D on4cases,
model cap64. Same8calls/16tools/10native/180s/3corrections/onewrite trial limits.

Detached Windows orchestrator PID16728: reports/v2-orchestrate.ps1. Sequential
Solvalidation -> Qwenvalidation -> fullPhoenixaudit -> validationgate -> Solmock
-> Qwenmock -> fullPhoenixaudit -> install official UR5e packages through WSLroot
-> deterministic4case fullarmcontrols -> armgate -> SolGazebo -> QwenGazebo ->
fullPhoenixaudit -> unloadQwen, stoptemporarypowerhold, finalreceipt.
Logs: reports/v2-orchestrator-{output,errors}.log; campaign/operator/{hosted,
local-validation,local-mock,local-gazebo,phoenix-*,arm-install,arm-control}.log.
Failure writes false pending gates so hosted cleanup revokes rather than waiting
forever. No automatic new consent, inference replay or trial rerun.

Detached evidence finisher PID21800: reports/v2-finish.ps1. Waits for ordered
live phases plus OAuth/power cleanup, snapshots operator source, runs independent
reports/v2-review.py, writes fullreport + replay/comparisonJSON + manifest + ZIP.
Receipt reports/RELIABILITY_V2_FINISHER.json; final log reports/v2-final-review.log.
Final ZIP ROSA_RELIABILITY_V2_UR5E_COMPLETE_EVIDENCE_2026-10-22.zip in eval artifacts.
Do not reseal/overwrite if already produced; improvements become separateaddenda.

Temporary Windows monitor PID36448: reports/v2-monitor.ps1, no permanent power
plan change. First monitor attempt released immediately due sandbox metadata
access; attempt1 receipts preserved. Current monitor restarted unsandboxed with
resource-query failures caught. Current power-release.json is from attempt1
until final release: require released_utc >= current power-hold.started_utc.
Model runtime matches v1: digest56671c2...,context8192, size6.402GB,
VRAM3.494GB; Q4_K_M. qwen-runtime-initial.json and resource CSV saved.

Keep all earlier data unchanged. No new commit/push requested or performed.
Package final review independently checks every source digest,96planned live
trials, all actual traces/counters/caps, mock state replay at claim time, rejection
attribution (busy vs unsafe vs malformed), deterministic controls and revocation.
Review/packaging source is post-registration analysis, preserved separately.

Use one memory-only OAuth session per sequential hosted campaign, live token
callback, renewal preflight and explicit checkpointed trial boundaries. New
consent stays manual. Keep8model/16tool/10native/180s/3corrections/onewrite caps.
Do not tune after live results. New source freeze must include auth maintenance.
