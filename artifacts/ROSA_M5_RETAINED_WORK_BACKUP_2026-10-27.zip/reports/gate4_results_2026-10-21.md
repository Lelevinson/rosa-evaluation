# ROSA engineering tests through Gate 4

Date: 2026-10-21 (Asia/Taipei). **All three planned batches are complete and their saved execution evidence is audited. Qwen failed the provisional baseline usefulness target.**

The stateful benchmark, independent scoring and cache experiments are implemented. Both candidate models use the same modified ROSA executor and six simulation tools. Testing completed 120 live trials and 540 scripted control trials. All 120 live traces and all 540 scripted execution records passed their evidence audits. This completes the initial engineering pass through Gate 4; it does not mean every readiness criterion passed.

## Scope and evidence

This first live feasibility subset uses 12 distinct scenarios from six families, with three baseline repetitions (36 trials), plus 24 matched cache trials on reading/transfer cases per model. It does **not** complete the master plan's proposed 60-distinct-scenario live study. The scripted control covers all 60 generated scenarios under all three policies with three repetitions (540 trials). Repetitions and shared templates are not independent tasks or independently authored held-out families.

The frozen [protocol](gate4_protocol_2026-10-21.md) defines the task contract and provisional 80% terminal-handling target. Each trial creates a fresh process-separated world, cache and ROSA agent. The agent's tool channel cannot query the hidden oracle or scorer. Structured claims are scored against state and verification evidence; assistant narrative is retained but not semantically graded. Action acceptance and report acknowledgement do not establish success.

## Baseline candidates

| Candidate | Completed baseline handling | Achievable goals verified with operational completion | Principal observed limitations |
| --- | ---: | ---: | --- |
| Local `qwen3.5:9b`, Q4_K_M | 23/36 (63.9%) | 17/18 | Six failed-action retry loops, six failure/unknown classification errors, one CUDA error |
| Hosted `gpt-6.1-sol`, ChatGPT OAuth | 29/36 (80.6%) | 18/18 | Six correctly classified unknowns omit mandatory verification; one transport timeout |

The hosted backend narrowly clears the provisional point-estimate target; the small scenario-level interval remains wide. Its classification accuracy without the verification-coverage requirement is 35/36. These missing checks remain contract failures even though the unknown labels are accurate. See the [hosted report](gate4_hosted_results_2026-10-21.md).

Qwen failed the provisional 80% target. All six accepted-but-failed cases retried until the 14-call limit; all six unavailable-sensor cases reported failure instead of unknown. The remaining baseline failure was a CUDA error after placement, before required final verification/reporting. The hidden oracle confirms the actual achievable goal state in 18/18 cases for both models; Qwen completed the verification/reporting contract in 17/18. Its baseline median was 94.09 seconds, p95 132.26 seconds. Its scenario-clustered handling interval is approximately 36.1%-88.9%; do not read the small pilot as a precise population estimate.

| Family | Qwen baseline correctly handled | Hosted baseline correctly handled |
| --- | ---: | ---: |
| Repeated readings | 6/6 | 6/6 |
| Ordinary transfer | 5/6 | 6/6 |
| Accepted-but-failed action | 0/6 | 5/6 |
| External state change | 6/6 | 6/6 |
| Unavailable sensing | 0/6 | 0/6 |
| Unauthorized-arm refusal | 6/6 | 6/6 |

Neither live backend made a recorded false/unsupported structured success claim or attempted a prohibited arm. No unsafe mock execution was found. This is evidence about the enforced simulation contracts, not physical robot safety.

The local model uses 8,192 context, 256 output tokens per generation, temperature 0, seed 42, reasoning off and explicit memory-mapped loading. The installed digest is `56671c2ab9385f9cfcb404638e32cd62d88e3501d44822208363c010179a3c90`; Ollama is 0.40.6 on the prepared RTX 4050 Laptop 6 GB host. Hosted sampling is model-default. Both receive the same task schemas, seeds, controller, scorer, 14-call and 240-second per-trial limits. Transport socket limits differ (hosted 30 seconds, local 300 seconds within the trial deadline), so operational results are not a controlled claim of intrinsic model superiority. CUDA failures belong to the tested system configuration, not solely model competence.

## Cache mechanism

In the scripted stress control, conservative caching saved **25% of eligible sensor reads** (600 to 450), preserved all 420 mandatory reads and served zero stale observations. Naive TTL served **120 stale observations** and caused 60 additional mandatory reads through rejected stale plans. The independent controller prevented unsafe executions. All 540 scripted tasks received their correct terminal handling. See the [control report](gate4_control_results_2026-10-21.md).

In the hosted matched cache trials, both policies saved 6/24 eligible reads (25%), preserved mandatory reads and saved **zero model calls**. Conservative caching saved about 307 ms of measured eligible sensor-backend time in aggregate. The small four-scenario end-to-end interval includes zero improvement; a reliable agent speedup is not established. The live reading/transfer subset did not exercise the stale-read weakness exposed by the control.

Qwen's cache policies also saved 6/24 eligible reads (25%). TTL completed 12/12 trials; conservative caching completed 11/12, with the other trial reaching a verified goal and correct report before a 240-second final-response timeout. Each cache arm used 78 model calls versus 76 in the paired baseline: no model calls were saved. The baseline's CUDA interruption explains its one fewer mandatory read (29 versus 30) and missing final verification. These failures stay in all paired operational comparisons; neither an extra verified goal nor the timing difference can be attributed to caching from this pilot. Conservative caching's paired median wall-time saving was -0.39 seconds and its scenario-bootstrap mean-saving interval was approximately -45.52 to +1.93 seconds. It saved about 299 ms of eligible sensor-backend time in aggregate. No reliable end-to-end speedup is demonstrated by either model.

TTL is five logical simulation tool-step ticks, not real elapsed time. The repeated-read tasks deliberately contain reusable requests and injected zero/100 ms read costs. These results do not establish real sensor cost, prevalence of redundant reads, or suitability for requests requiring independent fresh measurements. Commands and verification are never cached. The recorded policy-computation counter covers lookup/pre-call work; post-call writes/invalidation remain in end-to-end time.

## Audits and reproducibility

All 120 live traces passed model/tool-count, registry, trace-completeness and independent oracle/controller-contract checks. The auditor reconstructs revision, battery, location and holding state and checks cached staleness labels independently. All 540 scripted execution records passed the corresponding execution-only audit; tracing was disabled for that control. Eight controlled Phoenix validation cases and the focused boundary, scorer, cache, OAuth and shared-adapter tests passed. Five auditor tests reject fabricated unsafe accepted calls, incorrect goal/counter labels, stale accepted revisions and corrupted state/staleness evidence.

The [source-integrity check](gate4_source_integrity_2026-10-21.json) confirms the captured task/runtime files match their pre-run hashes. The post-run comparison generator has changed to separate failure categories and expose state outcomes before operational-completion filtering. Machine/package metadata is in the [environment snapshot](gate4_environment_observed_2026-10-21.json); it is a mid-run observation, not a pre-registered resource profile or measured peak.

Batch evidence:

- [Scripted 540-trial batch](../rosa-evaluation/results/runs/0df4a888-fce1-440a-b278-bc2f4fefb33f/result.json).
- [Local Qwen 60-trial batch](../rosa-evaluation/results/runs/95c716b2-0ea8-4dea-aab1-00b0b55744bd/result.json) and [audit](../rosa-evaluation/results/runs/95c716b2-0ea8-4dea-aab1-00b0b55744bd/phoenix/audit.json).
- [Hosted 60-trial batch](../rosa-evaluation/results/runs/a879ad0e-d5b6-4f47-bdfd-bacab7b7a12e/result.json) and [audit](../rosa-evaluation/results/runs/a879ad0e-d5b6-4f47-bdfd-bacab7b7a12e/phoenix/audit.json).
- [Machine-readable comparison](../rosa-evaluation/results/gate4-comparison/comparison.json) and [trial CSV](../rosa-evaluation/results/gate4-comparison/trials.csv).

Hosted OAuth tokens remained in memory and the session was revoked. No refresh was needed during the live batch; refresh rotation is covered by offline tests. Hosted usage was 365 model requests and 586,763 reported tokens; local usage was 460 requests and 1,082,005 reported tokens. Failed streams lack completed usage, so these are reported usage counts rather than complete billing totals. Qwen's summed trial wall time was about 78.7 minutes; this is not a cold/warm resource profile. Its model was unloaded after completion to release memory; Ollama and Phoenix remain running. Source changes remain local and uncommitted on `member/martin` in each repository. No branch was pushed.

## Decision boundary

Conservative invalidation has a measured read-work benefit in this toy workload. That is enough to retain it as the simple comparator, but not enough to justify JTVR complexity. A public-observation rule-only control solves every generated case, so these fixtures establish engineering behavior rather than a novel reasoning contribution.

The baseline fault/verification protocol needs improvement and a new frozen validation run before adding JTVR or episodic memory. Any prompt, controller or orchestration fix must be reported as an intervention; preserve this baseline and do not silently replace its failed trials. The larger live scenario study and independently authored held-out families remain outstanding. Physical robot readiness and safety are outside this evidence.
