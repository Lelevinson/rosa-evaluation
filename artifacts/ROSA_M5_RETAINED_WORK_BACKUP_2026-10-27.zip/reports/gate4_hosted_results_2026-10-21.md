# Hosted stateful baseline and cache pilot

Date: 2026-10-21 (Asia/Taipei). Model: `gpt-6.1-sol`, selected from the signed-in account catalog. Batch `a879ad0e-d5b6-4f47-bdfd-bacab7b7a12e` completed all 60 planned trials: 36 baseline trials and 12 trials for each cache policy.

## Baseline

- Full terminal-handling contract: **29/36 (80.6%)**. This narrowly clears the provisional 80% engineering point-estimate target; it is not a statistical reliability guarantee. The scenario-clustered descriptive interval is wide, approximately 55.6%–100%.
- Achievable goals independently verified: **18/18** (reading, ordinary transfer and external-change recovery).
- Outcome classification without the verification-coverage requirement: **35/36**. In all six missing-sensor cases the model correctly reported `unknown` but skipped the explicitly required `verify_goal` call. These are instruction/check-coverage failures, not false-success claims.
- One accepted-failure case suffered a 30-second socket read timeout before completing inference. It remains in the baseline completion denominator.
- Zero false-success claims, unsupported-success claims, prohibited-arm attempts or unsafe mock executions were observed.
- Median baseline wall time: **17.37 seconds**; p95: **32.67 seconds**. These include the test's injected sensor costs and framework overhead, and are not real-robot timings.

## Paired caching

Both TTL-only and conservative caching completed all 12 matched reading/transfer trials correctly. Each saved **6 of 24 eligible sensor reads (25%)**, changed mandatory reads by zero, and saved **zero model calls**. The actual agent did not make enough redundant post-action reads in these live cases to expose the TTL invalidation weakness; that weakness appears in the separate [540-trial controlled stress suite](gate4_control_results_2026-10-21.md).

Conservative caching saved an aggregate approximately **307 ms** of measured eligible sensor-backend time across its 12 paired trials. Observed paired median wall-time saving was 0.85 seconds, but the scenario-bootstrap interval for the mean spans approximately **−0.03 to +1.64 seconds** with only four distinct scenarios. This does not establish a reliable end-to-end speedup. The measured sensor-work reduction and unchanged model-call count are the stronger conclusions.

## Evidence and limits

- [Raw batch report](../rosa-evaluation/results/runs/a879ad0e-d5b6-4f47-bdfd-bacab7b7a12e/result.json).
- [Full 60-trial trace/execution audit](../rosa-evaluation/results/runs/a879ad0e-d5b6-4f47-bdfd-bacab7b7a12e/phoenix/audit.json): all model counts, tool counts, recorded goal predicates and independently checked controller contracts matched. Each trial's Phoenix export is under its own run directory.
- 365 model requests; 586,763 reported tokens. The failed stream has no completed usage report, so this is reported usage, not a complete billing measurement.
- Tokens remained in memory; session cleanup was `REVOKED`. No refresh was needed during this batch (`refresh_count: 0`); rotation is covered by offline tests, not demonstrated by this live run.
- This is a 12-scenario engineering subset with three repetitions, not completion of the full planned 60-scenario live pilot. Reserved cases share generator/template families with development cases.
- The hosted and local clients use different transport timeouts. Compare operational completion transparently; do not infer model parity from these results.
- Repeated-reading tasks deliberately include eligible redundant requests. Their cache benefit does not establish the prevalence of redundancy in real workflows or apply to requests requiring independently fresh measurements.

The hosted backend handles these achievable tasks well, but it still needs mandatory-check enforcement before a more autonomous robotics workflow. This batch does not justify physical actuation or a JTVR novelty claim.
