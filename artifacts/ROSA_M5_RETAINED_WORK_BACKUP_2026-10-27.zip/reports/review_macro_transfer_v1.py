"""Human review supplement after the immutable experiment archive is complete."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
CAMPAIGN = ROOT / 'rosa-evaluation/artifacts/macro-transfer-v1-20261022'
ARCHIVE = CAMPAIGN.parent / 'ROSA_MACRO_TRANSFER_V1_EVIDENCE_2026-10-22.zip'
OUTPUT = ROOT / 'reports/MACRO_TRANSFER_V1_COMPLETE_REVIEW_FOR_CHATGPT.md'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    assert read(CAMPAIGN / 'operator/finalizer-status.json')['status'] == 'COMPLETE'
    analysis, review, freeze = [read(CAMPAIGN / name) for name in
                               ('analysis.json', 'independent-review.json', 'freeze.json')]
    assert analysis['complete'] and review['evidence_audit_pass']
    with ZipFile(ARCHIVE) as archive:
        manifest = json.loads(archive.read('evidence-manifest.json'))
        assert archive.testzip() is None
        assert all(hashlib.sha256(archive.read(name)).hexdigest() == value for name, value in manifest.items())
        for name, value in freeze['files'].items():
            archived = (CAMPAIGN / 'source' / name).relative_to(ROOT).as_posix()
            assert manifest[archived] == value and hashlib.sha256(archive.read(archived)).hexdigest() == value
    all_rows = []
    for backend in ('ollama', 'siwc'):
        all_rows.extend(read(CAMPAIGN / 'gazebo' / backend / 'checkpoint.json')['trials'])
    summaries = analysis['summaries']
    lines = ['# ROSA strong macro reference: complete review for ChatGPT', '',
        'This report supplements the immutable evidence ZIP. It was written after sealing, so it '
        'is intentionally external to that ZIP. All primary scores and old campaigns are unchanged.', '',
        '**Verdict:** the simple macro captures the same acquisition policy as the existing workflow. '
        'The experiment provides descriptive evidence about bundling under the tested shared configuration; '
        'it does not establish a novel tool-selection algorithm. A shared default-system-prompt mismatch '
        'was discovered during review and must be fixed before a larger, clean evaluation.', '',
        '## Complete results', '',
        '| Backend | Condition | Correct / 6 | Calls | Input tokens | Generated tokens | Native ops | Invalid attempts | Trial seconds total |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for r in summaries:
        lines.append(f'| {r["backend"]} | {r["condition"]} | {r["correct"]}/6 | {r["calls"]} | '
            f'{r["input_tokens"]} | {r["output_tokens"]} | {r["native_operations"]} | '
            f'{r["invalid_attempts"]} | {r["wall_seconds"]:.2f} |')
    lines += ['', 'All-attempt totals include unsuccessful trials. Failing early is not an efficiency gain. '
        'Latency is summed in-trial wall time, not end-to-end batch duration; reset/control/startup, '
        'serialization wait and post-trial persisted-span audit costs are recorded separately.', '',
        '## Paired cases', '',
        'Each cell is `primary correctness / model calls / native operations`. '
        'There is one run per case and condition, no outcome-based replacement or tuning.', '',
        '| Backend | Case | Primitive tools | Macro | Workflow |',
        '| --- | --- | --- | --- | --- |']
    for pair in analysis['paired_cases']:
        cells = [pair['conditions'][c] for c in ('model', 'macro', 'workflow')]
        lines.append(f'| {pair["backend"]} | {pair["case"]} | ' + ' | '.join(
            f'{"PASS" if c["correct"] else "FAIL"} / {c["calls"]} / {c["native"]}' for c in cells) + ' |')
    lines += ['', '## Fault exercise and unsupported reports', '',
        '| Backend | Condition | Exercised / completed fault cases | Unsupported structured SUCCESS attempts | Censored trials |',
        '| --- | --- | ---: | ---: | ---: |']
    for r in summaries:
        lines.append(f'| {r["backend"]} | {r["condition"]} | {r["faults_exercised"]}/{r["fault_cases_completed"]} | '
            f'{r["unsupported_success_attempts"]} | {r["censored_trials"]} |')
    lines += ['', 'Fault coverage is distinct from primary correctness: a fault can be exercised but '
        'the model can still fail to finish/report. Primary correctness also requires the correct selected '
        'skill, exact required dispatch count, correct commanded goal, fresh supported classification, '
        'normal validated termination and independent outcome. No-effect motions must actually be attempted; '
        'truthful failure without an attempt does not pass this campaign.', '',
        '## Predeclared macro retention screen', '', '```json', json.dumps(review['retention_screen'], indent=2), '```', '',
        'This is the frozen engineering screen, not a statistical equivalence/non-inferiority test. '
        'A one-call difference still counts under it. Do not redefine a failed screen after seeing results. '
        'The newly identified prompt-contract inconsistency separately blocks progression to a larger clean '
        'study even if a backend passes this numerical screen.', '',
        '## Task failures', '']
    for row in all_rows:
        if row['score']['pass']:
            continue
        lines += [f'### {row["backend"]} / {row["case"]} / {row["condition"]}', '',
            f'Calls: {row["inference"]["calls"]}; generated tokens: '
            f'{row["inference"]["known_output_tokens"]}; native operations: {row["native_operations"]}; '
            f'invalid attempts: {row["score"]["invalid_attempts"]}; seconds: {row["wall_seconds"]:.2f}.', '',
            'Accepted report: ' + str(row['score']['accepted_report_status']) + '; independent requested-goal attainment: '
            + str(row['score']['requested_goal_attained']) + '.', '',
            'Recorded answer:', '', '```text', row['answer'], '```', '']
    lines += ['## Execution, observability and reproducibility', '',
        f'{len(all_rows)} live trials completed. All were audited locally and matched actual persisted Phoenix '
        'span IDs/closed trees. Scores were recomputed from saved raw evidence by the finalizer. '
        '40 offline test methods and 18 scripted ROSA/Phoenix checks passed before the freeze. '
        'Six initial deterministic UR5e controls and six before each live backend passed, using an independent '
        'read-only ROS observer. The initial Phoenix-unavailable preflight attempt remains in the archive.', '',
        f'All {len(freeze["files"])} frozen source files are included and reverified against ZIP bytes. '
        f'The ZIP has {len(manifest)} checksummed manifest entries. Both dependency lockfiles are included. '
        'The earlier original ZIP remains preserved; its missing uv.lock was supplied in a separate corrected '
        'complete archive. No old trial was rerun or rescored.', '',
        'Per trial: 8 model requests, 180-second external alarm, 16 tool attempts including bundled calls, '
        '10 native operations, one dispatched trajectory, three correction opportunities. Each backend '
        'has an overall ceiling of144 inference requests and4500 active batch seconds. Both models '
        'use identical controller guards and outcome verification within their comparisons.', '',
        'Qwen retains qwen3.5:9b Q4_K_M, the frozen model digest, Ollama0.40.6, num_ctx8192, temperature0, '
        'seed42, reasoning off and num_predict at most1024 per call reduced against2048 cumulative generated '
        'tokens. Hosted gpt-6.1-sol uses the existing OAuth adapter with an observed2048-token stopping '
        'threshold, not an equivalent hard generation cap. Cross-model resource equality is not claimed.', '',
        'Hosted session receipt:', '', '```json', json.dumps(read(CAMPAIGN / 'session-siwc.json'), indent=2), '```', '',
        'Tokens stayed in memory, consent remained manual, and session cleanup revoked authorization. '
        'Do not infer successful refresh testing solely from renewal support; inspect token_refreshes above. '
        'Simulators exited cleanly, Qwen was unloaded and temporary sleep holds were released. '
        'The finalizer helper waits for supervisors to exit before sealing. Its own terminal status '
        'receipt is written after sealing; any archived waiting status is a pre-seal snapshot.', '',
        '## Interpretation and recommended next steps', '',
        '1. Preserve this campaign, including its failures and the prompt-contract exception. '
        'The evidence supports further work on bounded bundling, not a claim of universal reliability '
        'or a new selection algorithm.',
        '2. Resolve the shared prompt/tool contradiction for both backends. An agent with only bounded '
        'skill tools should not retain mandatory instructions to call unavailable discovery/math tools. '
        'Validate the actual composed model input, not only tool schemas. Treat this as a separate '
        'prospective interface repair; do not silently rerun or rename these cases as fresh held-out tests.',
        '3. Keep the simplest bounded macro as the main candidate to investigate. The state-tracked '
        'workflow has no different acquisition policy in this prototype. Respect each numerical retention '
        'result, document small cost differences and avoid claiming one implementation has a proven '
        'architectural advantage from six cases.',
        '4. Only after repair validation, use independently designed cases and repeated paired trials '
        'to compare primitive tools and the simple bundle, retaining the workflow reference if needed. '
        'Measure unsupported claims, actual fault exercise, verified completion, model/native/token costs '
        'and latency together. Include heterogeneous robot skills before generalizing beyond pose selection.',
        '5. Do not add JTVR, episodic memory, a general planner, or physical-robot deployment to explain '
        'this pilot. Those remain separate optional directions.', '',
        '## Detailed interpretation and audit notes', '',
        (CAMPAIGN / 'INTERPRETATION_NOTES.md').read_text(), '',
        '## Evidence files', '',
        'Raw campaign: `rosa-evaluation/artifacts/macro-transfer-v1-20261022`.', '',
        'Immutable ZIP: `' + ARCHIVE.name + '`.', '',
        'SHA256: `' + hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() + '`.', '',
        'This external complete review: `reports/' + OUTPUT.name + '`.']
    OUTPUT.write_text('\n'.join(lines) + '\n')
    print(json.dumps({'report': str(OUTPUT), 'trials': len(all_rows), 'manifest_entries_verified': len(manifest),
                      'frozen_sources_verified': len(freeze['files'])}))


if __name__ == '__main__':
    main()
