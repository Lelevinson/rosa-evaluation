"""One-time scaffold for a new prospective campaign; never edits old campaigns."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / 'rosa-evaluation/experiments/workflow_reference_v1'
NEW = ROOT / 'rosa-evaluation/experiments/macro_transfer_v1'


def main():
    NEW.mkdir(exist_ok=False)
    (NEW / '__init__.py').write_text('')
    for name in ('inference.py', 'tracing.py', 'persisted.py'):
        content = (OLD / name).read_text().replace('workflow_reference_v1', 'macro_transfer_v1').replace(
            'rosa-workflow-reference-v1-20261022', 'rosa-macro-transfer-v1-20261022')
        (NEW / name).write_text(content)
    content = (OLD / 'runner.py').read_text()
    replacements = {
        'workflow_reference_v1': 'macro_transfer_v1',
        'workflow-reference-v1': 'macro-transfer-v1',
        'request_cap\': 64': 'request_cap\': 144',
        "status['total_model_calls'] >= 64 or batch_counter['calls'] >= 128":
            "status['total_model_calls'] >= 144 or batch_counter['calls'] >= 144",
        'request_budget=128': 'request_budget=144',
        "'request_cap': 128": "'request_cap': 144",
        "spec, program = job['case'], job['program']":
            "spec, condition = job['case'], job['condition']\n            program = condition != 'model'",
        "run_id = f'{index:02d}-{spec[\"id\"]}-{\"program\" if program else \"model\"}'":
            "run_id = f'{index:02d}-{spec[\"id\"]}-{condition}'",
        "class EvaluatedSession(WorkflowSession):":
            "session_type = MacroSession if condition == 'macro' else WorkflowSession\n\n            class EvaluatedSession(session_type):",
        "'case': spec['id'], 'program_managed': program,":
            "'case': spec['id'], 'condition': condition, 'program_managed': program,",
        "request = query(spec, program, phase)": "request = query(spec, condition, phase)",
        "configure_fault(controller, spec)\n                controller.records.clear()\n                transport = controller":
            "configure_fault(controller, spec)\n                controller.records.clear()\n                transport = FaultTransport(controller, spec)",
        "run_backend(args.backend, llm, 'mock', counter, transport)\n            wait_mock_gate()\n            with gazebo_lock():":
            "with gazebo_lock():",
    }
    for old, new in replacements.items():
        if old not in content:
            raise RuntimeError('missing replacement: ' + old)
        content = content.replace(old, new)
    start = content.index('def score(')
    end = content.index('\ndef unload_local', start)
    content = content[:start] + 'from .scoring import score\n\n' + content[end:]
    start = content.index('def wait_mock_gate():')
    end = content.index('@contextmanager\ndef gazebo_lock', start)
    content = content[:start] + content[end:]
    content = content.replace('from .design import LIMITS, catalogue, PilotTransport, jobs, query',
        'from .design import LIMITS, catalogue, PilotTransport, FaultTransport, jobs, query\nfrom rosa_reliability.macro import MacroSession')
    content = content.replace('timeout=1800', 'timeout=1800')
    # The absolute trial alarm is unchanged. Backend time includes all trial overhead.
    content = content.replace('time.monotonic() + 2700', 'time.monotonic() + 4500')
    (NEW / 'runner.py').write_text(content)
    content = (ROOT / 'reports/workflow-reference-v1-run.ps1').read_text().replace(
        'workflow-reference-v1', 'macro-transfer-v1').replace('workflow_reference_v1', 'macro_transfer_v1')
    (ROOT / 'reports/macro-transfer-v1-run.ps1').write_text(content)
    print('Created new opt-in campaign; original runtime and artifacts unchanged.')


if __name__ == '__main__':
    main()
