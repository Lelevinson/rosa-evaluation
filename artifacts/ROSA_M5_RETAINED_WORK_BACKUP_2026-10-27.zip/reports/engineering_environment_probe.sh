#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
echo '=== runtime ==='
id
command -v gz || true
ls /usr/bin/gz* /opt/ros/jazzy/opt/gz_tools_vendor/bin/gz 2>/dev/null || true
gz sim --versions || true
ros2 pkg prefix ros_gz_bridge
echo '=== existing services ==='
ps -eo pid,args | grep -E 'phoenix|ollama|gz sim|rosa' | head -18 || true
echo '=== configuration names ==='
/home/martin/.local/share/rosa-envs/research/bin/python - <<'PY'
from pathlib import Path
from dotenv import dotenv_values
from importlib.metadata import version
p = Path('/mnt/c/Proj/robotics/introtorobotics/rosa-evaluation/.env')
for key, value in dotenv_values(p).items():
    if key in ('OLLAMA_BASE_URL', 'PHOENIX_COLLECTOR_ENDPOINT', 'PHOENIX_PORT', 'ROSA_OTLP_ENDPOINT', 'SIWC_MODEL'):
        print(key, value)
for pkg in ('langchain-core', 'pydantic', 'opentelemetry-sdk'):
    print(pkg, version(pkg))
PY
