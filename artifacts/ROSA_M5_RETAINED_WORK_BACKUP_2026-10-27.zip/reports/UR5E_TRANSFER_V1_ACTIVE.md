# Active follow-up: readiness-corrected six-axis UR5e comparison

## FINAL COMPLETE — supersedes all running notes below

All requested experiments finished across the preserved original campaign and
separate readiness-corrected follow-up.96live trials,86correct outcomes,
482modelcalls across both backends; all96persisted Phoenix trace sets match.
ValidationSol8/8,Qwen8/8. MainmockSol32/32,Qwen28/32 (A6,B8,C8,D6 of8 each).
FullUR5eSol8/8,Qwen2/8 (A1/4,D1/4); local six numeric-state cases ended with
actual provider length termination at256tokens before any movement command.
Two unavailable-sensor cases correctly reported UNKNOWN after guard assistance.
Four deterministic arm controls passed. No observed combined-D retention benefit.
Interfacegoal_verified/nestedverificationambiguity remains a documented limitation.

Combinedreport:rosa-evaluation/artifacts/reliability-v2-ur5e-review-20261022/REPORT_FOR_CHATGPT.md.
EvidenceZIP:ROSA_RELIABILITY_V2_UR5E_COMPLETE_EVIDENCE_2026-10-22.zip,7020733bytes,
SHA25663188649d0c21bd7f0b9a8a70bce01de88b5d2df45845486aafa884d68cadae6.
554manifestmembers independently match ZIP AND current files. All three older
evidence ZIP hashes unchanged. No active simulator process. Both OAuth sessions
REVOKED; Qwen unloaded; temporary sleep hold released. No batch/consent pending.
Finalreceipt reports/RELIABILITY_V2_UR5E_FINAL_VERIFICATION.json.
Supervisor COMPLETE receipt reports/UR5E_TRANSFER_V1_ORCHESTRATOR.json.
No new Gitcommit or push performed. Do not overwrite/reseal this completed ZIP;
any further report clarification must be an explicit separate addendum.

CORRECTION: Qwen completed32 mock trials but passed28, not32. ItsA/D6/8 and
B/C8/8;Sol32/32. Earlier tail-log-based message and frozen follow-up background
statement were wrong; explicit erratum BACKGROUND_CORRECTION.md preserves the
correction without changing frozen protocol/scores. Solarm8/8 passed; Qwenarm
running and firsttwo coordinated moves failed after unfinished prose, with actual
Ollama metadata done_reason=length/eval_count=256 on second model generation.
Do not change output cap or rerun frozen trials. Postrun analysis records every
length-terminated LLM span, model rejection attribution and pre-write confounds.

User returned after a chat usage limit and asked whether work was interrupted.
Evidence: background continued and completed BOTH32/32 mock matrices and all64
persisted Phoenix trace audits. Earlier16/16 fresh validation audits also passed.
The old pipeline then stopped at independent_home_reset_failed before any model
arm trial. Original session REVOKED; Qwen unloaded; power released. Failed
orchestrator/finisher receipts and original sources/results are preserved.

Diagnosis: joint-state publication is not trajectory-controller readiness. A
separate model-free diagnostic explicitly waited for both controllers active and
the independently observed reset passed. New experiments/ur5e_transfer_v1 clones
the arm runner but adds an outside-trial ListControllers readiness prerequisite.
Two targeted regression tests and all four deterministic controls passed.
New36-file freeze: rosa-evaluation/artifacts/ur5e-transfer-v1-20261022/freeze.json.
DO NOT edit frozen source. Original v2 source remains unchanged. Task targets,
faults, A/D interface, budgets, three-second trajectories/four-second settling
and reporting ambiguity remain unchanged; this is a separate startup correction.

User completed fresh manual OAuth consent. Hosted Linux PID454 running8Gazebo
trials, cap64requests; session remains memory-only and will revoke afterward.
Windows supervisor PID30732 reports/ur5e-orchestrate-v1.ps1 waits hosted completion,
starts local services/Qwen8trials sequentially, independently retrieves all16
Phoenix traces in rosa-ur5e-transfer-v1-20261022, unloadsQwen, releases power,
then runs reports/v2-review.py to audit/package BOTH original80 and follow-up16.
MonitorPID32296, reports/ur5e-monitor-v1.ps1, temporaryhold only in newcampaign.
Logs reports/ur5e-orchestrator-{output,errors}.log, campaign/operator/{hosted,
local,phoenix,services}.log; final reports/ur5e-combined-review.log and
reports/UR5E_TRANSFER_V1_ORCHESTRATOR.json. Original FAILED receipts unchanged.

Review source now reads old validation/mock and new Gazebo roots separately;
checks BOTH source snapshots; preserves old failure; writes combined report in
rosa-evaluation/artifacts/reliability-v2-ur5e-review-20261022/REPORT_FOR_CHATGPT.md.
ZIP ROSA_RELIABILITY_V2_UR5E_COMPLETE_EVIDENCE_2026-10-22.zip includes both
separate campaign roots and review with exact SHA256 manifest. No successful
sealed bundle exists yet. If audit fails, fix analysis errors without changing
frozen data. Do not overwrite a completed ZIP: create explicit addenda instead.

Latest live checkpoint: hosted3/8 allcorrect/localtraceauditspass; controller
readiness records show transitions through inactive to active before release.
Qwen not started yet. Phoenix restarted successfullyPID483 with existing local
data directory. No new consent pending. No Gitcommit/pushrequested/performed.
