# Workflow live v1 — active pilot

FINAL: COMPLETE. Both supervisors exited, hosted session REVOKED, local model
unloaded and temporary sleep holds released. All 24 trials and persisted traces
are accounted for. No Gazebo trials were started.

| Backend | Reference correct | Program correct | Calls reference / program | Native reference / program | Gate |
| --- | ---: | ---: | ---: | ---: | --- |
| Qwen | 6/6 | 5/6 | 35 / 28 | 19 / 24 | FAIL: paired reporting loss |
| Sol | 6/6 | 6/6 | 29 / 15 | 16 / 17 | PASS: small pilot only |

Both-backend progression gate: FAIL. Keep the workflow candidate exploratory;
do not advance it as a validated improvement for both models. The failed Qwen
case recognized UNKNOWN but repeatedly omitted the leading slash in /bench_arm
when reporting. No unsafe dispatch or accepted unsupported success occurred.
Earlier results and protocol scores remain unchanged.

Final analysis: `rosa-evaluation/artifacts/workflow-live-v1-20261022/analysis.json`.
Detailed report: `.../DETAILED_REVIEW_FOR_CHATGPT.md`.

The launch record below is retained as history, not current process status.

Frozen 2026-10-22. Vision unchanged: reusable ROSA reliability/efficiency changes
around existing backends; no model training or mandatory JTVR/memory.

Approved scope: 24 mock trials total, six cases and two conditions per backend.
Qwen and Sol are compared separately against their own model-managed reference.
No Gazebo or physical-robot deployment in this pilot.

- Preflight: nine new control tests passed; six scripted local traces exactly
  matched complete Phoenix server-side traces.
- Source/cases/model digest: frozen before live inference (45 files).
- Qwen supervisor: started, PID 26736.
- Sol supervisor: started, PID 27628; awaits manual browser OAuth consent.
- Both supervisors have temporary sleep holds, released on completion/failure.
- Each backend: 12 trials, maximum 96 inference requests; each trial 8 calls,
  180 seconds, 10 native operations, 16 tool attempts and one dispatched write.
- Qwen output: 1024 per response, clamped to the remaining 2048 trial allowance.
- Sol output: observed cumulative 2048 stopping threshold, not a hard generation
  cap; unchanged account settings. Unknown unreturned usage stays unknown.

Authoritative progress: `rosa-evaluation/artifacts/workflow-live-v1-20261022/`
contains backend `checkpoint.json`, individual trial folders and operator logs.
Checkpoint counters update at trial boundaries; an in-progress request can be
absent from the last saved aggregate. Do not infer completion from log tails.

Live protocol: `rosa-evaluation/docs/WORKFLOW_LIVE_V1_PROTOCOL_2026-10-22.md`.
Freeze: `rosa-evaluation/artifacts/workflow-live-v1-20261022/freeze.json`.
Analysis/report are written as each supervisor finishes; inspect their status
before treating them as final. No failed trial is silently rerun or rescored.
