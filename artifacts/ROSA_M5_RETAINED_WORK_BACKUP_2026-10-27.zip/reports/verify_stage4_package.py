"""Operator publication review. Read-only, including nested historical ZIPs."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1] / 'rosa-evaluation'
archive = ROOT / 'artifacts/ROSA_STAGE4_COMPLETE_EVIDENCE_2026-10-21.zip'
wanted = archive.with_suffix('.sha256').read_text().split()[0]
assert hashlib.sha256(archive.read_bytes()).hexdigest() == wanted
patterns = [re.compile(p) for p in (
    rb'eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}',
    rb'sk-[A-Za-z0-9_-]{24,}', rb'gh[pousr]_[A-Za-z0-9_]{30,}',
    rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    rb'Bearer [A-Za-z0-9_.-]{24,}')]
findings, scanned = [], 0


def inspect_archive(data, label, depth=0):
    global scanned
    if depth > 4:
        raise RuntimeError('unexpected_archive_nesting')
    with zipfile.ZipFile(io.BytesIO(data)) as handle:
        assert handle.testzip() is None
        for info in handle.infolist():
            if info.is_dir():
                continue
            scanned += 1
            path = PurePosixPath(info.filename)
            forbidden = (path.is_absolute() or '..' in path.parts
                or any(p in ('.git', '.venv', '.local', '.aws', '.codex') for p in path.parts)
                or (path.name.startswith('.env') and path.name != '.env.example')
                or path.name in ('registration.json', 'config.local.toml')
                or path.suffix in ('.sqlite', '.sqlite3', '.db'))
            if forbidden:
                findings.append({'path': label + '!' + info.filename, 'reason': 'private_or_unsafe_path'})
            member = handle.read(info)
            if path.suffix == '.zip':
                inspect_archive(member, label + '!' + info.filename, depth + 1)
            elif any(pattern.search(member) for pattern in patterns):
                findings.append({'path': label + '!' + info.filename, 'reason': 'opaque_credential_pattern'})


inspect_archive(archive.read_bytes(), archive.name)
with zipfile.ZipFile(archive) as handle:
    name = 'artifacts/stage4-batching-completion-20261021/evidence-manifest.json'
    manifest = json.loads(handle.read(name))
    for relative, expected in manifest.items():
        assert hashlib.sha256(handle.read(relative)).hexdigest() == expected, relative
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative

missing_links = []
for file in (ROOT / 'STAGE4_RESULTS.md', ROOT / 'docs/PROJECT_ROADMAP_SIX_STAGES.md',
             ROOT / 'docs/STAGE4_EVIDENCE_GUIDE.md',
             ROOT / 'artifacts/stage4-batching-completion-20261021/FINAL_REPORT_FOR_CHATGPT.md'):
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', file.read_text(encoding='utf-8-sig')):
        if not target.startswith(('http:', 'https:', '#')) and not (file.parent / target.split('#')[0]).exists():
            missing_links.append({'source': str(file.relative_to(ROOT)), 'target': target})
print(json.dumps({'archive_sha256': wanted, 'manifest_members_verified': len(manifest),
    'zip_members_scanned_including_nested': scanned, 'findings': findings,
    'missing_local_report_links': missing_links}, indent=2))
if findings or missing_links:
    raise SystemExit(1)
