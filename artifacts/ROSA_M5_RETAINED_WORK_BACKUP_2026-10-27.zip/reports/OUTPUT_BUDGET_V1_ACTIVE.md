# Output/interaction diagnostic v1 — active handoff

## FINAL COMPLETE — 40 scored trials, 1 external unscorable interruption

Current supervisor completed; no experiment/consent pending. Model unloaded, sleep
hold released, simulator/runner processes absent in final check. All40 scored
trace-ID sets exactly match Phoenix with closed trees. Original0 metadata audit
exception and external partial15-span trace are preserved. No scored trial erased
or rerun. Original published archive hashes unchanged.

Verified primary outcomes: L2562/8, L5123/8, L10245/8, C2561/8, R2562/8.
Healthy primary outcomes: L10241/2; all other conditions0/2. Total13/40 primary
passes,188 scored-trial model calls;5 scored trials have bounded unknown last
generation usage, plus the separate external unscorable attempt (reserve8calls,
2048tokens). Never present all aggregate usage as exact.

New post-run contract check: L512 entry028 had a truthful UNKNOWN report accepted
before max iterations; R256 entry039 reached goal and had truthful SUCCESS accepted
before final acknowledgement timed out. Primary scores unchanged. Retrospective
goal-plus-accepted-report counts would be L5124/8,R2563/8; others unchanged. Do not
call these corrected primary scores or claim recovery never accepted a healthy
report. The useful next hypothesis is terminal completion after a validated report
without another model acknowledgement, while rejected reports remain recoverable.

Read: `rosa-evaluation/OUTPUT_BUDGET_V1_REVIEW_FOR_CHATGPT.md`.
Sealed main report: `rosa-evaluation/artifacts/output-budget-v1-resume-20261022/REPORT_FOR_CHATGPT.md`.
Sealed raw evidence ZIP: `ROSA_OUTPUT_BUDGET_V1_COMPLETE_EVIDENCE_2026-10-22.zip`,
4782967bytes,395manifest files, SHA256:
ae202ca1f6aa0bf43fdeea189c6f489b0b1cb0b632ce160e905303b3accea19a.
Independent final verifier: `reports/OUTPUT_BUDGET_V1_FINAL_VERIFICATION.json` PASS.
Terminal descriptive check: `reports/OUTPUT_BUDGET_V1_TERMINAL_REPORT_REVIEW.json`.
Shareable review ZIP includes this post-run review, raw evidence ZIP and receipts:
`rosa-evaluation/artifacts/ROSA_OUTPUT_BUDGET_V1_COMPLETE_REVIEW_2026-10-22.zip`.
Review package verification: `reports/OUTPUT_BUDGET_V1_REVIEW_PACKAGE.json`.
All changes/results local; no new commit/push. No new experiments were launched.

Historical running notes below are superseded by this final status.

## Current status: external-interruption recovery RUNNING

The user returned after an external interruption. Supervisor27612 was gone, WSL
was stopped, Ollama unavailable; original checkpoint remained RUNNING,35 scored
results saved, entry035 healthy L512 repetition1 in progress with an empty folder.
Do not modify that checkpoint or invent a score. Shutdown cause/time unknown.

Existing services restarted. All35 saved local span-ID sets still match Phoenix.
15 persisted partial spans were recovered for the unscorable attempt; no complete
root/outcome is invented. Four fresh deterministic controls and8 offline tests
passed after restart; Python package versions unchanged. New freeze69 source files.

Current package: `rosa-evaluation/artifacts/output-budget-v1-resume-20261022`.
Supervisor: `reports/output-budget-v1-resume-run.ps1`.
Process receipt: `reports/OUTPUT_BUDGET_V1_RESUME_PROCESS.json`.
Terminal status: `reports/OUTPUT_BUDGET_V1_RESUME_SUPERVISOR.json`.
Only original entries35..39 run;35 is an explicitly labeled replacement for the
unscorable attempt. No scored trial is rerun. Final record41 attempts,40 scored,
one external interruption unknown. Counts/rates are descriptive complete-case.
Original metadata-accounting exception also remains preserved.

Prior165 known calls +8 reserved for interrupted attempt +40 resume cap=213<=320.
Output upper reserve41689<=81920. Combined conservative active-time upper bound
6061.85833seconds<10800; external downtime excluded. Each trial retains180seconds,
8 calls,2048 output tokens,10 native operations,one write. Resume cap30minutes.

Final report will be in the resume package. Supervisor independently audits all40
scored traces, unloads model/releases temporary power hold, then generates report
and combined ZIP containing all three packages. Analysis log:
`reports/output-budget-v1-resume-analysis.log`.
After completion run `reports/verify_output_budget_v1.py` with existing WSL Python
to independently check source profiles, identical schemas, original hashes and ZIP.

Everything below is historical context for the prior stopped supervisors.

## Current status — separately frozen follow-up is RUNNING

Original first R256 healthy trial reached the independent physical goal but hit
180seconds before report. Score remains FAILED;7 calls,1026 known output tokens,
generation7 usage UNKNOWN (at most256 additional tokens). Original local accounting
audit failed completed_usage_records; actual spans/callbacks were closed. Original
supervisor stopped, model unloaded, sleep hold released. Do not rerun that trial.

The new follow-up runs ONLY original schedule entries1..39, unchanged settings,
order, prompts, controller, recovery and180second/2048token/8call limits. It permits
one explicitly wall-interrupted final generation with unknown usage bounded by its
requested allowance, then serializes a model unload before the next trial. Other
missing usage remains a stop. New2 offline interruption tests and previous6 tests
passed. Freeze57 source files, cap312 remaining requests (original7+312<=320).

Current supervisor: `reports/output-budget-v1-followup-run.ps1`.
PID receipt: `reports/OUTPUT_BUDGET_V1_FOLLOWUP_PROCESS.json`.
Checkpoint: `rosa-evaluation/artifacts/output-budget-v1-followup-20261022/gazebo/ollama/result.json`.
Terminal receipt: `reports/OUTPUT_BUDGET_V1_FOLLOWUP_SUPERVISOR.json`.
Error log: `reports/output-budget-v1-followup-supervisor-errors.log`.
Live log: `rosa-evaluation/artifacts/output-budget-v1-followup-20261022/operator/live.log`.
Final combined report: `rosa-evaluation/artifacts/output-budget-v1-followup-20261022/REPORT_FOR_CHATGPT.md`.
Final package planned: `rosa-evaluation/artifacts/ROSA_OUTPUT_BUDGET_V1_COMPLETE_EVIDENCE_2026-10-22.zip`.
The final analyzer includes original1+remaining39, preserves original audit exception,
independently fetches all40 trace trees from their distinct Phoenix projects, reports
unknown usage honestly and archives both attempts without changing historical scores.

The earlier notes below describe the original stopped attempt, not the current PID.

User authorized testing Qwen output allowances512/1024 (corrected from2024),
response style and safe incomplete-response recovery on2026-10-22.

Frozen source/schedule: `rosa-evaluation/artifacts/output-budget-v1-20261022/freeze.json`.
Protocol: `rosa-evaluation/docs/OUTPUT_BUDGET_V1_PROTOCOL_2026-10-22.md`.
40 trials: L256/L512/L1024/C256/R256 ×4 UR5e cases ×2 repetitions.
All share8 calls,2048 generated tokens,180seconds,10 native operations,one write.
Two allowed recovery requests count against existing budgets; no OAuth involved.
Original96-trial evidence stays unchanged. Source freeze contains46 files.

Before live inference:6 offline completion tests passed, including actual ROSA
post-write truncation without command replay and closed spans;4 fresh deterministic
Gazebo controls passed. No model inference was used to tune the code before freeze.

Detached PowerShell supervisor: `reports/output-budget-v1-run.ps1`.
Process receipt: `reports/OUTPUT_BUDGET_V1_PROCESS.json`.
Live checkpoint: `rosa-evaluation/artifacts/output-budget-v1-20261022/gazebo/ollama/result.json`.
Live log: `rosa-evaluation/artifacts/output-budget-v1-20261022/operator/live.log`.
Supervisor terminal status: `reports/OUTPUT_BUDGET_V1_SUPERVISOR.json`.
Supervisor errors: `reports/output-budget-v1-supervisor-errors.log`.
The supervisor finishes persisted Phoenix auditing, model unload, sleep-hold release,
then independent analysis/report/checksummed ZIP generation automatically.
Analysis output: `reports/output-budget-v1-analysis.log`.
Final report: `rosa-evaluation/artifacts/output-budget-v1-20261022/REPORT_FOR_CHATGPT.md`.

Do not edit frozen files during this run, silently rerun cases, or modify old
packages. Unexpected engineering/trace/accounting failures stop and preserve the
checkpoint. An interrupted response without returned usage has unknown consumption;
stop, don't infer zero or silently continue. A future attempt needs a separate freeze.

The recovery module is opt-in; default ROSA and the model factory are unchanged.
It gates generated messages before the tool parser, holds back all calls in a
length-stopped response and asks for a fresh complete step without rebuilding JSON
or replaying any accepted/uncertain robot command. Existing write/prerequisite and
report-evidence gates remain responsible for robot actions.
