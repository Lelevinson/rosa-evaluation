# Prompt-contract repair checkpoint, 2026-10-26 Asia/Taipei

Current status: COMPLETE_WITH_DOCUMENTED_CONTINUATIONS. Qwen9/9 and Sol9/9
completed scoreable outcomes; all19 attempts audited. R2 completed5/5,19 new
requests,32 combined hosted calls including1 unknown-cost initial request.
All token sessions revoked and simulator shutdowns normal. Gate proof/report
are in the R2 campaign's COMBINED_ANALYSIS.json and COMBINED_VALIDATION_REPORT.md.
The fresh pilot is now separately frozen and launched: read
reports/MACRO_FOCUS_V2_ACTIVE.md. Do not regenerate/modify earlier analysis/data,
which is now hashed by the fresh pilot's freeze. The history below is preserved.
R1 aborted during its first independent home reset, with ZERO model requests.
Its simulator and token session closed normally; source/evidence retained.
Installed initial elbow/wrist2 differ from documented HOME by1.57 radians; the
setup trajectory hit the existing0.2-radian path tolerance. No tolerance change.
Separate experiments.simulator_home_v1 adds only explicit HOME initial positions
to a generated Xacro copy.2 unit methods,3 cold starts,18 deterministic controls
and3 clean shutdowns passed at artifacts/simulator-home-v1-preflight-20261026.
All old files remain unchanged.3 R2 coordinator/scope tests passed before freeze.
R2 campaign: artifacts/prompt-contract-v1-live-resume-r2-20261026. Supervisor:
reports/prompt-live-resume-v2-run.ps1. Same5 remaining cells,max40 new requests,
max53 combined,original72 ceiling. No retry loop. Requires R1 used exactly0
inference calls; R2 could not be used after another service-failed model run.
Current final validation report/analysis will be generated automatically in R2.
Qwen completed9/9 correct outcomes,34 calls,all audits and cleanup verified.
Initial Sol completed4/4 scoreable outcomes, then a generic stream error during
the fifth case;1 censored attempt,4 unstarted cells.13 reserved calls,12 returned
usage records,1 unknown-cost call. No dispatch in the interrupted case. Both
initial simulators closed normally; initial hosted auth was revoked. This is
not established quota exhaustion or a model capability failure.
The held-out pilot has not started. Both repos remain on member/martin; unrelated dirty
work was preserved and nothing was staged/committed by this milestone.

The team-package migration is parked. User resumed the original ordering:
common prompt repair, separate validation, new frozen macro comparison, then
retention based on evidence. Existing provider adapters/settings are unchanged.

Opt-in implementation: rosa-research/src/rosa_reliability/prompt_contract.py.
New tests: rosa-evaluation/tests/test_prompt_contract_v1.py.
Engineering result: rosa-evaluation/artifacts/prompt-contract-v1-engineering-20261026/result.json.
Report: rosa-evaluation/docs/PROMPT_CONTRACT_V1_ENGINEERING_REPORT_2026-10-26.md.
Next-gate draft: rosa-evaluation/docs/PROMPT_REPAIR_AND_MACRO_PILOT_DRAFT_2026-10-26.md.

All48 regression test methods and18 scripted real-ROSA/Phoenix executions passed;
common system prompt identical across conditions; historical frozen sources
verified unchanged. These are scripted development fixtures and do not show
that Qwen's past failures are fixed. Zero live model requests; no OAuth sign-in.
The persistent local Phoenix service was started for actual span audits.

Frozen live protocol: rosa-evaluation/docs/PROMPT_CONTRACT_V1_LIVE_PROTOCOL_2026-10-26.md.
Campaign: rosa-evaluation/artifacts/prompt-contract-v1-live-20261026.
Nine known-case Gazebo cells/backend, at most72 requests/backend; manual hosted
consent completed. Hidden supervisors: operator-ollama and operator-siwc, each
with live.log, supervisor.json and finally power-release.json. Shared Gazebo lock
serializes access. Backend checkpoints are gazebo/<backend>/checkpoint.json.
Fresh six-case deterministic controls precede each backend. Existing model and
Ollama digests verified; actual common system inputs are checked after each trial.
New coordinator preflight:2/2 passed before the source freeze. No automatic
reruns; preserve complete and incomplete outcomes. Normal memory-only hosted
renewal/revocation remains in place. Analysis helper (read-only w.r.t. raw data):
experiments.prompt_live_v1_summary. Do not run a populated backend again.

Single safe continuation frozen: experiments/prompt_live_resume_v1, campaign
artifacts/prompt-contract-v1-live-resume-r1-20261026.5 coordinator safety tests
passed. Only original indices4..8 selected: interrupted read-only cell plus4
unstarted; max40 additional calls,max53 combined,original72 ceiling retained.
R1 had no agent-treatment changes; R2 changes only outside-trial simulator spawn
and records it as a separate prospective setup amendment. No service retry loop.
Source/evidence freeze includes every initial JSON/log/report digest. Do not
regenerate initial analysis or edit initial operator logs now. R1 operator runs
reports/prompt-live-resume-v1-run.ps1 hidden, then analyzes automatically after
normal revocation/cleanup; combined validation report lives in R1, not base.

Next: finish/audit live validation. The progression screen requires all18 known
case contracts to pass, plus audits/limits/cleanup. Task failures do not equal
engineering failure; if the screen fails, review rather than tune/retry until
passing. Only after the gate passes, freeze genuinely fresh cases/repetitions
and caps for the held-out study. Keep live/pilot reports separate for now, then
combine them as the user requested. Teammate dependency migration remains parked.
Do not run old frozen campaigns with new prompts, silently change their scores,
or replace completed outcomes. Keep the five-tool registry scope and arbitrary
caller-prompt limitations explicit; preserve all safety/authorization content.
