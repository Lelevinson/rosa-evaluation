# Stage 4 completed publication handoff

FINAL STATUS (2026-10-22, Asia/Taipei): all 160 planned live trials finished;
the report, roadmap and evidence were committed and pushed to member/martin as
f8482cca72da5d2a12b3c9d6acc8ae36dd8ab876. Remote SHA verified; evaluation tree clean.
Frozen audit passed152/160, with eight explicitly reconciled missing guard-stop
tool spans. Original failed audit/supervisor and all scores are preserved.
See STAGE4_PUBLICATION_RECEIPT_2026-10-22.json and the canonical final report.
No batch is pending and no further publication work remains. The older operator
checkpoints below are historical; do not relaunch or overwrite this campaign.

## User authorization

User approved simplified Stage 4 using batching, then committing files/data/results
to their experiments repository branch, with a detailed report for ChatGPT.
Fresh OAuth consent was completed. No further user input is pending.

## Active execution

Latest extension checkpoint (2026-10-21 ~14:48 UTC): local58/80, 496model calls,
8strict passes,20operational failures. ALL48reliability complete,8strict passes.
The first10parameter trials failed mainly on a report-schema mismatch: models
produce valid read manifests but flat observed_values, while report requires
node-grouped values. ROSA aborts on unhandled Pydantic validation. Preserve these
failures; do not retune or rerun. Cost benefit is unestimable if no paired successes.

Post-freeze additions: offline_review.py and docs/STAGE4_EVIDENCE_GUIDE.md.
System Python --help import passed with no optional dependencies. Run full offline
review only once both80and live audits complete. It replays archived-source hashes,
state checks and exported trace summaries against persisted audits; zero network.
final_report.py now includes family diagnostics, operational error messages,
schema/flat-report counts, per-turn reported token maxima, calibration hash check,
and the write-budget gap. It copies analysis code into analysis-source. Four
analysis unit tests passed during this extension; run final six analysis/hardening
checks after remaining report changes, capture canonical log before packaging.
No frozen execution module was edited.137source hashes matched at interim check.

The historical cost calibration is separately frozen in the policy-tier freeze;
final report validates it. packager now also checks original JTVR ZIP against
known1bd949...sha. Early privacy scans found no opaque credential patterns in
code/docs/artifacts and no credential/private-reasoning fields in hosted records.
Final ZIP/path/credential review still required before explicit staging.

Do not describe all failures as physical failures: hosted6failed reliability
trials classified UNKNOWN accurately, without critical actions, but omitted the
required verifier. Local has both artificial battery-sentinel violations AND
invalid attempts/retries/cap exits. Fixed raw scoring remains primary. Extra
claims/final prose are not exhaustively graded. The matched B comparator shares
the batching helper; there is no untouched primitive-only ROSA comparison.

- Campaign: `rosa-evaluation/artifacts/stage4-batching-completion-20261021/`.
- Supervisor PID 20323; hosted child 20324 finished; local child 22074.
- Windows resource/sleep monitor PID 28496. It stops on campaign `monitor.stop`.
- Hosted completed 80/80, audit 80/80 passed, session REVOKED. Qwen is running.
- Host reliability strict passes: original8/12, clarified12/12,
  bounded_recovery10/12 (zero actual recoveries), enforce_verification12/12.
- Host batching: both16/16 passes, each48CLI/30RPC/67model calls.
  Reference wall318.281807s; candidate352.605294s. Do not call jitter a causal
  slowdown. Same native/model work means no demonstrated selector benefit.
- Qwen first trial reached goal but failed report argument compliance, ~105.85s.
- Live protocol:48reliability+32batching=80/backend; max1056requests/backend,
  240s/trial, six hours/backend. Hosted then local sequentially.
- Exact code/protocol freeze has137 source/input files. Do NOT edit listed files.
  New post-run analysis modules are outside the frozen key set.

## Environment and tooling

WSL Ubuntu-24.04, research Python3.12 at
`/home/martin/.local/share/rosa-envs/research/bin/python`.
Launcher: `scripts/jtvr-wsl.sh -m experiments.stage4_batching...`.
Phoenix read/audit must use separate Python at
`/home/martin/.local/share/rosa-envs/phoenix/bin/python`.
Project: `rosa-stage4-batching-20261021`.
Ollama0.40.6 is ready on172.31.0.1:11434. Qwen profile unchanged8192/256,
temperature0, seed42, mmaptrue, automatic offload. No inference tuning mid-study.

72 tests passed before live; final11-test focused suite included2new cases.
16 real-ROS scripted cases and scripted native-message actual ROSA/Phoenix trace
accepted. Failed preflight attempts and dispositions are preserved. Later4
analysis tests and2 separate hardening tests passed. Do not repeat model trials
to repair packaging or bookkeeping.

## Important scope and implementation notes

Both arms have the SAME helper/read continuations/native tools and strong cost
prompt. Reference honors model preferred direct/bulk/node_bulk. Candidate applies
amortized selection to model-generated validated requirements. Invalid fields are
not silently filled. This isolates automatic selection over a matched helper;
it is NOT an untouched upstream-ROSA comparison. Do not claim the shared helper's
speed benefit over upstream was measured.

Native spans attach to run under installed LangChain instrumentation. Audit counts
explicit stage4.actor provenance; do not assume nested ancestry. All tracing checks
passed on hosted. New audit uses60s no-proxy local HTTP client.

The frozen Gateway read guard counts24 operations but write dispatches lacked an
independent count check. Final report discloses actual maxima/violations. A separate
BoundedGateway fixes this for future use; two tests passed. It is NOT imported by
the frozen study and must not receive credit for live data. Frozen execution is
preserved. Original report/algorithm/scoring files have not been retuned.

Original JTVR policy comparison remains frozen:1152policy episodes+15realROS,
primary J/B96/96ties. Original-JTVR full Runnable is stopped, not renamed batching.
Baseline v1 ZIP SHA721d5960d82f49ea4b0c6f6470ad2c2b02e4e4379720f4b6936a67f13cd3fcad.
Older V2 expanded60movement live fixtures remain unrun under superseded protocol;
the simplified reliability follow-up is six development fixtures, not held-out
generalization. Be explicit about this in conclusions.

## Remaining work after supervisor COMPLETE

1. Inspect local/host outputs and all audits. If bookkeeping fails, preserve
   original audit and use a separately versioned post-hoc correction; don't change
   frozen execution or silently rerun model trials.
2. Run `python -B -m experiments.stage4_batching.final_report` in research env.
   This generates analysis.json, all160trialCSV and FINAL_REPORT_FOR_CHATGPT.md.
   Review all metrics/failures, paired retention criteria and limitations.
3. Update working docs/PROJECT_ROADMAP_SIX_STAGES.md, root workspaceREADME and add
   evaluation STAGE4_RESULTS.md. Do NOT edit frozen evaluationREADME or protocol.
4. Check power-release and cleanup files. Resource monitor exits automatically.
5. Run `python -B -m experiments.stage4_batching.package_results`. It curates v1
   ZIP/report, oldV2preflight+scripted264archive, originalJTVR and current evidence;
   then verifies final ZIP/member hashes. Refuses overwrite.
6. Validate links, privacy/file scope, hashes, git diff check and source freeze.
7. Commit explicit project paths to Lelevinson/rosa-evaluation branchmember/martin;
   include source/data/reports and sibling research snapshot (LICENSE also copied).
   User authorized upload; push member/martin without force. Dry-run succeeded;
   remote branch currently absent. No actual commit or push yet.
8. Final handoff: outcome, remaining real-robot/generalization limits, report+ZIP
   links, actual commit SHA/branch URL. Do not mark completion before audits pass.

Post-run analysis modules added after freeze: final_report.py, package_results.py;
analysis source is separately archived. Analysis metric clarification was recorded
before any TrackB outcome: native work means actualCLI; all-attempt failure
denominators preserved. Retention screen: no strict/combined completion loss,
>=10% paired successful time orCLI reduction, nonnegative in both repetitions.
CLI/RPC and model serving timing are distinct. If no benefit, simplify honestly.

Git attributes preserve artifact/spec bytes. Artifact logs are explicitly unignored;
local runtime logs, .env, .local, databases and environments remain excluded.
Do not stage unrelated local configuration. Git writes/push require tool escalation
under current sandbox; authorization already exists, don't ask redundantly.
