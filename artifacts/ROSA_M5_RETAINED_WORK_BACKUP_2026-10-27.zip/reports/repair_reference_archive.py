"""Add a corrected complete archive without altering the original evidence."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / 'rosa-evaluation/artifacts'
CAMPAIGN = ARTIFACTS / 'workflow-reference-v1-20261022'
ORIGINAL = ARTIFACTS / 'ROSA_WORKFLOW_REFERENCE_V1_EVIDENCE_2026-10-22.zip'
CORRECTED = ARTIFACTS / 'ROSA_WORKFLOW_REFERENCE_V1_EVIDENCE_2026-10-22_COMPLETE.zip'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    original_hash = digest(ORIGINAL.read_bytes())
    freeze = json.loads((CAMPAIGN / 'freeze.json').read_text())['files']
    with ZipFile(ORIGINAL) as old:
        manifest = json.loads(old.read('evidence-manifest.json'))
        assert old.testzip() is None
        assert all(digest(old.read(name)) == value for name, value in manifest.items())
        required = {(CAMPAIGN / 'source' / name).relative_to(ROOT).as_posix(): value
                    for name, value in freeze.items()}
        missing = {name: value for name, value in required.items() if name not in manifest}
        assert missing and all(name.endswith('/uv.lock') for name in missing), missing
        for name, value in required.items():
            assert digest((ROOT / name).read_bytes()) == value, name
        receipt = {'original_archive': ORIGINAL.name, 'original_sha256': original_hash,
                   'original_manifest_entries': len(manifest), 'frozen_sources': len(required),
                   'missing_from_original': missing,
                   'correction': 'Include frozen uv.lock; original experiment and archive unchanged.'}
        payloads = {name: old.read(name) for name in manifest}
    payloads.update({name: (ROOT / name).read_bytes() for name in missing})
    payloads['ARCHIVE_CORRECTION.json'] = (json.dumps(receipt, indent=2) + '\n').encode()
    payloads['ARCHIVE_CORRECTION.md'] = (
        '# Archive completeness correction\n\n'
        'The original ZIP correctly hashes its listed entries but excludes the frozen uv.lock. '
        'The packaging filter excluded all .lock suffixes. This corrected archive adds the exact '
        'frozen file and verifies all frozen sources against both the freeze and ZIP entries. '
        'The original archive, source freeze, scores and results are unchanged.\n').encode()
    manifest = {name: digest(data) for name, data in payloads.items()}
    with ZipFile(CORRECTED, 'x', compression=ZIP_DEFLATED) as archive:
        for name, data in payloads.items():
            archive.writestr(name, data)
        archive.writestr('evidence-manifest.json', json.dumps(manifest, indent=2) + '\n')
    with ZipFile(CORRECTED) as archive:
        assert archive.testzip() is None
        assert all(digest(archive.read(name)) == value for name, value in manifest.items())
        assert all(name in manifest and digest(archive.read(name)) == value
                   for name, value in required.items())
    assert digest(ORIGINAL.read_bytes()) == original_hash
    CORRECTED.with_suffix('.sha256').write_text(digest(CORRECTED.read_bytes()) + '  ' + CORRECTED.name + '\n')
    (ARTIFACTS / 'WORKFLOW_REFERENCE_V1_ARCHIVE_CORRECTION.json').write_text(
        json.dumps({**receipt, 'corrected_sha256': digest(CORRECTED.read_bytes()),
                    'corrected_manifest_entries': len(manifest), 'all_frozen_sources_included': True}, indent=2) + '\n')
    print(json.dumps({'corrected': str(CORRECTED), 'entries': len(manifest),
                      'frozen_sources_included': len(required), 'original_unchanged': True}))


if __name__ == '__main__':
    main()
