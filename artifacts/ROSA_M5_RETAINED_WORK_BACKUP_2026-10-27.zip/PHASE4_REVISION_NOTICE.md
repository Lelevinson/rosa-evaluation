# Phase 4 revision notice — original JTVR specification received

The historical [PHASE4_V2_PLAN.md](PHASE4_V2_PLAN.md), its source freeze and
scripted results are preserved. Its policy named `jtvr` is a fixed dependency
bundle, not the original algorithm. Do not infer the original proposal's success
or failure from it.

The pending hosted batch stopped before consent with zero model requests/trials.
Its local successor did not start. Reliability checks, retrospective analysis
and inference diagnostics remain valid within their stated scope.

Read the [specification review and minimum experiment proposal](rosa-evaluation/docs/JTVR_SPEC_REVIEW_AND_MINIMAL_EXPERIMENT.md)
and [six-stage roadmap](rosa-evaluation/docs/PROJECT_ROADMAP_SIX_STAGES.md).

No original-JTVR implementation or results commit is claimed complete. The user's
request to commit Stage 4 artifacts to `rosa-evaluation` on `member/martin` remains
conditional on completing the agreed revised experiment and its audits.
