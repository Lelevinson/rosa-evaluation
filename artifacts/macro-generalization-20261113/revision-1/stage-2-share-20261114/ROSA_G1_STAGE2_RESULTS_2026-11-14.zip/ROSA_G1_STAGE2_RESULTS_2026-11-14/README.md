# ROSA G1 Stage 2 results package

Date: 2026-11-14. Hosted Sol development validation only.

Start with [the combined results and problems report](revision-1/STAGE2_RESULTS_AND_PROBLEMS_2026-11-14.md).
The [combined execution report](revision-1/stage-2-continuation-1/COMBINED_STAGE2_REPORT.md) includes all 36 trial rows.
The [detailed checks](revision-1/stage-2-continuation-1/DETAILED_STAGE2_CHECKS.md) cover fault exercise, native ratios and both cost views.

There are 36 retained trial records: 35 correct completions and one original provider interruption.
All ten continuation trials completed correctly. The interrupted trial was not rerun or replaced.
All 36 local and persisted audits passed, matching 1,472 spans; total inference attempts were 94/291.
This is AI-authored exploratory dev, without independent case authorship or semantic human review.
P1-P4 are not adjudicated. This package establishes no Qwen, held-out or stock-ROSA comparison.

## Included

- Both Stage 2 segments: results, transcripts in result records, JSON traces, per-trial Phoenix audit records/logs,
  aggregate analyses, interruption records, frozen execution/scoring helpers, plans, settings and integrity receipts.
- The combined report and selected shared protocol/catalogue/world definitions.
- A package-specific SHA-256 manifest, omission list and packaging script.

## Deliberate omissions and interpretation

The six local Phoenix database/sidecar files are preserved locally and omitted here. Review uses the retained
per-trial trace JSON and persisted audit records. No credential store, OAuth token cache, .env file, Git history,
held-out case collection or full earlier-stage archive is included. Authorization-status JSON contains sanitized
scope/cleanup metadata, not token credentials. Files retain original machine paths and historical status wording.

Original manifests are historical inventories of their complete local segments; they list the omitted database
files as well. Use PACKAGE_MANIFEST.json to verify this ZIP's contents. Selected protocol references do not make
this a turnkey reinstall or a complete source/dependency backup. Stages 0 and 1 are not combined into this report.

All retained source bytes are copied unchanged. The only new material is this package's README, manifest and builder.
No experiment, inference request, Git commit, upload or publication was performed to create this package.
