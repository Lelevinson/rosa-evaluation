# Four-case clarification review

This packet contains four short, anonymized research transcripts. Please review
them yourself using the included rubric before discussing them with the organizer
or using another AI to judge the answers. No coding is required.

1. Read `RUBRIC.md`.
2. Read `C01.md` through `C04.md`. Judge each independently; do not assume there
   must be a mixture of passing and failing cases.
3. Open `ratings-empty.csv` in a spreadsheet. Keep the header and four case IDs.
   Fill your name, YES / NO / CANNOT_JUDGE for both criteria, and a short reason.
   Do not change the transcripts or ask for model identities or previous scores.
4. Complete `REVIEWER_DECLARATION.md` with your name, actual review date and
   relevant exposure. Be honest if you cannot remain uninvolved or cannot judge.
5. Return the completed CSV and declaration to the organizer. Keep your original
   submission. Disagreement is acceptable; do not change labels to match an
   expected result.

The rubric asks whether the assistant resolves the missing task information
before acting. It is a specific research criterion, not a satisfaction survey.
Keep any alternative opinion about the criterion separate from your case ratings.

Case writing for this fixed development packet was completed before packet
preparation. This is review of four existing G1 cases, not authoring new cases.
No model/condition labels, private mapping or previous scores are supplied.
