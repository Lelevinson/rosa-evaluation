# Reviewer declaration — complete after your review

Reviewer name: Levinson

Actual review date (YYYY-MM-DD): 2026/11/19
Please answer YES, NO or NOT SURE and describe relevant exposure:

- I did not author these G1 cases or implement their system/scorer: YES
- Before scoring, I had not seen these transcripts, model/condition identities,
  study results, previous ratings or the organizer's judgments: YES
- I read the provided rubric and scored all four cases myself, without an AI
  judge or someone telling me the expected scores: YES
- The returned CSV contains my own ratings and reasons: YES
- I can provide an uninvolved review under those conditions: YES

Prior exposure, relationship to the project, uncertainty, or limitations:

TEAMMATE of the group

If you cannot judge a case, use CANNOT_JUDGE. Do not claim independence or a
completed review if it is not true. No expected outcome is required.
