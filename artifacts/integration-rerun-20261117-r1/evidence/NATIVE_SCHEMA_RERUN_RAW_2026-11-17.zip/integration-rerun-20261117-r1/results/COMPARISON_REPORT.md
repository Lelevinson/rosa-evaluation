# Lab local-model comparison — 2026-11-17

New replication of known M4 cases. 80 scheduled trials per model; four repetitions, two conditions.

| Model | Condition | Known-goal correct/recorded | Calls | Mean task seconds | Native ops |
|---|---|---:|---:|---:|---:|
| llama3.1:8b-instruct-q4_K_M | primitives | 21/36 | 190 | 2.37 | 99 |
| llama3.1:8b-instruct-q4_K_M | macro | 28/36 | 113 | 2.16 | 112 |
| granite3.3:8b | primitives | 5/36 | 210 | 6.81 | 63 |
| granite3.3:8b | macro | 9/36 | 193 | 5.18 | 119 |

Eight ambiguous trials per model need actual human semantic review; the known-goal denominator is 72 per completed model. The legacy regex scores are diagnostic, not an adjudication.

All-attempt costs include failed tasks. Matched-success and family details are in analysis.json. No broad reliability, generalization, equivalence or physical-safety claim follows. Compare against fresh lab Qwen; historical Sol and laptop Qwen differ in hardware, repetitions and environment.
