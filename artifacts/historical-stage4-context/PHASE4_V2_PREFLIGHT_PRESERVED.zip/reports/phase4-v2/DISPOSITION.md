# Disposition: superseded experiment proposal, preserved preflight

On 2026-10-21 the user supplied the original JTVR specification and requested
comparison/proposal before further JTVR implementation.

The fixed dependency bundle does not implement that specification. Hosted batch
`00879ccd-8e51-4b84-9ce5-50163da5bc55` was interrupted while awaiting consent:
zero model requests/trials, cleanup NO_TOKEN_SESSION. The supervisor records the
interruption as a failed child step. This was an operator-directed scope change,
not a measured model failure. The local successor did not start. The monitor and
temporary sleep hold released normally.

Keep the final 264 audited scripted trials, 41 passing tests, retrospective v1
checks, nine local diagnostic requests and earlier preflight candidates. Frozen
model/world/scorer/policy code is unchanged by this review. No prospective v2
reliability/JTVR live results are claimed. Phase 4 is incomplete.

The prior browser prompt is retired. The proposal/roadmap are under evaluation
`docs/`. Do not overwrite this experiment to imply original-spec implementation.
