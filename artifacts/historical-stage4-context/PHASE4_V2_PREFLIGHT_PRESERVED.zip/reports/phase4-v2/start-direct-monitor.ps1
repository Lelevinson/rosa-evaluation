$ErrorActionPreference = 'Stop'
@{pid=$PID; started_utc=[DateTime]::UtcNow.ToString('o'); launcher='direct hidden tool process'} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'monitor-process.json') -Encoding UTF8
$workspace = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
& (Join-Path $workspace 'rosa-evaluation/scripts/phase4-monitor.ps1')
