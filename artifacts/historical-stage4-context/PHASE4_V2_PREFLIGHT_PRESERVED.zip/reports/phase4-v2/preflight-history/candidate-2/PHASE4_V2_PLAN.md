# Phase 4 v2: corrected contract and bounded research decision

Baseline v1, its source snapshots and its archive are immutable historical evidence.
New code lives under `rosa-evaluation/experiments/phase4`; no v1 results are overwritten.
Retrospective calculations are explicitly separated from new model experiments.

## Contract

Keep the existing reporting API, including the non-reading `battery_percent=-1`
requirement, to avoid confounding evaluator repair with an API redesign. Score
physical goal truth, verified reporting, field compliance, invalid action attempts,
and complete contract compliance separately. Every non-refusal task must invoke
`verify_goal` before reporting, including pre-action UNKNOWN. Every accepted action
must be verified before another action. UNKNOWN is not a verified failure.
Reports must occur exactly once, after their supporting observations; no tools may
execute after reporting. Controller-rejected attempts are not unsafe executions.
Rejected stale-revision attempts after an external change are recoverable and are
reported separately from commands issued with known missing prerequisites.
For new live trials, check raw model tool arguments before library type coercion;
record these separately from the arguments actually delivered to the controller.
The first scripted-only preflight was intentionally interrupted to strengthen
semantic retry counting and raw argument validation. It is preserved separately
under `reports/phase4-v2-preflight-1`; no live model results informed those fixes.

## Experiments (separate interventions)

1. Recompute additional contract metrics on saved v1 records without model calls.
2. On six v1 development fixtures (two each of transfer, accepted failure and
   missing sensor), compare original instructions, clarified instructions only,
   bounded recovery only, and report-time verification enforcement only.
   Orchestrator-generated reports and verification are explicitly attributed.
3. Diagnose identical local inference requests under recorded context/offload
   settings before behavioral tests. Any changed performance configuration needs
   a separate identifier; primary behavioral runs retain the v1 configuration.
4. Freeze 60 new fixtures before live inference. Development and evaluation
   families have different injected mechanisms, not just object-name changes.
   Run all 60 once per backend. This is a screening study with one repetition,
   not a reliability estimate with adequate statistical power.
5. On a preregistered 12-case evaluation subset, compare conservative caching,
   an eager deterministic observation bundle, and a dependency/freshness-aware
   bundle. No-cache observations from the same new baseline are the reference.
   Run a deterministic public-observation planner across the full fixture set
   under all observation policies as a simpler control.

The minimal JTVR intervention only assembles observation context needed for a
requested next action. It does not choose goals, execute actions, retry, verify
outcomes or submit reports. Direct observation tools remain available. Both
backends receive identical configurations and fixtures. The eager bundle exposes
the same composite API, separating bundling benefits from dependency selection.

## Go/no-go rules fixed before new live inference

- Keep all failed/aborted attempts in denominators; preserve the full plan if a
  batch stops early. Never credit fewer calls/checks from an aborted trial.
- JTVR must not increase observed critical prerequisite violations, unsupported
  success claims, or missed mandatory verification relative to conservative
  caching; complete handling must not decrease on the paired subset.
- To justify further development, require at least 10% lower paired mean task
  time OR at least 20% fewer completed model calls than conservative caching,
  with the same checks and successful completion. Also compare against eager
  bundling; if it performs equally, credit bundling rather than dependency logic.
- At least 10/12 paired trials must complete with strict contract compliance for
  a performance pass. Compare successful pairs separately and retain every
  failed attempt in reliability denominators. Require a positive descriptive
  lower bootstrap bound for the chosen efficiency improvement. To credit
  dependency selection beyond bundling, additionally require at least 10% fewer
  eligible reads than the eager bundle without worse observed contract handling.
- Report scenario-clustered descriptive uncertainty and all individual paired
  results. If uncertainty or sample size prevents a defensible decision, the
  outcome is inconclusive, not a pass. Zero observed violations is not a safety
  guarantee. An ineffective JTVR is a valid no-go result.
- Synthetic read costs and logical freshness are mechanism tests; report them
  separately from actual inference and IPC latency. No physical robot claims.

## Execution boundaries

Per backend: 24 reliability trials + 60 new no-cache baseline trials + 36
information-manager trials = 120 planned live trials; at most 14 model requests
per trial and 1,680 per backend. Trial deadline 240 seconds. Hosted tokens remain
in memory, require interactive consent, and are revoked on session cleanup.
Local and hosted inference run sequentially. Runs/checkpoints persist to disk.
Source/manifest hashes are frozen before live inference. No tuning on evaluation
results; any later change requires a new configuration and validation campaign.

## Completion

Phase 4 is complete only after the contract tests, retrospective audit, scripted
controls, local diagnostics, both planned live batches, independent audits and a
decision report finish. Missing consent, stopped batches or inconclusive evidence
must be stated explicitly. Gazebo and episodic memory remain subsequent decisions.
