# Preflight completed; prospective model results pending

This is a historical progress record, not the final Phase 4 decision. The pending
live run was subsequently closed before consent upon receipt of the original
JTVR specification. See DISPOSITION.md; do not restart the old prompt or interpret
the fixed dependency bundle as the original algorithm.

- 41 evaluation tests passed (including actual ROSA callback/recovery tests).
- 264 final scripted trials completed and independently audited: all passed.
- Final source/manifest freeze is in freeze.json; subsequent integrity check found
  no source changes. Earlier scripted-only candidates remain in preflight-history
  and are excluded from final experiment denominators.
- Retrospective v1 additional strict checks: local 12/36, hosted 30/36. Original
  v1 scores and archive remain unchanged. Raw model argument types were not
  reconstructed in that retrospective calculation; new live trials record them.

New-world deterministic controls (60 fixtures per policy):

| Policy | Strict handling | Eligible reads | Controller/verification reads | Cache hits | Stale observations |
| --- | ---: | ---: | ---: | ---: | ---: |
| None | 60/60 | 320 | 220 | 0 | 0 |
| Conservative cache | 60/60 | 300 | 220 | 20 | 0 |
| Eager bundle | 60/60 | 405 | 211 | 0 | 0 |
| Dependency/freshness bundle (minimal JTVR) | 60/60 | 304 | 214 | 20 | 0 |

Different controller-read totals include avoided rejected action attempts. All
accepted-action and reporting obligations were audited. They are not evidence
that required checks were skipped. The dependency bundle reduces eager overread,
but does not reduce backend reads relative to conservative caching in this
scripted workload. Model-turn and end-to-end benefit still require live tests.

Local diagnostic: all nine fixed native requests returned observe_robot as
requested. Original 8192-context automatic-offload profile generated roughly
9–11 tokens/s; 4096 context roughly 9–10; forced 24-layer offload roughly 14–15.
These are short-request generation measurements with host workloads uncontrolled,
not full task throughput or guaranteed sustained performance. The prospective
behavioral run retains the original profile. Model was unloaded afterward.

The 120-trial hosted batch requires fresh consent. It has a hard ceiling of
1,680 model requests and revokes its in-memory session afterward. A separate
120-trial local batch, audits and final report follow sequentially. Until all
planned data and audits complete, Phase 4 is not complete.
