"""Sanitized runtime inventory; never collect the process environment or credentials."""
from datetime import datetime, timezone
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

import rclpy
from dotenv import dotenv_values
from urllib.request import ProxyHandler, Request, build_opener

workspace = Path('/mnt/c/Proj/robotics/introtorobotics')
folder = Path(__file__).parent
endpoint = dotenv_values(workspace / 'rosa-evaluation/.env')['OLLAMA_BASE_URL']
opener = build_opener(ProxyHandler({}))
def get(path):
    with opener.open(Request(endpoint + path), timeout=10) as response:
        return json.load(response)

snapshot = {'observed_utc': datetime.now(timezone.utc).isoformat(), 'python': sys.version,
    'executable': sys.executable, 'platform': platform.platform(), 'os_release': Path('/etc/os-release').read_text(),
    'ros_distro': os.environ.get('ROS_DISTRO'), 'ros_version': os.environ.get('ROS_VERSION'),
    'rclpy_module': rclpy.__file__, 'uv_version': subprocess.check_output(['uv', '--version'], text=True).strip(),
    'research_packages': sorted([{'name': dist.metadata['Name'], 'version': dist.version}
                                for dist in metadata.distributions()], key=lambda item: item['name'].lower()),
    'ollama_version': get('/api/version'), 'ollama_models': get('/api/tags'), 'loaded_models_before_live': get('/api/ps')}
(folder / 'environment.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print('Sanitized environment inventory saved; rclpy import PASS.')
