"""Detached final-stage runner: retain evidence and clean up even if the UI closes."""
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys
import traceback
from urllib.request import ProxyHandler, Request, build_opener

FOLDER = Path(__file__).parent
ROOT = FOLDER.parent.parent
EVAL = ROOT / 'rosa-evaluation'
PYTHON = '/home/martin/.local/share/rosa-envs/research/bin/python'
state = {'started_utc': datetime.now(timezone.utc).isoformat(), 'status': 'RUNNING'}


def status(phase):
    state['phase'] = phase
    (FOLDER / 'supervisor-status.json').write_text(json.dumps(state, indent=2) + '\n')


def phase(name):
    status(name)
    subprocess.run([PYTHON, '-B', '-m', 'experiments.clean_campaign', name], cwd=EVAL, check=True)


def unload():
    from dotenv import dotenv_values
    endpoint = dotenv_values(EVAL / '.env')['OLLAMA_BASE_URL']
    request = Request(endpoint + '/api/generate', data=b'{"model":"qwen3.5:9b","keep_alive":0}',
                      headers={'Content-Type': 'application/json'})
    with build_opener(ProxyHandler({})).open(request, timeout=30) as response:
        result = json.load(response)
    (FOLDER / 'local-model-cleanup.json').write_text(json.dumps({'observed_utc': datetime.now(timezone.utc).isoformat(),
        'done': result.get('done'), 'reason': result.get('done_reason')}, indent=2) + '\n')


def stop_helpers():
    (FOLDER / 'monitor.stop').write_text('Testing finished; release background sampling/power request.\n')
    subprocess.run(['/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', '-NoProfile',
        '-ExecutionPolicy', 'Bypass', '-File', 'C:/Proj/robotics/introtorobotics/reports/clean-stage1-4-20261021-r1/stop-helpers.ps1'], check=True)


try:
    campaign = json.loads((FOLDER / 'campaign.json').read_text())
    assert campaign['steps']['audit-hosted']['status'] == 'COMMAND_PASSED'
    phase('local')
    status('unload-model')
    unload()
    phase('audit-local')
    status('cleanup-helpers')
    stop_helpers()
    shutil.copy2(EVAL / '.local/ollama/stderr.log', FOLDER / 'ollama-current-stderr.log')
    status('tests-and-audits-complete')
    shutil.copy2(FOLDER / 'supervisor.log', FOLDER / 'supervisor-checkpoint.log')
    (FOLDER / 'supervisor-checkpoint.json').write_text(json.dumps(state, indent=2) + '\n')
    status('build-report')
    subprocess.run([PYTHON, '-B', str(FOLDER / 'compile_report.py')], cwd=EVAL, check=True)
    state['status'] = 'COMPLETE'
    state['ended_utc'] = datetime.now(timezone.utc).isoformat()
    status('complete')
except BaseException as error:
    state['status'] = 'FAILED'
    state['error_type'] = type(error).__name__
    state['ended_utc'] = datetime.now(timezone.utc).isoformat()
    status('failed')
    traceback.print_exc()
    try:
        unload()
    except Exception:
        pass
    try:
        stop_helpers()
    except Exception:
        pass
    raise
