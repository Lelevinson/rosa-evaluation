from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import sys

root = Path('/mnt/c/Proj/robotics/introtorobotics')
sys.path.insert(0, str(root / 'rosa-evaluation'))
from experiments.clean_campaign import sources

folder = Path(__file__).parent
data = json.loads((folder / 'campaign.json').read_text())
data['before_live_utc'] = datetime.now(timezone.utc).isoformat()
data['source_sha256_before_live'] = sources()
data['preflight_correction'] = 'Initial full discovery lacked ROS sourcing; corrected invocation sources Jazzy. Original 80-error log retained. No model/world/scorer/cache behavior was changed.'
for relative in data['source_sha256_before_live']:
    target = folder / 'source-before-live' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / relative, target)
(folder / 'campaign.json').write_text(json.dumps(data, indent=2) + '\n')
print('Source and protocol checkpoint saved before live inference.')
