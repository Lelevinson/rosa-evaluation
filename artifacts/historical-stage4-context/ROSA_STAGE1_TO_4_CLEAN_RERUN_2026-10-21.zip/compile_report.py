"""Build a detailed review report and an allowlisted, hashed evidence archive."""
from collections import Counter
from datetime import datetime, timezone
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import statistics
import sys
import zipfile

FOLDER = Path(__file__).parent
WORKSPACE = FOLDER.parent.parent
EVAL = WORKSPACE / 'rosa-evaluation'
sys.path.insert(0, str(EVAL))
from experiments.clean_campaign import sources
from experiments.gate4_report import describe, failure_category


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def block(value):
    return '```json\n' + json.dumps(value, indent=2, ensure_ascii=False) + '\n```\n'


def table(headers, rows):
    def safe(value):
        return str(value).replace('|', '\\|').replace('\n', '<br>')
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |']
                     + ['| ' + ' | '.join(map(safe, row)) + ' |' for row in rows]) + '\n'


def main():
    campaign = read(FOLDER / 'campaign.json')
    batches = {name: read(EVAL / 'results/runs' / campaign['steps'][name]['run_id'] / 'result.json')
               for name in ('scripted', 'hosted', 'local')}
    if any(b['status'] != 'COMPLETE' for b in batches.values()):
        raise RuntimeError('Refusing a final report while a planned batch is incomplete')
    audits = {name: read(EVAL / 'results/runs' / batch['batch_id'] / 'phoenix' /
                        ('oracle-audit.json' if name == 'scripted' else 'audit.json'))
              for name, batch in batches.items()}
    if not all(a['all_verified'] and a['trials_audited'] == len(batches[name]['trials']) for name, a in audits.items()):
        raise RuntimeError('Resolve missing or mismatched audit evidence before finalizing')
    described = {name: describe(batch) for name, batch in batches.items()}
    decisions = {
        'local_baseline_usefulness_target_met': described['local']['correct_handling_fraction'] >= .8,
        'hosted_baseline_usefulness_target_met': described['hosted']['correct_handling_fraction'] >= .8,
        'required_verification_omissions': {name: described[name]['missing_required_verification'] for name in ('local', 'hosted')},
        'conservative_cache_read_savings': {name: batch['summary']['_paired_cache_comparisons']['conservative']['eligible_reads_saved'] for name, batch in batches.items()},
        'conservative_cache_model_calls_saved': {name: batch['summary']['_paired_cache_comparisons']['conservative']['model_calls_saved'] for name, batch in batches.items()},
        'recommendation': 'Preserve this baseline. Fix repeated terminal-handling/check failures and validate on new frozen cases before JTVR or memory. A read-saving mechanism alone does not establish an agent speedup or research novelty.'}
    current = sources()
    # Recover the checkpoint manifest from its preserved copies: a later recorder
    # write retained step results but dropped the checkpoint's additional keys.
    checkpoint = FOLDER / 'source-before-live'
    frozen = {str(p.relative_to(checkpoint)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in checkpoint.rglob('*') if p.is_file()}
    if not frozen:
        raise RuntimeError('The preserved before-live source snapshot is missing')
    campaign['source_sha256_before_live'] = frozen
    campaign['checkpoint_manifest_recovery'] = 'Hashes reconstructed from preserved source-before-live copies; no current source substituted and no historical timestamp reconstructed.'
    changed = [name for name in sorted(set(current) | set(frozen))
               if current.get(name) != frozen.get(name)]
    campaign.update(ended_utc=datetime.now(timezone.utc).isoformat(), status='COMPLETE',
                    source_changes_after_before_live_checkpoint=changed)
    (FOLDER / 'campaign.json').write_text(json.dumps(campaign, indent=2) + '\n')
    (FOLDER / 'comparison.json').write_text(json.dumps(described, indent=2) + '\n')
    evidence = FOLDER / 'evidence'
    evidence.mkdir(exist_ok=True)
    run_ids = {batch['batch_id'] for batch in batches.values()}
    run_ids.update(row['run_id'] for batch in batches.values() for row in batch['trials'])
    run_ids.update(campaign['steps'][step]['run_id'] for step in ('native', 'shared-local'))
    for identifier in sorted(run_ids):
        source = EVAL / 'results/runs' / identifier
        for name in ('result.json', 'metadata.json', 'oracle.json', 'protocol.json', 'scenario-manifest.json',
                     'requests.json', 'phoenix/trace.json', 'phoenix/audit.json', 'phoenix/oracle-audit.json'):
            path = source / name
            if path.is_file():
                target = evidence / 'runs' / identifier / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)
    validation = campaign['steps']['phoenix-validation']['validation_project']
    shutil.copytree(EVAL / 'results/validations' / validation, evidence / 'validations' / validation, dirs_exist_ok=True)
    with (FOLDER / 'all-trials.csv').open('w', newline='') as stream:
        columns = ['backend', 'run_id', 'scenario_id', 'family', 'split', 'repetition', 'policy', 'api_failed',
                   'failure_category', 'oracle_goal_achieved', 'verified_task_success', 'correct_terminal_handling',
                   'independent_outcome', 'reported_outcome', 'mandatory_verification_covered',
                   'false_success_claim', 'unsupported_success_claim', 'prohibited_action_attempts', 'unsafe_executions',
                   'sensor_backend_reads', 'mandatory_sensor_reads', 'cache_hits', 'stale_observations_served',
                   'model_calls', 'input_tokens', 'output_tokens', 'wall_seconds']
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        for name, batch in batches.items():
            for row in batch['trials']:
                merged = {**row, **row['score'], **row['model_metrics'], 'backend': name,
                          'model_calls': row['model_metrics']['calls'], 'failure_category': failure_category(row)}
                writer.writerow({key: merged.get(key) for key in columns})
    samples = list(csv.DictReader((FOLDER / 'resource-samples.csv').open(encoding='utf-8-sig')))
    resources = {}
    for name in ('native', 'shared-local', 'hosted', 'local'):
        step = campaign['steps'][name]
        start, end = datetime.fromisoformat(step['started_utc']), datetime.fromisoformat(step['ended_utc'])
        selected = [r for r in samples if start <= datetime.fromisoformat(r['observed_utc']) <= end]
        def numbers(key):
            return [float(r[key]) for r in selected if r[key] and re.fullmatch(r'[0-9.]+', r[key])]
        resources[name] = {'samples': len(selected), 'sampled_peak_gpu_memory_mib': max(numbers('gpu_memory_used_mib'), default=None),
            'sampled_min_free_ram_mib': min(numbers('free_ram_mib'), default=None),
            'sampled_min_free_commit_mib': min(numbers('free_commit_mib'), default=None),
            'mean_sampled_gpu_utilization_percent': statistics.mean(numbers('gpu_utilization_percent')) if numbers('gpu_utilization_percent') else None}
    gaps = [(datetime.fromisoformat(b['observed_utc']) - datetime.fromisoformat(a['observed_utc'])).total_seconds()
            for a, b in zip(samples, samples[1:])]
    resources['sampling'] = {'gpu_target_interval_seconds': 10, 'memory_target_interval_seconds': 30,
        'maximum_observed_gap_seconds': max(gaps, default=None), 'gaps_over_30_seconds': sum(gap > 30 for gap in gaps),
        'interpretation': 'Sampled extrema only, not instantaneous process peaks; includes other host activity.'}
    (FOLDER / 'resource-summary.json').write_text(json.dumps(resources, indent=2) + '\n')
    native = read(EVAL / 'results/runs' / campaign['steps']['native']['run_id'] / 'result.json')
    shared = read(EVAL / 'results/runs' / campaign['steps']['shared-local']['run_id'] / 'result.json')
    from experiments.stateful.tools import INSTRUCTIONS, make_tools
    from langchain_core.utils.function_calling import convert_to_openai_tool
    schemas = [convert_to_openai_tool(t) for t in make_tools(lambda *args, **kwargs: None)]
    (FOLDER / 'tool-schemas.json').write_text(json.dumps(schemas, indent=2) + '\n')
    family_pairs = []
    for name in ('local', 'hosted'):
        rows = batches[name]['trials']
        base = {(r['scenario_id'], r['repetition']): r for r in rows if r['policy'] == 'none'}
        for policy in ('ttl', 'conservative'):
            for family in ('repeat_read', 'transfer'):
                pairs = [(base[(r['scenario_id'], r['repetition'])], r) for r in rows
                         if r['policy'] == policy and r['family'] == family]
                family_pairs.append([name, policy, family, len(pairs),
                    sum(a['score']['sensor_backend_reads'] for a, b in pairs),
                    sum(b['score']['sensor_backend_reads'] for a, b in pairs),
                    sum(a['model_metrics']['calls'] - b['model_metrics']['calls'] for a, b in pairs)])
    lines = ['# ROSA Stage 1-4 clean rerun: examination report', '',
        'Date: 2026-10-21 (Asia/Taipei). This report describes a new campaign, not a relabeling or pooling of the earlier overnight runs.', '',
        '## 1. Executive result', '',
        f"Campaign `{campaign['campaign']}` completed {len(batches['hosted']['trials']) + len(batches['local']['trials'])} live trials and {len(batches['scripted']['trials'])} scripted control trials. All recorded live traces and scripted execution records passed the independent evidence audits. A completed batch can contain failed tasks.", '',
        table(['Backend', 'Full baseline terminal handling', 'Oracle achievable goal states', 'Verified goal/report plus operational completion', '80% point target'],
            [[name, f"{described[name]['correct_handling']}/{described[name]['baseline_attempts']} ({described[name]['correct_handling_fraction']:.1%})",
              f"{described[name]['oracle_goal_states_on_achievable']}/{described[name]['achievable_attempts']}",
              f"{described[name]['verified_goal_successes_on_achievable']}/{described[name]['achievable_attempts']}",
              'MET' if described[name]['correct_handling_fraction'] >= .8 else 'FAILED'] for name in ('local', 'hosted')]),
        'These are small engineering-pilot point estimates, not statistical reliability guarantees or an intrinsic model-superiority claim. Cache benefits, task outcome and operational completion are reported separately below.', '',
        'Qwen failed all six accepted-action-failure cases by exhausting its iteration budget, and all six missing-sensor cases by confusing unknown with failure. The hosted backend failed all six missing-sensor cases by omitting required verification. Both completed all 18 achievable baseline goals with verification and reporting. These recurring failures survived the clean restart.', '',
        'The local conservative-cache arm also had one 240-second timeout before any action, leaving 11/12 cached trials handled correctly. Its apparent five model calls saved and four fewer mandatory reads reflect that aborted task; they are not a cache efficiency or check-preservation benefit. The hosted cached arms and local TTL arm handled 12/12 each. Conservative scripted controls saved 25% of eligible reads with no stale observations; this establishes a narrow mechanism result, not a full live robustness or speedup claim.', '',
        block(decisions),
        '## 2. What Stage 1-4 means', '',
        'The authoritative opening gate table in the updated master plan is used: Stage/Gate 1 is native Qwen tool calling; 2 is the isolated stateful mock pilot and independent evaluator; 3 is compatibility with the real modified ROSA interface; 4 is simple caching and invalidation. OAuth is the parallel comparator track (Gate 7 in that table), exercised through the same Stage 2-4 interface here. The older OAuth-specific Gate 4 numbering is not used as the stopping definition.', '',
        'JTVR, tool-menu pruning, dependency routing, episodic memory, Gazebo task trials and physical actuation were not implemented or tested in this campaign. Modified ROSA is explicitly distinguished from an unchanged upstream checkout.', '',
        '## 3. Clean execution, provenance and timeline', '',
        'Only project-owned Ollama and Phoenix processes were stopped and restarted. Stored databases, previous results, model weights and existing uv environments were retained. This is a process/session/world reset, not a Windows reboot or new dependency installation. Every benchmark trial constructs a fresh world process, cache and ROSA agent. No accumulated agent conversation or observation state crosses trials. Provider-managed prompt/KV caching and operating-system file caching are not reset per trial.', '',
        'Live local and hosted batches ran sequentially. Readiness uses 4,096 context; the stateful Qwen benchmark uses 8,192, matching the prior protocol. Both live batches now use the same 2,048 trace-attribute cap. The prior hosted batch used the older cap, so cross-campaign tracing conditions differ. No prompts, world rules, scorer or cache policy were tuned to make a failure pass.', '',
        'A temporary thread-scoped Windows ES_SYSTEM_REQUIRED request prevented automatic idle sleep during the live campaign. It did not require the display or alter the saved power plan, and was released after testing. This cannot prevent manual sleep, reboots, network loss or an application interruption. See power-hold.json and the sampling gaps for the observed execution record.', '',
        'The first shell/nohup detached launcher exited before recording any local model step or trial. Its PID was confirmed absent, and no local trial was duplicated. The replacement launcher uses Popen(start_new_session=True), matching the persistent Phoenix process pattern, and its separate Linux session was verified alive. launch-attempts.json retains both attempts. The detached supervisor then runs the local batch, unloads the model, audits its traces, stops sampling/the temporary power request and builds this report. This execution-control correction did not change model prompts, fixtures, scoring or cache behavior.', '',
        'The first report-build attempt stopped on a missing checkpoint-manifest key after all tests, audits and cleanup had finished. A later campaign-recorder write had retained step records but dropped the added checkpoint metadata. The before-live source copies remained intact, so their hashes were reconstructed directly from those copies and compared with current sources; no current-source substitution or historical timestamp reconstruction was used. The failed supervisor status and traceback are retained as packaging evidence. Only report assembly was retried; model trials were not repeated.', '',
        f"UTC start: `{campaign['started_utc']}`; UTC end: `{campaign['ended_utc']}`. Convert to Asia/Taipei by adding eight hours. Exact per-command times, commands, PIDs and return codes are in [campaign.json](campaign.json).", '',
        table(['Step', 'UTC start', 'Seconds', 'Command status', 'Run or validation ID'],
            [[name, r['started_utc'], round(r.get('wall_seconds', 0), 3), r['status'], r.get('run_id', r.get('validation_project', ''))]
             for name, r in campaign['steps'].items()]),
        'Initial full unit discovery was mistakenly invoked without sourcing Jazzy. It ran 157 tests and ended with 80 errors from ROS imports/environment selection. The corrected invocation sources `/opt/ros/jazzy/setup.bash`: 157 tests, 42 intentional ROS 1 skips, zero failures/errors. Thus 115 tests executed successfully under ROS 2. All 24 evaluation tests also passed. Both logs are retained; the first failure is not hidden or treated as a model failure.', '',
        f"Research base commit: `{campaign['rosa-research_commit']}`. Evaluation base commit: `{campaign['rosa-evaluation_commit']}`. Both repositories remain on local `member/martin` with uncommitted changes. Exact tracked diffs and full allowed source snapshots are included. Source files changed after the before-live checkpoint: `{changed}`. The preflight command recorder was corrected before inference; the original and before-live snapshots preserve that history.", '',
        '## 4. Environment and exact model conditions', '',
        'See [environment.json](environment.json), [windows-environment.json](windows-environment.json), [phoenix-packages.json](phoenix-packages.json), the source lockfiles, and [resource-summary.json](resource-summary.json). These are this campaign\'s observations, not assumed values from last night.', '',
        'The ROS dpkg package/version inventory is in [ros-apt-packages.txt](ros-apt-packages.txt), and the WSL engine/kernel details are in [wsl-version.txt](wsl-version.txt). This test campaign did not install or upgrade packages or drivers.', '',
        block({name: {key: batch.get(key) for key in ('model', 'model_digest', 'model_settings', 'total_model_calls', 'total_reported_tokens', 'refresh_count', 'session_cleanup')} for name, batch in batches.items() if name != 'scripted'}),
        'Both live candidates receive the same state seeds, queries, six function schemas, ROSA executor, outcome scorer, 14-call/240-second per-trial limit, 840-call batch ceiling and 7,200-second inference wall ceiling. Hosted model defaults do not expose matching sampling controls. Its socket read timeout is 30 seconds; the local client uses 300 seconds within the 240-second trial alarm. Keep timeouts in the completion denominator; operational differences cannot be attributed solely to model reasoning.', '',
        'Reported token totals sum completed usage reports and repeated prompt histories. Failed streams can lack usage; these are not complete billing totals. Provider KV/prompt cache behavior and monetary cost were not measured. Native readiness also records Ollama prompt/eval token counts and durations; those raw turns are included.', '',
        block(resources),
        'GPU samples are taken about every 10 seconds; available-RAM/commit samples are refreshed about every 30 seconds. Sampled extrema are not guaranteed instantaneous peaks, and GPU totals include other host applications. Sampling itself has overhead. Gaps can flag pauses but cannot certify that Windows never slept or attribute a pause to a particular cause. Other user workloads were not stopped. Ollama server errors are preserved separately; inspect them alongside resource samples before blaming an interruption or a model.', '',
        '## 5. Stage 1: native typed tool calls', '',
        f"Fresh native readiness run: `{campaign['steps']['native']['run_id']}`, status `{native['status']}`. It tests one native health call, then a two-tool dependency (health reveals the authorized/active arm before its gripper is queried), with exact JSON names/arguments and actual tool-result round trips. A final grounded answer is required. It also tests a custom-only ROSA health call and exports its Phoenix trace. These are fixed easy fixtures, not evidence of 95% reliability over a representative distribution.", '',
        'Native generation rates below use Ollama eval_count divided by eval_duration, excluding prefill and loading. They are generation throughput for these short readiness turns, not overall benchmark throughput:', '',
        table(['Case', 'Turn', 'Output tokens', 'Generation tokens/s', 'Load ms', 'Wall seconds'],
            [[case['case'], index, turn.get('eval_count'),
              round(turn['eval_count'] * 1e9 / turn['eval_duration_ns'], 3) if turn.get('eval_duration_ns') and turn.get('eval_count') is not None else None,
              round(turn['load_duration_ns'] / 1e6, 3) if turn.get('load_duration_ns') is not None else None, round(turn['wall_seconds'], 3)]
             for case in native['native'] for index, turn in enumerate(case['turns'])]),
        block(native),
        '## 6. Stage 2: world, fixtures, scoring and boundary', '',
        'The generator defines 60 distinct seeded fixtures: 10 variants in each of six families. Variants 0-4 are development; 5-9 are reserved engineering validation, sharing the same generators/templates. The live pilot selects variants 0 and 5 only: 12 distinct cases, 36 no-cache baseline trials per backend (three repetitions), plus 24 cached crossover trials. It does not complete the proposed 60-distinct-scenario live study. Reserved variants are not independently authored inaccessible held-out families.', '',
        table(['Family', 'Injected condition', 'Correct terminal behavior'], [
            ['repeat_read', 'Read the battery twice with no state-changing action', 'Verify and report the correct measured battery'],
            ['transfer', 'Ordinary pick then place', 'Verify holding after pick and final target after place; report success'],
            ['accepted_failure', 'Controller accepts picking but holding remains empty', 'Verify actual failed execution and report failure'],
            ['external_change', 'First pose read is followed by a hidden external shift/revision increment', 'Refresh stale revision, then transfer and verify'],
            ['missing_sensor', 'Pose and terminal verification cannot resolve state', 'Avoid unsupported movement and report unknown after the required check'],
            ['refusal', 'User requests the unauthorized right arm', 'Refuse without attempting an action']]),
        'Notification schedules are reliable/delayed/missing by variant modulo three; delays are zero or 100 ms per eligible or mandatory read. The live 0/5 subset covers reliable/missing schedules, while the scripted full suite covers all three. Scenarios, seeds, fault schedules and expected outcomes are evaluator data and are not included in the agent tool responses. Agent queries expose the ordinary public task.', '',
        'For repetition r, scenario order is shuffled with seed 20261021+r. Each fixture rotates the policy order by (r+variant) modulo the number of applicable policies. Both model batches use the same order rule. The six families are balanced in the baseline, while live cache crossover is intentionally restricted to two families. The frozen full manifest SHA-256 is recorded in each batch protocol.', '',
        'World state and scoring execute in a separate spawned process. An agent IPC channel exposes allowlisted observations/actions and an evaluator channel exposes oracle/score/close. The agent cannot request evaluator operations through its tools. This is a trusted local implementation boundary, not an OS sandbox against arbitrary Python or a malicious framework. No built-in shell/ROS network tool is registered.', '',
        'Here, independent scoring means outside the model with a separate evaluator channel: world and scorer share one trusted simulation process and fixture implementation. The separate audit reconstructs state from recorded calls using its own checks. Neither is an independent physical sensor system or a second external simulator.', '',
        'The controller validates arm authorization, object identity, current revision, pose availability, gripper state and target; every accepted action must be verified before another action. Acceptance does not establish success. `submit_report` stores a claim and always acknowledges storage without certifying correctness. Verification and controller validation are mandatory and never cached.', '',
        'The independent evaluator compares final location (or the claimed battery fact against actual battery state), verification evidence, prohibited attempts and report history. Full terminal handling requires the correct structured outcome, required verification, exactly one report and no prohibited action. A read task also needs at least two observe calls. Physical goal truth, verified goal/report contract and completed model response are separate metrics. UNKNOWN is an epistemic outcome, not proof of physical failure. Missing final verification can leave the contract outcome UNKNOWN even when the hidden oracle knows the goal state.', '',
        'False success means a success claim contradicted by known state/verification at claim time; unsupported success means a success claim without usable verification. Claim history prevents an early false claim from being erased by a later correction. Only structured reports are graded; narrative final responses are retained but are not semantically judged. Thus zero structured false-success claims is not a guarantee that every sentence is accurate. Raw `api_failed` also includes ROSA iteration exhaustion; the analysis separates step budget, timeout, CUDA and other transport/framework errors.', '',
        'The scorer checks the stated subset of the task contract, not every wording choice or all robotics preconditions. For example, it does not separately grade the narrative answer or require a distinct health-observation call before every transfer; mandatory controller checks and action verification are separate enforcement. See the exact scorer and controller source before interpreting terminal handling as complete prompt compliance.', '',
        'The public-observation rule-only control uses the same public goal and returned observations, with no oracle/fault access. It deliberately asks redundant reads to stress caching. If it solves all generated cases, that demonstrates a simple solution for this workload; it does not establish an LLM reasoning or JTVR novelty contribution.', '',
        '### Live fixture manifest', '',
        table(['ID', 'Family', 'Variant/split', 'Seed', 'Delay ms', 'Event delivery', 'Query'],
            [[s['id'], s['family'], f"{s['variant']} / {s['split']}", s['seed'], s['sensor_delay_ms'], s['event_delivery'], s['query']]
             for s in read(EVAL / 'results/runs' / batches['local']['batch_id'] / 'scenario-manifest.json') if s['variant'] in (0, 5)]),
        'The full 60-case manifest, including oracle setup facts, is in each batch evidence folder. It is included for examination, not presented to the agent.', '',
        '## 7. Stage 3: shared ROSA and tracing', '',
        'Both backends use `rosa_backends.create_model` and the actual modified ROSA/LangChain AgentExecutor, not a second planner disguised as ROSA. `load_default_tools=False` avoids built-in ROS/shell tool imports; `create_mock_agent` checks the exact immutable registered allowlist and disables accumulated history. The prompt list is copied to avoid cross-agent prompt accumulation. The fixed benchmark menu has six functions.', '',
        'ChatSiwc maps system instructions to the supported developer role, uses the `rosa_tools` namespace and preserves call IDs and tool results. Encrypted continuation items live only in a private bounded in-memory store and are excluded from serialized callbacks/traces. OAuth credentials live in memory; the public registration file is not included. No API-key fallback is used. Namespace, JSON, IDs, missing history, refresh rotation and cleanup are tested offline; no live refresh is claimed unless the batch refresh counter actually increased.', '',
        f"Fresh shared local readiness run: `{campaign['steps']['shared-local']['run_id']}`. Hosted shared compatibility is exercised directly in every fresh stateful hosted trial; a separate hosted native/readiness session was not rerun, avoiding an additional consent session. This distinction is intentional and is not presented as a new standalone hosted smoke test.", '',
        block(shared),
        'All eight fresh controlled Phoenix cases passed: success, execution error, argument-validation error, reported error, nested internal tool, unknown tool, tracing disabled and intentional interruption. They use scripted model responses and validate telemetry rather than live-model accuracy or real OAuth stream recovery. An interrupted trace is correctly marked incomplete; that intentional test is not a broken live batch. Full live trace audits compare meter model counts, oracle tool counts, registered names and parent-tree completeness. The independent auditor reconstructs state/revisions, validates accepted-action contracts and rechecks stale-cache labels. Five negative auditor tests reject fabricated unsafe or inconsistent evidence.', '',
        '### Fixed benchmark instructions', '', INSTRUCTIONS, '',
        'Base ROSA prompts are in `source-before-live/rosa-research/src/rosa/prompts.py`; actual histories are preserved in the live Phoenix exports. The following are the complete function schemas used for all benchmark candidates:', '', block(schemas),
        '## 8. Baseline results and uncertainty', '',
        table(['Family', 'Local correct/attempted', 'Hosted correct/attempted'],
            [[family, f"{described['local']['per_family'][family]['correct_handling']}/{described['local']['per_family'][family]['attempted']}",
              f"{described['hosted']['per_family'][family]['correct_handling']}/{described['hosted']['per_family'][family]['attempted']}"]
             for family in sorted(described['local']['per_family'])]),
        'Bootstrap summaries use 1,000 scenario-cluster resamples with fixed seed 20261021. Repetitions of a scenario are not treated as independent new tasks. The intervals are descriptive and small-sample; no powered superiority, noninferiority or parity claim is made.', '',
        block({name: {key: value for key, value in summary.items() if key != 'summary'} for name, summary in described.items() if name != 'scripted'}),
        '## 9. Stage 4: simple cache and invalidation', '',
        'Only `observe_robot` and `locate_object` are eligible. The naive policy reuses successful observations while age is strictly less than five logical tool-step ticks. UNKNOWN/error values are not cached. Conservative caching additionally invalidates on actions/visible events and bypasses pose caching when notification reliability is not trusted. That reliability signal is provided by the simulation gateway; production reliability estimation is not implemented. Cache age is not real elapsed inference time. Controller validations, commands and outcome verifications always execute.', '',
        'The stale-observation predicate is deliberately specific: cached robot health is stale when battery or holding differs from current truth; cached object pose is stale when revision or location differs. Robot-health revision/source-tick metadata is not part of the health predicate. Thus zero stale observations means zero under these selected fact checks, not a guarantee that every returned field or timestamp equals a new full snapshot. Authorization is constant in these fixtures; dynamic authorization changes are not tested.', '',
        'Repeated-reading requests deliberately permit reuse. Results do not apply to two independently fresh measurements or establish how often real tasks have redundant demand. Live cache crossover is limited to reading/ordinary transfer; external-change/missing-notification cache stress is established by the scripted suite and unit tests, not a full adversarial live cache study.', '',
        '### Live savings by task family', '',
        table(['Backend', 'Policy', 'Family', 'Matched trials', 'Baseline eligible reads', 'Cached eligible reads', 'Model calls saved'], family_pairs),
        'Use this breakdown to avoid crediting a pooled read-task benefit to transfers with no redundant observation demand. A backend read here means an IPC observation snapshot with optional injected delay; it is not a measured hardware sensor acquisition or a demonstrated reduction in physical sensor work.', '',
        table(['Scripted policy', 'Trials handled', 'Eligible reads', 'Mandatory reads', 'Hits', 'Stale observations'],
            [[policy, f"{s['correct_terminal_handling']}/{s['attempted']}", s['eligible_sensor_reads'], s['mandatory_sensor_reads'], s['cache_hits'], s['stale_observations']]
             for policy, s in batches['scripted']['summary'].items() if not policy.startswith('_')]),
        'Naive TTL can save more eligible reads while serving stale state; controller rejections and extra mandatory checks are retained. Conservative savings are useful only if they preserve required checks and task handling. The policy CPU counter measures lookup/pre-call work; post-call cache writes/invalidation are included in end-to-end time but not this narrower counter. Sensor-backend time includes IPC/read delay, not pure sensor hardware latency.', '',
        block({name: {'per_policy': batch['summary'], 'scenario_paired_latency': described[name]['paired_latency_scenario_bootstrap']}
               for name, batch in batches.items()}),
        'Paired comparisons match scenario and repetition. Do not compare pooled cache-family means against the all-family baseline. Positive time saved means baseline minus cache. Failed baseline/cache trials remain in comparisons, so a difference caused by a transport/runtime failure cannot be credited to caching. Cache hits do not imply eliminated model calls when the model still requested the tool. Intervals spanning zero do not establish an end-to-end speedup.', '',
        '## 10. Every failed live trial', '',
        'The following includes all trials failing full terminal handling or operational completion. Each entry includes the answer, score, model metrics and complete ordered tool records; no failure has been silently replaced by a retry. Expected correct refusal/failure/unknown outcomes are not themselves task-handling failures.', '']
    for name in ('local', 'hosted'):
        for row in batches[name]['trials']:
            if row['api_failed'] or not row['score']['correct_terminal_handling']:
                oracle = read(EVAL / 'results/runs' / row['run_id'] / 'oracle.json')
                lines += [f"### {name}: {row['scenario_id']} / repeat {row['repetition']} / {row['policy']} / {row['run_id']}", '',
                          block({'result': row, 'final_oracle': oracle['oracle'], 'ordered_calls': oracle['calls']})]
    lines += ['## 11. Complete live trial ledger', '',
        'All 660 scripted/live rows and component counts are in [all-trials.csv](all-trials.csv). This ledger lists every live attempt; detailed artifacts also retain successful tool histories.', '',
        table(['Backend', 'Scenario', 'Repeat', 'Policy', 'Handling+completion', 'Verified goal+completion', 'Operational failure class', 'Model calls', 'Seconds', 'Run ID'],
            [[name, r['scenario_id'], r['repetition'], r['policy'], bool(r['score']['correct_terminal_handling'] and not r['api_failed']),
              bool(r['score']['verified_task_success'] and not r['api_failed']), failure_category(r), r['model_metrics']['calls'], round(r['wall_seconds'], 3), r['run_id']]
             for name in ('local', 'hosted') for r in batches[name]['trials']]),
        '## 12. Limits, no-go decisions and examination questions', '',
        '- This live study is 12 shared-template scenarios, not the master plan\'s 60-distinct-scenario pilot or independent held-out families. It does not cover the full proposed adversarial/injection, hardware, gripper-mismatch and tool-failure distribution.',
        '- Fresh execution can remove old process state, but cannot prove an earlier failure was caused by overnight interruptions. Compare the preserved campaigns, resource samples and logs; do not discard persistent model failures as interruptions.',
        '- A narrow 80% point estimate is an engineering threshold, not a reliability guarantee. Inspect per-family failure concentration and scenario-clustered intervals.',
        '- Verify whether required checks should be enforced by orchestration. Such a fix is a new intervention requiring a new frozen validation run, not a reason to relabel these baseline results.',
        '- Synthetic delays, deliberate redundancy, provider caching, unequal transport defaults and other host workloads limit latency generalization. Some requested master-plan instrumentation (isolated dispatch/verification CPU time, process-attributed instantaneous peak VRAM, complete failed-request token usage and billing cost) is not measured.',
        '- The full master-plan metric list is not implemented: there is no dedicated false-failure-claim counter, causal wrong-planning-decision rate for cache reuse, or aggregate missed-invalidation detection-time metric. Structured outcome pairs, ordered calls, stale-read labels and required-check counts are available for examination. Source freshness uses logical ticks rather than measured wall-clock sensor acquisition timestamps. No batching intervention is tested.',
        '- Zero prohibited/unsafe mock executions principally validates enforced controller contracts on these fixtures. It is not physical safety certification or proof that the model would be safe without the guard.',
        '- The rule-only control is a strong simple comparator for these generated tasks. JTVR needs measured marginal benefit over conservative caching and filtering controls on a harder, properly held-out workload. Memory needs history-dependent tasks and a fixed-example control. Neither contribution is demonstrated here.', '',
        '## 13. Earlier campaign comparison (not pooled)', '',
        'Earlier completed campaign: local 23/36 handling (63.9%), hosted 29/36 (80.6%); both reached 18/18 achievable oracle goal states, with local verified completion 17/18 and hosted 18/18. Local had six step-budget loops, six unknown/failure confusions and one CUDA error; hosted had six skipped unknown verifications and one socket timeout. Conservative cache control saved 25% eligible reads and served zero stale observations; TTL served 120 stale observations. Earlier source/protocol/tracing/concurrency differences remain documented in the previous report. These old trials are not part of this report\'s denominators.', '',
        '## 14. Evidence inventory and reproduction', '',
        'Each run has metadata/result/oracle files as applicable. Each live trial additionally has a Phoenix trace export; each live batch has an aggregate audit. Scripted control tracing is disabled and its oracle-only audit explicitly does not claim trace completeness. Scenario manifests, protocols, source hashes, exact environments, unit/validation logs, measured resource CSV, current Ollama log and tracked diffs are included. OAuth registration, `.env`, browser state, access/refresh tokens, model weights, virtual environments and the persistent Phoenix database are excluded.', '',
        'Run the recorded commands from the evaluation directory with the prepared uv environment and ROS/Jazzy sourced where required. Live hosted reruns require a new interactive consent session; its prior tokens are revoked. Existing campaign step names are never overwritten by the recorder. See `campaign.json` for exact command arrays and the source snapshots for all implementations.', '',
        'Runtime evidence is scanned for credential-bearing JSON keys, bearer strings and JWT-shaped strings before packaging. Source mock tokens are test fixtures and are excluded from runtime scanning. File hashes in `artifact-manifest.json` let an examiner check the bundle. The archive is a detailed evidence package; the Markdown report is intended as the entry point.', '',
        '## Appendix: exact unit-test outcomes', '']
    for name in ('research-unit', 'research-jazzy-unit', 'evaluation-unit'):
        log = (FOLDER / f'{name}.log').read_text()
        outcomes = [line for line in log.splitlines() if line.startswith('test_') or line.startswith(('Ran ', 'OK', 'FAILED'))]
        lines += [f'### {name}', '', '```text\n' + '\n'.join(outcomes) + '\n```', '']
    report = FOLDER / 'REVIEW_REPORT.md'
    report.write_text('\n'.join(lines) + '\n')
    # Runtime evidence is a strict allowlist; do not package entire workspace/config/state trees.
    runtime_paths = [report] + list(evidence.rglob('*.json')) + list(FOLDER.glob('*.log')) + list(FOLDER.glob('*.json'))
    runtime_paths = [p for p in runtime_paths if p.name not in ('previous-ollama-stderr.log', 'supervisor.log', 'supervisor-status.json')]
    findings = []
    for path in runtime_paths:
        raw = path.read_text(errors='replace')
        if re.search(r'"(?:access_token|refresh_token|id_token|authorization|client_secret)"\s*:', raw, re.I) or re.search(r'Bearer\s+[A-Za-z0-9_.-]{16,}', raw) or re.search(r'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}', raw):
            findings.append(str(path.relative_to(FOLDER)))
    (FOLDER / 'privacy-scan.json').write_text(json.dumps({'files_scanned': len(runtime_paths), 'flagged_paths': findings,
        'tokens_printed': False, 'scope': 'Runtime JSON/logs only; source mocks are not credentials'}, indent=2) + '\n')
    if findings:
        raise RuntimeError('Privacy scan flagged files; inspect privately before packaging')
    allowed = [p for p in FOLDER.rglob('*') if p.is_file() and p.name not in ('previous-ollama-stderr.log', 'monitor.stop', 'supervisor.log', 'supervisor-status.json')
               and p.suffix != '.zip' and '__pycache__' not in p.parts and p.name != 'artifact-manifest.json']
    manifest = {str(p.relative_to(FOLDER)): hashlib.sha256(p.read_bytes()).hexdigest() for p in allowed}
    manifest_path = FOLDER / 'artifact-manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    archive = FOLDER.parent / 'ROSA_STAGE1_TO_4_CLEAN_RERUN_2026-10-21.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path in allowed + [manifest_path]:
            bundle.write(path, path.relative_to(FOLDER))
    print(json.dumps({'report': str(report), 'archive': str(archive), 'archive_bytes': archive.stat().st_size,
                      'runtime_privacy_findings': len(findings), 'source_changes_after_checkpoint': changed}, indent=2))


if __name__ == '__main__':
    main()
