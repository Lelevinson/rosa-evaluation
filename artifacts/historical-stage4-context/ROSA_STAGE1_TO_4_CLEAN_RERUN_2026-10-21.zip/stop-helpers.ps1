$ErrorActionPreference = 'Stop'
[System.IO.File]::WriteAllText((Join-Path $PSScriptRoot 'monitor.stop'), 'Tests and audits finished.')
$markers = @('clean-stage1-4-20261021-r1/monitor.ps1', 'clean-stage1-4-20261021-r1/keep-awake.ps1')
$owned = @(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" | Where-Object {
    $line = ([string]$_.CommandLine).Replace('\', '/')
    @($markers | Where-Object { $line.Contains($_) }).Count -gt 0
})
foreach ($entry in $owned) {
    $running = Get-Process -Id $entry.ProcessId -ErrorAction SilentlyContinue
    if ($running) {
        try { Wait-Process -Id $running.Id -Timeout 30 }
        catch { if (Get-Process -Id $entry.ProcessId -ErrorAction SilentlyContinue) { throw } }
    }
}
[pscustomobject]@{observed_utc=[DateTime]::UtcNow.ToString('o'); stop_marker_written=$true; identified_helpers=@($owned.ProcessId); all_identified_helpers_exited=$true} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'helper-cleanup.json') -Encoding UTF8
Write-Output 'Resource sampler and temporary idle-sleep request stopped.'
