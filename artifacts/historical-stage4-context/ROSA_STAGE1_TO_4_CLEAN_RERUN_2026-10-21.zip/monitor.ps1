$ErrorActionPreference = 'Stop'
$folder = $PSScriptRoot
$iteration = 0
$memory = $null
while (!(Test-Path -LiteralPath (Join-Path $folder 'monitor.stop'))) {
    $gpu = (& nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,power.draw,temperature.gpu --format=csv,noheader,nounits | Select-Object -First 1) -split ',\s*'
    if (($iteration % 3) -eq 0) {
        try { $memory = Get-CimInstance Win32_OperatingSystem } catch { $memory = $null }
    }
    $freeRam = $null
    $freeCommit = $null
    if ($memory) {
        $freeRam = [math]::Round($memory.FreePhysicalMemory / 1024)
        $freeCommit = [math]::Round($memory.FreeVirtualMemory / 1024)
    }
    [pscustomobject]@{
        observed_utc = [DateTime]::UtcNow.ToString('o')
        gpu_utilization_percent = $gpu[0]
        gpu_memory_used_mib = $gpu[1]
        gpu_memory_total_mib = $gpu[2]
        gpu_power_w = $gpu[3]
        gpu_temperature_c = $gpu[4]
        free_ram_mib = $freeRam
        free_commit_mib = $freeCommit
    } | Export-Csv -LiteralPath (Join-Path $folder 'resource-samples.csv') -NoTypeInformation -Append
    $iteration += 1
    Start-Sleep -Seconds 10
}
Write-Output 'Resource sampling stopped.'
