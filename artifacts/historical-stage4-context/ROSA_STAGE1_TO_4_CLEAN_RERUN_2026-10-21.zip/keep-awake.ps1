$ErrorActionPreference = 'Stop'
Add-Type -Namespace RosaTestPower -Name Native -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
public static extern uint SetThreadExecutionState(uint flags);
'@
$held = [RosaTestPower.Native]::SetThreadExecutionState([uint32]2147483649)
if ($held -eq 0) { throw 'The temporary system-awake request could not be established.' }
try {
    [pscustomobject]@{started_utc=[DateTime]::UtcNow.ToString('o'); kind='thread-scoped ES_CONTINUOUS | ES_SYSTEM_REQUIRED'; display_required=$false; persistent_power_plan_changed=$false} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'power-hold.json') -Encoding UTF8
    Write-Output 'Temporary idle-sleep hold active; display settings unchanged.'
    while (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'monitor.stop'))) { Start-Sleep -Seconds 10 }
} finally {
    [void][RosaTestPower.Native]::SetThreadExecutionState([uint32]2147483648)
    Write-Output 'Temporary idle-sleep hold released.'
}
