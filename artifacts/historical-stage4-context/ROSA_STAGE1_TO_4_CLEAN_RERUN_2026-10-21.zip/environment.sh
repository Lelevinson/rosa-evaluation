#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
exec /home/martin/.local/share/rosa-envs/research/bin/python -B /mnt/c/Proj/robotics/introtorobotics/reports/clean-stage1-4-20261021-r1/environment.py
