#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Proj/robotics/introtorobotics/rosa-evaluation
folder=/mnt/c/Proj/robotics/introtorobotics/reports/clean-stage1-4-20261021-r1
if [[ -e "$folder/supervisor.pid" ]]; then
    echo 'A detached supervisor was already launched. Inspect its status instead of duplicating trials.' >&2
    exit 1
fi
nohup /home/martin/.local/share/rosa-envs/research/bin/python -B "$folder/supervise_local.py" > "$folder/supervisor.log" 2>&1 < /dev/null &
printf '%s\n' "$!" > "$folder/supervisor.pid"
echo "Detached test supervisor PID $!; incremental status: $folder/supervisor-status.json"
