"""Launch with a new Linux session, as used by the persistent Phoenix service."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

folder = Path(__file__).parent
pid_file = folder / 'supervisor.pid'
attempts = []
history = folder / 'launch-attempts.json'
if history.exists():
    attempts = json.loads(history.read_text())
if pid_file.exists():
    previous = int(pid_file.read_text().strip())
    if Path(f'/proc/{previous}').exists():
        raise RuntimeError('A prior supervisor PID still exists; inspect before launching another')
    attempts.append({'pid': previous, 'outcome': 'EXITED_BEFORE_LOCAL_STEP',
                     'observed_utc': datetime.now(timezone.utc).isoformat(),
                     'local_trial_started': False, 'launcher': 'shell nohup'})
campaign = json.loads((folder / 'campaign.json').read_text())
if 'local' in campaign['steps']:
    raise RuntimeError('Local step already recorded; refusing duplicate execution')
with (folder / 'supervisor.log').open('a') as log:
    process = subprocess.Popen(['/home/martin/.local/share/rosa-envs/research/bin/python', '-B',
        str(folder / 'supervise_local.py')], cwd=folder.parent.parent / 'rosa-evaluation',
        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        start_new_session=True, close_fds=True)
pid_file.write_text(str(process.pid) + '\n')
attempts.append({'pid': process.pid, 'outcome': 'LAUNCHED_NEW_SESSION',
                 'observed_utc': datetime.now(timezone.utc).isoformat(), 'launcher': 'Popen(start_new_session=True)'})
history.write_text(json.dumps(attempts, indent=2) + '\n')
print(f'Local supervisor launched in a new session: PID {process.pid}')
